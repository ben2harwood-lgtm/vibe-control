(function () {
'use strict';
const state = typeof module !== 'undefined' ? require('./state.js') : globalThis.StudioState;
// All data reaches HTML through this encoder; candidate data never supplies tags or URLs.
const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const line = value => `<p>${escape(value)}</p>`;
const warning = value => `<p class="warning">${escape(value)}</p>`;
const details = value => `<pre>${escape(value)}</pre>`;
const section = (name, body) => `<section id="${name.toLowerCase().replaceAll(' ', '-')}" tabindex="-1"><h2>${name}</h2>${body}</section>`;
const rows = (items, render, empty) => items.length ? items.map(render).join('') : line(empty);
const ref = state.candidateText;
const error = value => value ? warning(state.errorText(value)) : '';

function renderEvidence(title, records, recordedOnly = false) {
    return `<h3>${title}</h3>` + rows(records, record =>
        `<article>${line(`${record.id} · ${record.status}`)}${line(ref(record.request.binding.candidate))}` +
        details(`Definition: ${record.request.binding.definition_digest}\nEnvironment: ${record.request.binding.environment_digest}`) +
        (recordedOnly ? '' : error(record.result?.error)) + '</article>', recordedOnly ? 'Not recorded' : 'Not run');
}

function previewFrame(preview) {
    const text = `${preview.id}\n${ref(preview.candidate)}\nPreview document not supplied by contract.`;
    const doc = '<!doctype html><html lang="en"><meta charset="utf-8">' +
        '<meta http-equiv="Content-Security-Policy" content="default-src &#39;none&#39;">' +
        '<title>Fixture preview</title><body><pre>' + escape(text) + '</pre></body></html>';
    return `<iframe title="Fixture preview" sandbox="" referrerpolicy="no-referrer" srcdoc="${escape(doc)}"></iframe>`;
}

function renderLive(live) {
    if (!live) return '';
    return `<aside aria-label="Local event session">${line(`Fake local source: ${live.fixture}`)}` +
        `<p role="status">${escape(live.status)}</p>` +
        line(`Cursor: ${live.cursor} · Notifications are not acceptance or stop confirmation.`) +
        (!live.status.startsWith('Connected') ? warning('State uncertain · Panels are unavailable or show the last recorded snapshot; reconnect to synchronise.') : '') +
        '<ol aria-label="Retained event journal">' + live.events.map(e =>
            `<li>${escape(`${e.sequence} · ${e.id} · ${e.state}`)}</li>`).join('') + '</ol></aside>';
}

function renderRunPage(model) {
    const supplied = model.runPage, view = supplied.view, data = view.journey || {};
    const names = ['Plan', 'Agents', 'Changes', 'Checks', 'Review', 'Spend', 'Approval and delivery'];
    const nav = `<nav aria-label="Workspace sections">${names.map(name =>
        `<a href="#${name.toLowerCase().replaceAll(' ', '-')}">${name}</a>`).join('')}</nav>`;
    const words = value => value == null ? 'Not recorded' : String(value).replaceAll('_', ' ');
    const record = view.records[view.current];
    const short = candidate => candidate?.digest?.replace(/^sha256:/, '').slice(0, 8) || 'Not recorded';
    const heading = '<header><h1>Vibe Control run</h1>' + line(view.id) +
        line(`Run: ${model.status} · Journey: ${data.outcome || 'Not recorded'}`) +
        line(`Approval: ${words(data.approval)} · Delivery: ${words(data.delivery)}`) +
        line('Completion does not mean approved. Approval stays in the terminal.') +
        line(data.review_notice || 'Not recorded') +
        (data.reason ? warning(data.reason) : '') +
        '<p><a href="../receipt.md">Receipt</a></p></header>';
    const plan = line(`Brief: ${data.brief || 'Not recorded'}`) +
        line(`Time limit: ${view.plan?.time_limit_seconds == null ? 'Not recorded' : view.plan.time_limit_seconds + ' seconds'}`) +
        line('Tool: Claude Code') + line(`Tool version: ${data.tool_version || 'Not recorded'}`) +
        line(`Check command: ${data.check_command || 'Not recorded'}`) +
        line(`Branch: ${data.branch || 'Not recorded'}`) + line(data.review_notice || 'Not recorded');
    const models = run => run?.details?.models_reported?.length ?
        run.details.models_reported.join(', ') : 'Not recorded';
    const agents = line(`Builder: session A · Models reported: ${models(data.build)}`) +
        line(`Reviewer: session B · Models reported: ${models(data.review)}`);
    const changes = (data.changes ? rows(data.changes, file =>
        line(`${file.path} (+${file.added} -${file.removed})`), 'No files changed') : line('Not recorded')) +
        line(`Result code: ${short(record?.candidate)}`);
    const checkLines = (label, result, key) => {
        let verdict = 'Not recorded';
        if (result) {
            verdict = result.timed_out ? 'held (time limit reached)' : result.passed ? 'passed' :
                supplied.could_not_start?.[key] ? 'could not start' :
                result.returncode == null ? 'held (result uncertain)' : 'failed';
        }
        return line(`${label}: ${data.check_command || 'Not recorded'} — ${verdict}`) +
            (result?.output ? '<details><summary>Check output</summary>' + details(result.output) + '</details>' : '');
    };
    const checks = checkLines('Baseline', data.baseline, 'baseline') + checkLines('Candidate check', data.check, 'check') +
        (data.check?.identical_failure_before_and_after ?
            line('Check failed before and after the change, identically. It does not show the change works.') : '') +
        (view.stopped ? warning('Stopped. ' + (data.reason || 'Checks may be unfinished.')) : '');
    const verdicts = { approve: 'approved by reviewer', reject: 'rejected by reviewer', uncertain: 'uncertain — held' };
    const review = line(`Review: ${verdicts[data.review?.verdict] || words(data.review?.verdict)}`) +
        (data.review ? rows(data.review.findings || [], line, 'No findings') : '') +
        line(data.review_notice || 'Not recorded') +
        (view.stopped ? warning('Stopped. ' + (data.reason || 'Review may be unfinished.')) : '');
    const approval = record?.approvals?.at(-1);
    const approved = approval?.tuple;
    const publication = record?.publications?.at(-1);
    const delivered = publication?.outcome === 'succeeded';
    const branch = destination => destination?.ref?.replace(/^refs\/heads\//, '') || 'Not recorded';
    const delivery = line(approval ? 'Approved by: you, at the terminal' : `Approval: ${words(data.approval)}`) +
        (approved ? line(`Approved: result code ${short(approved.candidate)}, branch ${branch(approved.destination)}`) : '') +
        line(`Approved when: ${approval?.recorded_at ?? 'Not recorded'}`) +
        (delivered ? line(`Delivered: branch ${branch(publication.body.destination)} into your own repository. Nothing pushed elsewhere.`) :
            line(`Delivery: ${words(publication?.outcome || data.delivery)}. ${data.reason || 'No delivery recorded.'}`));
    const reportedComplete = model.complete && data.build?.capture?.complete && data.review?.capture?.complete;
    const usage = data.usage;
    const synthetic = usage?.limits?.unit === 'synthetic_token';
    const unit = synthetic ? 'tokens reported by Claude Code' : usage?.limits?.unit;
    const spend = line(`Observed: ${usage?.limits ? usage.observed_units + ' ' + unit : 'Not recorded'}`) +
        line("Observed units are the tool's own report; not a bill.") +
        line(`Usage: ${reportedComplete ? 'Complete as reported' : 'Incomplete · Final usage unknown'}`) +
        line(`Time limit: ${supplied.enforced_limits?.max_seconds == null ? 'Not recorded' : supplied.enforced_limits.max_seconds + ' seconds'}`) +
        line(`Turn limit: ${supplied.enforced_limits?.max_turns ?? 'Not recorded'}`) +
        line(`Time taken: ${data.wall_seconds == null ? 'Not recorded' : data.wall_seconds + ' seconds'}`);
    const journal = '<aside aria-label="Run export">' +
        line('Disk export. Refresh after each journey step to see progress.') +
        line(`Stop requested: ${view.stopped ? 'Yes' : 'No'}`) +
        (view.stopped ? warning(data.reason || 'Stopped; termination not recorded.') : '') +
        '</aside>';
    return heading + nav + '<div class="panels">' + [section('Plan', plan),
        section('Agents', agents),
        section('Changes', changes), section('Checks', checks), section('Review', review),
        section('Spend', spend), section('Approval and delivery', delivery)].join('') + '</div>' + journal;
}

function render(model) {
    if (model.runPage && model.snapshot) return renderRunPage(model);
    const nav = `<nav aria-label="Workspace sections">${state.sections.map(name => `<a href="#${name.toLowerCase()}">${name}</a>`).join('')}</nav>`;
    const heading = renderLive(model.live) + `<header><p class="eyebrow">AAC Studio · UIW</p><h1>Project workspace</h1><p>Made-up fixture data · Local only</p></header>`;
    if (!model.snapshot) return heading + nav + `<p role="status">${escape(model.status)}</p>` +
        state.sections.map(name => section(name, line(model.status) + (name === 'Checks' ? line('Not run') : ''))).join('');
    const d = model.snapshot;
    const summary = `<div class="summary" role="status">${line(`${d.project.id} · ${d.fixture}`)}${line(`Run: ${model.status} · ${d.run.id} · Attempt ${d.attempt.ordinal}`)}${error(d.run.error)}${line('Acceptance: Not established by these fixtures')}</div>`;
    const plan = line(`Task: ${d.task.id}`) + line('Plan text and dependencies: Not supplied by contract.') +
        (d.authority?.plan ? details(`Recorded plan: ${d.authority.plan.id} · Revision ${d.authority.plan.revision} · ${d.authority.plan.digest}`) : line('Approved revision: Not supplied by contract.')) +
        details(`Runtime: ${d.project.runtime_container_id}\nIsolation: ${d.task.isolation.kind} · ${d.task.isolation.id}\n${d.task.isolation.decision}`);
    const actors = new Map();
    for (const record of [...d.commands, ...d.approvals, ...d.checks.map(c => c.request), ...d.reviews.map(r => r.request)]) {
        actors.set(record.actor.id, record.actor);
    }
    const agents = line('Agent roster: Not supplied by contract. Recorded actors:') + rows([...actors.values()], a => line(`${a.id} · ${a.kind}`), 'No recorded actors');
    const previews = rows(model.previews, p => `<article>${p.stale ? warning('Stale preview · Does not match the current candidate') : line(`Preview: ${p.state}`)}${line(ref(p.candidate))}${error(p.error)}${previewFrame(p)}</article>`, 'No preview') + line('Preview readiness does not establish acceptance.');
    const changes = `<h3>Current candidate</h3>${details(ref(model.current))}` + line('File changes and diffs: Not supplied by contract.') +
        rows(d.candidates, c => details(`${ref(c.ref)}\nBase: ${c.base_digest}`), 'No candidate') + '<h3>Recorded approvals</h3>' +
        rows(model.approvals, a => `<article>${a.stale ? warning('Stale approval · Invalid for current candidate') : line('Recorded active approval · Display only')}${line(`${a.id} · ${a.action}`)}${details(JSON.stringify(a.destination))}${details(ref(a.candidate))}</article>`, 'No approval');
    const commands = '<h3>Commands</h3>' + rows(d.commands, c => line(`${c.id} · ${c.body.action} · ${c.outcome === 'received' ? 'Received · Not confirmed successful' : c.outcome}`) + error(c.error), 'No commands') +
        (d.cancellation.requested ? warning(d.cancellation.resolution === 'reconciled' ? 'Stop reconciled · See recorded run state' : 'Stop requested · Not confirmed stopped; reconciliation required') : '') +
        line(`Cancellation requested: ${d.cancellation.requested ? 'Yes' : 'No'} · Resolution: ${d.cancellation.resolution}`) +
        line(`In-flight commands: ${d.cancellation.in_flight_command_ids.join(', ') || 'None recorded'}`);
    const checks = renderEvidence('Checks', model.checks) + renderEvidence('Reviews', model.reviews) + commands;
    const spend = line(`Observed: ${model.observed} / ${d.limits.max_units} ${d.limits.unit}`) +
        (model.exhausted ? warning('Synthetic ceiling exhausted') : line('Synthetic ceiling not exhausted')) +
        line(`Usage: ${model.complete ? 'Complete' : 'Incomplete · Final usage unknown'}`) +
        line('Made-up units only; no currency amount or provider billing is supplied.') +
        line('Plan controls: reject new work beyond known limits. In-flight requests can still incur usage; this is not a billing guarantee.') +
        line('Subscription mode: turn/time limits and stop; no additional charge assumes usage credits off. Direct API: reservations and stop on observed usage; provider enforcement may lag. Option G: refuses beyond budget before forwarding; admitted requests and generated tokens remain billable. Prepaid balance is an additional limit, not a guarantee.');
    return heading + nav + summary + '<div class="panels">' + [section('Plan', plan), section('Agents', agents), section('Preview', previews), section('Changes', changes), section('Checks', checks), section('Spend', spend)].join('') + '</div>';
}
const api = { render, escape };
if (typeof module !== 'undefined') module.exports = api;
else globalThis.StudioRender = api;
})();
