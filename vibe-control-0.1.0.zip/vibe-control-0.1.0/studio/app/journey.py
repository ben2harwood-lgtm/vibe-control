"""J1 orchestration over EX1's journal and frozen-candidate publisher."""
from contextlib import contextmanager
from dataclasses import asdict
import difflib
import json
import os
import re
from pathlib import Path
import signal
import shlex
import subprocess
import sys
import tempfile
import time

STUDIO = Path(__file__).resolve().parents[1]
for _folder in ('execution', 'providers', 'limits', 'onboarding', 'licence', 'publisher'):
    _path = str(STUDIO / _folder)
    if _path not in sys.path:
        sys.path.insert(0, _path)

from adapters import Capture
from artifacts import Refused, digest, require, restore
from claude_code import ClaudeCode, ClaudeCodeAgent, FAMILY, _exited
from execution import Service
from licence import Licence
from limits import Limits, kill_trees, processes
from repositories import MOVED, base_manifest, example_copy, inspect_tracked, metadata_copy, push_destination, require_build_room
from publisher import Publisher, endpoint
import intake
from page import plain, write_page

SESSIONS = {role: dict(id='local-' + role, role=role, projects=['project_local'], family=family)
            for role, family in [('control_service', 'local-service'), ('customer', 'local-user'),
                                 ('checker', 'local-check'), ('reviewer', FAMILY)]}
SESSIONS['task_agent'] = dict(id='local-builder', role='task_agent',
                             projects=['project_local'], family=FAMILY)
DEPENDENCY_HINT = ('Checks run in a clean copy; if your tests need dependencies, include the install '
                   'step, for example --check "npm ci && npm test"')
FAILING_BASELINE_NOTICE = (
    'Your check already fails before any change. If you continue, the check can only tell you '
    'whether the change made things different, not that it works. Answer N to stop.')
IDENTICAL_FAILURE_NOTICE = ('Check failed before and after the change, identically. '
                            'It does not show the change works.')


def check_could_not_start(result):
    """Command availability, not a list of particular test tools or ordinary failures."""
    if result.get('returncode') in (126, 127):
        return True
    output = result.get('output', '')
    if re.search(r"^(?:(?:/?(?:bin/)?(?:sh|bash|zsh)): (?:line \d+: |\d+: )?)?"
                 r"[A-Za-z_./~][^\s:]*: (?:command )?not found[ \t]*$|"
                 r"^(?:/?(?:bin/)?(?:sh|bash|zsh)): command not found: [^\s:]+[ \t]*$|npm[^\n]*missing script",
                 output, re.I | re.M):
        return True
    if re.search(r"(?:^|\n)(?:\S*sh|(?:/usr/bin/)?env):[^\n]*No such file or directory", output, re.I):
        return True
    if re.search(r"doesn't seem to have been installed|"
                 r"Local package\.json exists, but node_modules missing",
                 output, re.I):
        return True
    packages = re.findall(r"Cannot find (?:module|package) ['\"]([^'\"]+)['\"]", output, re.I)
    return any(not name.startswith(('.', '/', '\\')) for name in packages)


UNIT_RESERVATION = 1000000
REVIEW_NOTICE = ('Reviewed by a second, fresh Claude Code session of the same model family. '
                 'This is not an independent review.')
REVIEW_PENDING = ('Not reviewed yet. Before any approval, the change will be reviewed by a second, fresh '
                  'Claude Code session of the same model family; that is not an independent review.')
LIMITS_LINE = ('Limits enforced: the time limit above and 2 tool turns (one build, one review). '
               'Tokens are recorded as Claude Code reports them; they are not capped and this is not a bill.')
SCRIPT_CHANGED = 'The change edited the test script'
TOUCHED = 'This change touched files your check may depend on: '
NOT_TYPED = ('The approval code was not typed correctly. Run the same command again to be asked again '
             'for this same result; nothing is rebuilt.')
# Caps on untrusted text a person reads (characters, lines, items).
BRIEF_LIMIT, OUTPUT_LIMIT, OUTPUT_LINES, FINDING_LIMIT, FINDINGS_SHOWN = 2000, 4000, 60, 500, 20
PATH_LIMIT, FILES_SHOWN, REASON_LIMIT = 200, 50, 1000
STOP_SIGNALS = (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)


def quoted(marker, text, lines=OUTPUT_LINES):
    """Untrusted (already plain) text, every line behind a fixed marker."""
    rows = text.split('\n')
    shown = ['  %s> %s' % (marker, row) for row in rows[:lines]]
    if len(rows) > lines:
        shown.append('  (%d more lines not shown)' % (len(rows) - lines))
    return shown


def recorded_check(result):
    """What the journal keeps of a check: plain, capped output; start test from the full output."""
    return dict(result, output=plain(result.get('output', ''), OUTPUT_LIMIT),
                could_not_start=check_could_not_start(result))


def recorded_details(details):
    details = dict(details or {})
    models = [plain(m, 100, newlines=False) for m in details.get('models_reported') or []]
    details['models_reported'] = models
    if isinstance(details.get('identity'), dict):
        details['identity'] = dict(details['identity'], models_reported=models)
    return details


def recorded_review(review):
    findings = review['findings']
    return dict(review, findings=[plain(f, FINDING_LIMIT) for f in findings[:FINDINGS_SHOWN]],
                findings_not_shown=max(0, len(findings) - FINDINGS_SHOWN),
                details=recorded_details(review.get('details')))


def review_notice(data):
    return REVIEW_NOTICE if (data.get('review') or {}).get('verdict') in ('approve', 'reject') else REVIEW_PENDING


INSTALL_SCRIPTS = ['preinstall', 'install', 'postinstall', 'preprepare', 'prepare', 'postprepare']
NPM_INSTALL = {'ci', 'install', 'i', 'in', 'ins', 'add', 'clean-install', 'install-clean', 'isntall'}
INSTALL_TEST = {'it', 'cit', 'install-test', 'install-ci-test', 'clean-install-test'}


def script_runs(command, scripts, depth=0):
    """Names of package.json scripts a check command runs through npm, yarn, pnpm or
    `node --run` (with their pre/post scripts and the scripts those run in turn)."""
    try:
        lexer = shlex.shlex(command, posix=True, punctuation_chars=True)
        lexer.whitespace_split = True
        tokens = list(lexer) + [';']
    except ValueError:
        return sorted(scripts) if re.search(r'\b(npm|yarn|pnpm|node)\b', command) else []
    names, words = [], []
    for token in tokens:
        if token and all(c in '();<>|&' for c in token):
            names += [n for n in _segment_runs(words, scripts, depth) if n not in names]
            words = []
        else:
            words.append(token)
    return names


def _segment_runs(words, scripts, depth):
    while words and (re.match(r'[A-Za-z_][A-Za-z0-9_]*=', words[0]) or
                     words[0] in ('env', 'exec', 'command', 'time', 'nice')):
        words = words[1:]
    if not words or depth > 4:
        return []
    tool = os.path.basename(words[0])
    if tool in ('sh', 'bash', 'zsh', 'dash') and '-c' in words[:-1]:
        return script_runs(words[words.index('-c') + 1], scripts, depth + 1)
    rest, readings = words[1:], []
    if tool == 'node':
        run = [w.split('=', 1)[1] if w.startswith('--run=') else words[i + 2]
               for i, w in enumerate(words[1:]) if (w == '--run' and i + 2 < len(words)) or w.startswith('--run=')]
        readings = [(False, run)]
    # Every reading of an option's possible value is resolved, and the union is locked.
    for i in _next_words(rest) if tool in ('npm', 'yarn', 'pnpm') else []:
        sub, after = (rest[i], rest[i + 1:]) if i < len(rest) else ('', [])
        named = [after[j] for j in _next_words(after) if j < len(after)]
        if tool == 'npm':
            run = (['test'] if sub in ('test', 't', 'tst') or sub in INSTALL_TEST else
                   [sub] if sub in ('start', 'stop', 'restart') else
                   named if sub in ('run', 'run-script', 'rum', 'urn') else [])
            install = sub in NPM_INSTALL or sub in INSTALL_TEST
        else:
            run = (['test'] if sub in ('test', 't') or sub in INSTALL_TEST else
                   named if sub in ('run', 'run-script') else
                   [sub] if sub in scripts else [])
            install = sub in ('', 'install', 'i', 'add') or sub in INSTALL_TEST
        readings.append((install, run))
    names = []
    for install, run in readings:
        found = list(INSTALL_SCRIPTS) if install else []
        for name in run:
            found += ['pre' + name, name, 'post' + name]
        names += [n for n in found if n not in names]
    for name in list(names):
        if isinstance(scripts.get(name), str):
            names += [n for n in script_runs(scripts[name], scripts, depth + 1) if n not in names]
    return names


def _next_words(words):
    """Indexes of the words that may be the next non-option word. A word straight after a bare
    option (`-x` or `--name`, no `=`) may be that option's value, so both readings are kept;
    len(words) stands for "no word" when every candidate may be a value."""
    found = []
    for i, word in enumerate(words):
        if not word.startswith('-'):
            found.append(i)
            if i == 0 or not words[i - 1].startswith('-') or '=' in words[i - 1]:
                return found
    return found + [len(words)]


def package_scripts(manifest):
    entry = next((e for e in manifest['entries'] if e['path'] == 'package.json'), None)
    try:
        scripts = json.loads(bytes.fromhex(entry['bytes_hex'])).get('scripts') if entry else None
    except (ValueError, AttributeError):
        scripts = None
    return scripts if isinstance(scripts, dict) else {}


LOCKFILES = {'package.json', 'package-lock.json', 'npm-shrinkwrap.json', 'yarn.lock',
             'pnpm-lock.yaml', 'bun.lock', 'bun.lockb'}


def check_may_depend(path):
    parts = path.split('/')
    return (parts[-1] in LOCKFILES or any(p in ('test', 'tests', '__tests__') for p in parts[:-1])
            or re.search(r'\.(test|spec)\.', parts[-1]) is not None)


def run_check(command, workspace, seconds, *, on_start=None, on_abort=None, on_finish=None):
    """User-supplied shell command, on a restored copy; LIM ends its process tree."""
    started = time.monotonic()
    with tempfile.TemporaryFile() as stream:
        process = subprocess.Popen(command, shell=True, executable='/bin/sh', cwd=workspace,
                                   stdin=subprocess.DEVNULL, stdout=stream, stderr=stream,
                                   start_new_session=True)
        known, cleaned = {}, False
        try:
            row = processes().get(process.pid)
            require(row is not None, 'check process identity unavailable')
            known[process.pid] = row['start']
            if on_start:
                on_start(process.pid)
            # RV-A's exit observer retains the leader until LIM has swept descendants.
            timed_out = not _exited(process.pid, seconds)
            if timed_out and on_abort:
                on_abort('Check time limit reached.')
            result = kill_trees(known, 5)
            if on_finish:
                on_finish(result)
            process.wait(timeout=5)
            cleaned = True
            require(result['complete'] and all(p['state'] == 'dead' for p in result['processes']),
                    'check descendants not confirmed stopped')
            stream.seek(0)
            output = stream.read(4 * 1024 * 1024 + 1)
            require(len(output) <= 4 * 1024 * 1024, 'check output exceeds 4 MiB: hold')
            return dict(returncode=None if timed_out else process.returncode,
                        output=output.decode('utf-8', 'replace'), timed_out=timed_out,
                        passed=not timed_out and process.returncode == 0,
                        wall_seconds=round(time.monotonic() - started, 3))
        except KeyboardInterrupt:
            if on_abort:
                on_abort('Stopped during check by Ctrl-C.')
            raise
        finally:
            if not cleaned:
                try:
                    if known:
                        result = kill_trees(known, 5)
                        if on_finish:
                            on_finish(result)
                    else:
                        # The unreaped process still owns this group when ps is unavailable.
                        try:
                            os.killpg(process.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                except (Refused, OSError):
                    # Still our unreaped leader: end its group even if the tree scan failed.
                    # This does not prove detached descendants dead; the error remains a hold.
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    raise
                finally:
                    process.wait(timeout=5)


def changed_files(base, candidate):
    old = {e['path']: e for e in base['entries']}
    new = {e['path']: e for e in candidate['entries']}
    result = []
    for path in sorted(old.keys() | new.keys()):
        if old.get(path) == new.get(path):
            continue
        lines = []
        for files in (old, new):
            lines.append(bytes.fromhex(files.get(path, {}).get('bytes_hex', '')).decode(
                'utf-8', 'replace').splitlines())
        diff = list(difflib.ndiff(*lines))
        result.append(dict(path=path, added=sum(s.startswith('+ ') for s in diff),
                           removed=sum(s.startswith('- ') for s in diff)))
    return result


def check_line(result):
    if not result:
        return 'not run'
    if result.get('held'):
        return 'held, not run (%s)' % result['held']
    if result.get('timed_out'):
        return 'time limit reached'
    if result.get('passed'):
        return 'passed'
    return 'failed (exit %s)' % result.get('returncode')


def summary(run_id, data):
    """Plain lines from the journal's `journey` entry (an export of Service.view).

    Untrusted text (reviewer findings, error text in the reason) comes first, behind fixed
    markers or labels and without control characters; the command's own facts follow it, so
    they are the last thing shown before the approval question.
    """
    text = ['Vibe Control run ' + run_id]
    review = data.get('review')
    if review and review['findings']:
        rows = ['Reviewer findings, as the reviewer wrote them:']
        for finding in review['findings']:
            rows += quoted('reviewer', plain(finding), lines=20)
        text.append('\n'.join(rows))
    if review and review.get('findings_not_shown'):
        text.append('%d more reviewer findings were not shown.' % review['findings_not_shown'])
    if data.get('reason'):
        text.append('Reason: ' + plain(data['reason'], REASON_LIMIT, newlines=False))
    text.append('State: ' + data.get('outcome', 'held'))
    if 'repository' in data:
        text.append('Repository: %s, new branch %s' % (plain(data['repository'], newlines=False),
                                                      data.get('branch')))
    if 'changes' in data:
        changes = data['changes']
        rows = ['Files changed: %d' % len(changes)] + [
            '  file> +%d -%d  %s' % (c['added'], c['removed'], plain(c['path'], PATH_LIMIT, newlines=False))
            for c in changes[:FILES_SHOWN]]
        if len(changes) > FILES_SHOWN:
            rows.append('  (%d more files not shown; receipt.json lists them all)' % (len(changes) - FILES_SHOWN))
        text.append('\n'.join(rows))
    touched = data.get('check_dependencies') or []
    if touched:
        text.append(TOUCHED + ', '.join(plain(p, PATH_LIMIT, newlines=False) for p in touched[:FILES_SHOWN]) +
                    (' and %d more' % (len(touched) - FILES_SHOWN) if len(touched) > FILES_SHOWN else ''))
    if 'check_command' in data:
        check = data.get('check')
        line = 'Check `%s`: %s; at baseline: %s.' % (plain(data['check_command'], newlines=False),
                                                     check_line(check), check_line(data.get('baseline')))
        if check and check.get('identical_failure_before_and_after'):
            line += ' ' + IDENTICAL_FAILURE_NOTICE
        text.append(line)
    if review:
        count = len(review['findings']) + review.get('findings_not_shown', 0)
        text.append('Review: %s (%d finding%s%s).' % (review['verdict'], count, '' if count == 1 else 's',
                                                    ', shown above' if count else ''))
    text.append(data.get('review_notice') or review_notice(data))
    usage = data.get('usage') or {}
    complete = [u for u in usage.get('usage', []) if u.get('complete')]
    if usage.get('observed_units'):
        text.append('Usage: %s%d tokens reported by Claude Code (not a bill).' % (
            '' if complete and len(complete) == len(usage['usage']) else 'at least ', usage['observed_units']))
    elif 'usage' in data:
        text.append('Usage: not recorded.')
    if 'wall_seconds' in data:
        text.append('Time taken: %.1f seconds.' % data['wall_seconds'])
    text.append('Approval: %s. Delivery: %s.' % (data.get('approval', 'not_run'), data.get('delivery', 'not_run')))
    for key in ('build_termination', 'termination'):
        if data.get(key, {}).get('error'):
            text.append('Stop could not be confirmed: ' + plain(data[key]['error'], REASON_LIMIT, newlines=False))
        elif key in data and not data[key]['complete']:
            text.append('The process scan did not finish in time; other descendants are not confirmed dead.')
    for process in data.get('processes', []):
        text.append('Process %d (%s): %s.' % (process['pid'], process['stage'],
            'confirmed dead' if process['state'] == 'dead' else 'not confirmed dead'))
    text.append('This page and receipt contain folder paths from this computer. Check before sharing them.')
    return text


def awaiting_code(view):
    """A frozen, checked and reviewed result whose approval code was not typed (yet)."""
    record = view['records'].get(view['current']) if view['current'] else None
    return (record is not None and not view['stopped'] and
            view.get('journey', {}).get('approval') == 'not approved' and
            not record['approvals'] and not record['publications'])


def ask(input_fn, output, prompt):
    """End of input (Ctrl-D) is an empty answer: not approved."""
    try:
        return input_fn(prompt)
    except EOFError:
        output('')
        return ''


def approve_code(candidate_digest, destination, input_fn, interactive, output, warning=None, tries=3):
    """No CLI switch or pipe can substitute for terminal confirmation."""
    require(interactive, 'Final approval requires an interactive terminal; not approved.')
    short = candidate_digest.removeprefix('sha256:')[:8]
    output('Destination: %s\nCandidate: %s' % (plain(destination, newlines=False), short))
    if warning:
        output(warning)
    for left in range(tries - 1, -1, -1):
        try:
            answer = input_fn('Type %s to approve: ' % short)
        except EOFError:
            output('')
            return False
        if answer == short:
            return True
        if left:
            output('That is not the code. %d %s left.' % (left, 'try' if left == 1 else 'tries'))
    return False


class Journey:
    def __init__(self, options, *, tool_factory, input_fn=input, output=print,
                 interactive=False, licence=None, check_runner=run_check, launcher=None):
        self.options, self.tool_factory = options, tool_factory
        self.input, self.output, self.interactive = input_fn, output, interactive
        self.licence, self.check_runner = licence or Licence(), check_runner
        # Trusted in-process testing seam only; never supplied by CLI/file/environment.
        self.launcher = launcher
        self.service = self.limits = self.run_id = self.root = None
        self.started = time.monotonic()
        self.page_announced = False
        self.stopped_by = 'Ctrl-C'
        self.scripts = {}

    def interrupt(self, signum, frame):
        """SIGTERM and SIGHUP (closed terminal) take Ctrl-C's stop path."""
        self.stopped_by = {signal.SIGTERM: 'SIGTERM', signal.SIGHUP: 'a closed terminal (SIGHUP)'}.get(
            signum, 'Ctrl-C')
        raise KeyboardInterrupt()

    @contextmanager
    def finishing(self):
        """A second Ctrl-C (or SIGTERM/SIGHUP) cannot cut the stop and receipt short."""
        previous = {s: signal.signal(s, signal.SIG_IGN) for s in STOP_SIGNALS}
        try:
            yield
        finally:
            for s, handler in previous.items():
                signal.signal(s, handler)

    def page(self):
        # Both receipts and the page are disposable exports of the same view.
        try:
            view = self.service.view(self.run_id)
            self.root.joinpath('receipt.json').write_text(json.dumps(view, indent=2) + '\n')
            self.root.joinpath('receipt.md').write_text('\n\n'.join(summary(
                self.run_id, view.get('journey', {}))) + '\n')
            path = write_page(self.service, self.run_id, self.root)
        except (Refused, OSError, ValueError) as exc:
            self.output('Run page unavailable: ' + plain(exc, REASON_LIMIT, newlines=False))
            return
        if not self.page_announced:
            self.output('Run page: ' + str(path))
            self.page_announced = True

    def note(self, **fields):
        if fields.get('reason'):
            # Reasons can carry tool, check or repository error text.
            fields['reason'] = plain(fields['reason'], REASON_LIMIT, newlines=False)
        with self.service.journal.change('journey') as state:
            state['runs'][self.run_id].setdefault('journey', {}).update(fields)
        self.page()

    def receipt(self):
        started = self.service.view(self.run_id).get('journey', {}).get('started_at')
        elapsed = time.time() - started if started is not None else time.monotonic() - self.started
        self.note(wall_seconds=round(max(0, elapsed), 3), usage=self.limits.view(self.run_id),
                  review_notice=review_notice(self.service.view(self.run_id).get('journey', {})))
        view = self.service.view(self.run_id)
        data = view.get('journey', {})
        text = summary(self.run_id, data)
        self.root.joinpath('receipt.json').write_text(json.dumps(view, indent=2) + '\n')
        self.root.joinpath('receipt.md').write_text('\n\n'.join(text) + '\n')
        self.output('\n'.join(text))
        self.output('Receipt: ' + str(self.root / 'receipt.md'))
        return view

    def track(self, pid, stage):
        row = processes().get(pid)
        require(row is not None, 'Process identity unavailable: termination unconfirmed.')
        with self.service.journal.change('journey_process') as state:
            data = state['runs'][self.run_id].setdefault('journey', {})
            data.setdefault('processes', []).append(dict(pid=pid, start=row['start'],
                                                        stage=stage, state='running'))

    def record_termination(self, result, stage='cleanup', key='termination'):
        with self.service.journal.change('journey_termination') as state:
            data = state['runs'][self.run_id].setdefault('journey', {})
            for process in data.get('processes', []):
                for observed in result['processes']:
                    if (process['pid'], process['start']) == (observed['pid'], observed['start']):
                        process['state'] = observed['state']
            identities = {(p['pid'], p['start']) for p in data.get('processes', [])}
            for observed in result['processes']:
                if (observed['pid'], observed['start']) not in identities:
                    data.setdefault('processes', []).append(dict(observed, stage=stage))
            data[key] = result
        self.page()

    def fence(self, reason):
        self.service.revoke('customer', self.run_id, stop=True)
        self.note(outcome='held', reason=reason)

    def stop(self, reason):
        self.fence(reason)
        try:
            # LIM's builder sweep; its identities go in the same report as checks/reviewer.
            self.record_termination(self.limits.terminate('control_service', self.run_id),
                                    stage='build', key='build_termination')
        except (Refused, OSError) as exc:
            reason += '; termination unconfirmed: ' + str(exc)
        data = self.service.view(self.run_id).get('journey', {})
        known = {p['pid']: p['start'] for p in data.get('processes', []) if p['state'] != 'dead'}
        if known:
            try:
                self.record_termination(kill_trees(known, 5))
            except (Refused, OSError) as exc:
                self.note(termination=dict(complete=False, error=str(exc),
                    processes=[dict(pid=p, start=s, state='alive') for p, s in known.items()]))
                reason += '; check/reviewer termination unconfirmed: ' + str(exc)
        self.note(outcome='held', reason=reason)

    def check(self, command, manifest, folder, seconds):
        workspace = restore(manifest, self.root / folder)
        if self.check_runner is run_check:
            return run_check(command, workspace, seconds,
                on_start=lambda pid: self.track(pid, folder), on_abort=self.fence,
                on_finish=self.record_termination)
        return self.check_runner(command, workspace, seconds)

    def launch_reviewer(self, launch, workspace, prompt, seconds):
        """Fence a terminal SIGINT before RV-A handles its own process cleanup."""
        def started(pid):
            # Do not reenter SQLite from a signal while recording the new identity.
            mask = signal.pthread_sigmask(signal.SIG_BLOCK, set(STOP_SIGNALS))
            try:
                self.track(pid, 'review')
            finally:
                signal.pthread_sigmask(signal.SIG_SETMASK, mask)

        def interrupted(signum, frame):
            try:
                self.interrupt(signum, frame)
            except KeyboardInterrupt:
                self.fence('Stopped during review by %s.' % self.stopped_by)
                raise

        previous = {s: signal.signal(s, interrupted) for s in STOP_SIGNALS}
        try:
            return launch('reviewer', workspace, prompt, seconds, on_start=started)
        finally:
            for s, handler in previous.items():
                signal.signal(s, handler)

    def publisher(self):
        folder = self.root / 'publisher'
        folder.mkdir(exist_ok=True)
        repository = self.service.view(self.run_id)['journey']['repository']
        return endpoint(Publisher(folder, {'local': repository}))

    def restart(self):
        view = self.service.view(self.run_id)
        operations = [p for r in view['records'].values() for p in r['publications']]
        if not operations:
            if awaiting_code(view):
                self.output('Run %s: the same result is waiting for your approval code; '
                            'nothing is rebuilt.' % self.run_id)
                self.deliver(self.service.record(view))
                return
            self.stop('Existing run held after restart; no build or delivery was repeated. '
                      'Add --new to start a fresh run of the same brief.')
            return
        adapter = self.publisher()
        for op in operations:
            if op['outcome'] not in {'succeeded', 'failed'}:
                self.service.reconcile('control_service', self.run_id, op['id'], adapter)
        view = self.service.view(self.run_id)
        operations = [p for r in view['records'].values() for p in r['publications']]
        delivered = any(p['outcome'] == 'succeeded' and adapter.query(p['id'], p['body']) == 'landed'
                        for p in operations)
        self.note(outcome='delivered' if delivered else 'held',
                  delivery='delivered' if delivered else 'held',
                  reason='Previous delivery reconciled; no action was resent.' if delivered else
                         'Previous delivery reconciled or held; no action was resent.')
        if delivered:
            data = self.service.view(self.run_id)['journey']
            self.output('Already delivered: branch %s in %s. Nothing was sent again. '
                        'Add --new to start a fresh run of the same brief.' % (
                            data['branch'], plain(data['repository'], newlines=False)))
            self.instructions()

    def instructions(self):
        data = self.service.view(self.run_id)['journey']
        prefix = 'git -C %s push origin %s' % (shlex.quote(data['repository']), shlex.quote(data['branch']))
        self.output(plain('Run these yourself to push and open a pull request:\n' + prefix + '\n' +
                          'cd %s && gh pr create --head %s' % (
                              shlex.quote(data['repository']), shlex.quote(data['branch']))))

    def requests(self, key):
        """Runs of one request, oldest first: the first has task `key`, later --new runs number on."""
        runs, found = list(self.service.journal.read()['runs'].values()), []
        while True:
            task = key if not found else digest(dict(request=key, number=len(found)))
            match = [r for r in runs if r['task'] == task]
            if not match:
                return found
            found.append(match[0])

    def guarded(self, step, prefix=''):
        """Every stop or refusal after the run exists ends in a recorded hold and a receipt."""
        try:
            step()
        except KeyboardInterrupt:
            with self.finishing():
                self.stop('Stopped by %s. Delivery, if already admitted, requires reconciliation.'
                          % self.stopped_by)
                if self.service.unresolved(self.service.view(self.run_id)):
                    self.restart()
                return self.receipt()
        except (Refused, OSError, ValueError, subprocess.SubprocessError) as exc:
            reason = ('The build exceeded the candidate limit: 4 MiB and 1000 files. Nothing was delivered.'
                      if str(exc) == 'artifact size limit' else prefix + str(exc))
            self.stop(reason)
        return self.receipt()

    def make_root(self, runs, key):
        # A fresh folder per attempt: a refused or stopped earlier attempt never blocks this one.
        self.root = Path(tempfile.mkdtemp(prefix=key[7:23] + '-', dir=runs))
        return self.root

    def run(self):
        previous = {s: signal.signal(s, self.interrupt) for s in (signal.SIGTERM, signal.SIGHUP)}
        try:
            return self.journey()
        finally:
            for s, handler in previous.items():
                signal.signal(s, handler)

    def journey(self):
        opts = self.options
        shipped = STUDIO / 'example/project'
        repository = shipped if opts.command == 'demo' else Path(opts.repository).absolute()
        # The gate precedes reads of brief files, directory creation and tool discovery/version.
        gate = self.licence.gate(repository)
        require(gate.ok, gate.reason)
        brief = (STUDIO / 'example/brief.md').read_text() if opts.command == 'demo' else (
            Path(opts.brief_file).read_text() if opts.brief_file else opts.brief)
        require(isinstance(brief, str) and brief.strip(), 'A nonempty brief is required.')
        seconds = opts.time_limit * 60
        require(seconds > 0 and opts.model == 'sonnet', 'Positive time limit and sonnet required.')
        runs = Path(opts.runs_dir).expanduser().resolve()
        require(not runs.is_relative_to(repository.resolve()), 'Runs directory must be outside the repository.')
        runs.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.service = Service(runs / 'journal.sqlite', SESSIONS)
        self.limits = Limits(self.service)
        key = digest(dict(source=str(repository), brief=brief, check=opts.check,
                          seconds=seconds, model=opts.model))
        found = self.requests(key)
        if getattr(opts, 'new', False):
            # Exactly once: an unconfirmed delivery is reconciled by a plain rerun first.
            require(not any(self.service.unresolved(r) for r in found),
                    'An earlier run of this brief has a delivery that is not confirmed yet. Run the same '
                    'command without --new first to check what happened.')
        elif found and 'plan_approver' in found[-1]:
            # A plan was approved, so a build may exist: resume or hold, never rebuild.
            self.run_id = found[-1]['id']
            self.root = Path(found[-1].get('journey', {}).get('run_folder', runs / key[7:23]))
            return self.guarded(self.restart, prefix='Restart held: ')
        if found and any(p['state'] != 'dead' for p in found[-1].get('journey', {}).get('processes', [])):
            # Nothing was built, but end any recorded check before starting afresh.
            self.run_id = found[-1]['id']
            self.root = Path(found[-1]['journey']['run_folder'])
            self.stop('Replaced by a new run; nothing had been built.')
            self.run_id = self.root = None
        task = key if not found else digest(dict(request=key, number=len(found)))
        if opts.command == 'demo':
            repository = example_copy(shipped, self.make_root(runs, key) / 'repository')
        try:
            observation = inspect_tracked(repository, 'project_local')
        except OSError as exc:
            if exc.filename and Path(exc.filename).name == 'package.json':
                raise Refused('The package.json at the top of the repository could not be read. '
                              'Check that you have permission to read it and try again.') from None
            raise
        with self.service.journal.change('journey_intake') as state:
            state.setdefault('journey_intakes', []).append(observation)
        if observation['reasons'] == ['Missing or invalid root package.json dependency maps.']:
            with metadata_copy(repository) as metadata:
                names = intake.git(metadata, 'ls-tree', '--name-only', 'HEAD').decode().splitlines()
            reason = ('This does not look like a JavaScript project: there is no package.json at the top '
                      'of the repository. Vibe Control currently works on JavaScript and TypeScript projects only.'
                      if 'package.json' not in names else
                      'The package.json at the top of the repository cannot be read as a JavaScript project. '
                      'Check that it contains valid JSON and that its dependency lists are objects.')
            raise Refused(reason)
        require(observation['status'] == 'compatible', '; '.join(observation['reasons']))
        require(observation['working_tree'] == 'clean',
                'Repository must be clean; working tree is ' + observation['working_tree'])
        require_build_room(observation)
        manifest = base_manifest(repository, observation)
        package = next((e for e in manifest['entries'] if e['path'] == 'package.json'), None)
        package = json.loads(bytes.fromhex(package['bytes_hex'])) if package else {}
        command = opts.check or ('node --test' if opts.command == 'demo' else None)
        if command is None and isinstance(package.get('scripts'), dict) and package['scripts'].get('test'):
            command = 'npm test'
        require(command, '--check is required when package.json has no test script.')
        # The check is bound to the BASE's scripts; a candidate that edits them is held.
        base_scripts = package_scripts(manifest)
        self.scripts = {name: base_scripts.get(name) for name in script_runs(command, base_scripts)}
        tool = self.tool_factory()
        require(type(tool) is ClaudeCode, 'RV-A ClaudeCode tool required')
        if self.launcher is not None:
            tool.launch = self.launcher
        rule = dict(definition_digest=digest(dict(command=command, scripts=self.scripts,
            acceptance='passes-or-explicitly-consented-identical-started-failure-v2', base_digest=manifest['base_digest'])),
            environment_digest=digest(
            dict(platform=sys.platform, check='local-user-shell-v1')))
        policy = dict(version='j1-v2', independent_review=False, checks={'command': rule}, review=dict(
            definition_digest=tool.tool_digest('reviewer'), environment_digest=rule['environment_digest']))
        workspace = restore(manifest, (self.root or self.make_root(runs, key)) / 'workspace')
        self.run_id = self.service.create('control_service', project='project_local', task=task,
            brief=brief, plan_revision=1, policy=policy, workspace=workspace,
            base_digest=manifest['base_digest'], tool_digest=tool.tool_digest('builder'),
            time_limit_seconds=seconds)
        self.note(receipt_version='j1-v3', run_folder=str(self.root), repository=str(repository),
                  brief=plain(brief, BRIEF_LIMIT), intake=observation, check_command=plain(command),
                  check_scripts={plain(n, 100, newlines=False): None if t is None else plain(t, 500, newlines=False)
                                 for n, t in self.scripts.items()},
                  tool_version=tool.version, branch='vibe/' + self.run_id[:8], outcome='running',
                  review_notice=REVIEW_PENDING, approval='not_run', delivery='not_run', started_at=time.time())
        self.limits.set_limits('customer', self.run_id, max_units=2 * UNIT_RESERVATION,
                               max_turns=2, max_seconds=seconds)
        return self.guarded(lambda: self.execute(tool, brief, manifest, command, seconds))

    def execute(self, tool, brief, base, command, seconds):
        self.output('Working from commit %s. Untracked and ignored files (for example node_modules) '
                    'are not included.' % self.service.view(self.run_id)['journey']['intake']['baseline_commit'][:8])
        self.output(DEPENDENCY_HINT)
        self.output('The check command runs as you, on this machine, unsandboxed.')
        baseline = self.check(command, base, 'baseline', seconds)
        self.note(baseline=recorded_check(baseline))
        output = plain(baseline.get('output', ''), OUTPUT_LIMIT)
        self.output('\n'.join(['Baseline check: %s.' % check_line(baseline)] +
                              (['Its output, as the check printed it:'] + quoted('check', output) if output else [])))
        require(not baseline.get('timed_out'), 'Baseline time limit reached; task stopped.')
        if not baseline.get('passed') and check_could_not_start(baseline):
            self.note(outcome='held', reason='Baseline check could not start. ' + DEPENDENCY_HINT)
            self.output('Baseline check could not start; no build was started.')
            self.output(DEPENDENCY_HINT)
            return
        if not baseline.get('passed'):
            self.output(FAILING_BASELINE_NOTICE)
            if self.options.yes_plan and not self.options.allow_failing_baseline:
                self.note(outcome='held', reason='Failing baseline: --yes-plan requires --allow-failing-baseline; no build was started.')
                return
        view = self.service.view(self.run_id)
        data = view['journey']
        # Untrusted text first, behind markers; the plan's own facts follow, before the question.
        lines = ['Brief, as given:'] + quoted('brief', data['brief'])
        if self.scripts:
            lines.append('Scripts this check runs, read from package.json at commit %s:'
                         % data['intake']['baseline_commit'][:8])
            lines += ['  script> %s: %s' % (name, '(not defined)' if text is None else text)
                      for name, text in data['check_scripts'].items()]
        lines += ['Time limit: %s minutes' % self.options.time_limit,
                  'Tool: Claude Code %s (sonnet)' % tool.version,
                  'Check: ' + data['check_command'] + (
                      ' (it runs the package.json scripts listed above, as they are now; if the change '
                      'edits them, the check is held)' if self.scripts else ''),
                  'Destination: %s branch %s' % (plain(data['repository'], newlines=False), data['branch']),
                  'Tool digest: ' + view['plan']['tool_digest']]
        self.output('\n'.join(lines))
        self.output(REVIEW_PENDING)
        self.output(LIMITS_LINE)
        if not self.options.yes_plan and ask(self.input, self.output, 'Approve plan? (y/N) ').lower() != 'y':
            self.note(outcome='not approved', reason='Plan refused; no tool build was started. '
                      'Run the same command again to be asked again.')
            return
        self.service.approve_plan('customer', self.run_id, digest(view['plan']))
        self.page()
        execution_started = time.monotonic()
        launch = tool.launch

        def reserved_launch(role, workspace, prompt, timeout_seconds, **kwargs):
            if role == 'builder':
                # Both turns are reserved under the live lease, before either tool is started.
                for name in ('build', 'review'):
                    self.limits.reserve('control_service', self.run_id, name, UNIT_RESERVATION)
            self.page()
            result = (self.launch_reviewer(launch, workspace, prompt, timeout_seconds) if role == 'reviewer'
                      else launch(role, workspace, prompt, timeout_seconds, **kwargs))
            if role == 'reviewer':
                if result[1].get('timed_out'):
                    self.stop('Review time limit reached; no delivery was started.')
                known = {p['pid']: p['start'] for p in self.service.view(self.run_id)['journey'].get(
                    'processes', []) if p['stage'] == 'review' and p['state'] != 'dead'}
                if known:
                    # RV-A's (capture, details) is returned unchanged; this sweep is evidence only.
                    swept = kill_trees(known, 5)
                    self.record_termination(swept)
                    require(swept['complete'] and all(p['state'] == 'dead' for p in swept['processes']),
                            'Reviewer termination unconfirmed; delivery held.')
            return result

        tool.launch = reserved_launch
        agent = ClaudeCodeAgent(tool, brief, seconds, on_start=lambda pid: self.limits.register(
            'control_service', self.run_id, pid))
        try:
            self.service.dispatch('control_service', self.run_id, agent)
        finally:
            if agent.capture is not None:
                self.limits.settle('control_service', self.run_id, 'build', agent.capture)
                self.note(build=dict(capture=asdict(agent.capture), details=recorded_details(agent.details)))
                if agent.details.get('timed_out'):
                    self.stop('Build time limit reached. Nothing was published.')
        view = self.service.view(self.run_id)
        if self.limits._known(self.run_id):
            result = self.limits.terminate('control_service', self.run_id)
            require(result['complete'] and all(p['state'] == 'dead' for p in result['processes']),
                    'Builder termination unconfirmed; delivery held.')
        record = self.service.record(view)
        changes = changed_files(base, record['manifest'])
        self.note(changes=[dict(c, path=plain(c['path'], PATH_LIMIT, newlines=False)) for c in changes],
                  check_dependencies=[plain(c['path'], PATH_LIMIT, newlines=False)
                                      for c in changes if check_may_depend(c['path'])])
        remaining = seconds - (time.monotonic() - execution_started)
        if remaining <= 0:
            self.stop('Task time limit reached. Nothing was published.')
            return
        if self.scripts and {n: package_scripts(record['manifest']).get(n) for n in self.scripts} != self.scripts:
            # Never run the candidate's own edited script as the check.
            self.note(check=dict(passed=False, returncode=None, timed_out=False, output='', wall_seconds=0,
                                 held=SCRIPT_CHANGED, could_not_start=False,
                                 identical_failure_before_and_after=False))
            self.service.assess('checker', self.run_id, 'check', 'command',
                                self.service.binding(view, record, 'check', 'command'), 'held')
            self.note(outcome='held', reason=SCRIPT_CHANGED + ', so the check was not run and this change '
                      'cannot be approved. To check it with a command you choose, run again with '
                      '--check "<command>".')
            return
        check = self.check(command, record['manifest'], 'checks', remaining)
        inherited = (not check['passed'] and not baseline['passed'] and
                     not check.get('timed_out') and not baseline.get('timed_out') and
                     not check_could_not_start(check) and not check_could_not_start(baseline) and
                     type(check['returncode']) is int and check['returncode'] != 0 and
                     check['returncode'] == baseline['returncode'] and check['output'] == baseline['output'])
        self.note(check=dict(recorded_check(check), identical_failure_before_and_after=inherited))
        if inherited:
            self.output(IDENTICAL_FAILURE_NOTICE)
        # The approved definition measures regression against the recorded immutable base.
        self.service.assess('checker', self.run_id, 'check', 'command',
            self.service.binding(view, record, 'check', 'command'),
            'held' if check.get('timed_out') else 'passed' if check['passed'] or inherited else 'failed')
        self.page()
        require(not check.get('timed_out'), 'Candidate check time limit reached; task stopped.')
        remaining = seconds - (time.monotonic() - execution_started)
        if remaining <= 0:
            self.stop('Task time limit reached before review. Nothing was published.')
            return
        review = tool.review(record['manifest'], brief, remaining)
        self.limits.settle('control_service', self.run_id, 'review', Capture(**review['capture']))
        self.note(review=recorded_review(review), usage=self.limits.view(self.run_id))
        self.note(review_notice=review_notice(self.service.view(self.run_id)['journey']))
        self.service.assess('reviewer', self.run_id, 'review', 'review',
                self.service.binding(view, record, 'review', 'review'),
                {'approve': 'passed', 'reject': 'failed'}.get(review['verdict'], 'held'))
        self.page()
        if not (check['passed'] or inherited) or review['verdict'] != 'approve':
            self.note(outcome='held', reason='Checks or review did not pass; not approved.')
            return
        require(not self.service.view(self.run_id)['stopped'], 'Task stopped; not approved.')
        self.deliver(record)

    def deliver(self, record):
        view = self.service.view(self.run_id)
        data = view['journey']
        # The base is the commit recorded at intake (the candidate's build base), never a later HEAD.
        observed = lambda: push_destination(data['repository'], data['branch'],
                                            data['intake']['branch'], data['intake']['baseline_commit'])
        destination = observed()
        shown = self.service.display('customer', self.run_id, 'push', destination)
        self.note(outcome='awaiting approval', destination=destination)
        self.receipt()
        try:
            approved = approve_code(record['candidate']['digest'],
                data['repository'] + ' ' + destination['ref'], self.input, self.interactive, self.output,
                warning=IDENTICAL_FAILURE_NOTICE if data.get('check', {}).get('identical_failure_before_and_after') else None)
        except Refused as exc:
            self.note(outcome='not approved', approval='not approved', reason=str(exc))
            return
        if not approved:
            self.note(outcome='not approved', approval='not approved', reason=NOT_TYPED)
            return
        # Observe again after the (possibly long) question; the publisher checks once more before pushing.
        require(observed() == destination, MOVED)
        approval =self.service.confirm('customer', self.run_id, shown['reference'], shown['displayed'])
        self.note(approval='approved')
        operation = self.service.admit('customer', self.run_id, 'deliver-' + self.run_id,
                                       approval, shown['displayed'])
        self.page()
        try:
            self.service.fake_publish('control_service', self.run_id, operation['id'], self.publisher())
        except Refused as exc:
            raise Refused('Delivery not confirmed (%s). The run is held; run the same command '
                          'again to check what happened.' % exc) from None
        op = self.service.view(self.run_id)['records'][record['candidate']['id']]['publications'][-1]
        require(op['outcome'] == 'succeeded', 'Delivery outcome unresolved; restart to reconcile.')
        self.note(outcome='delivered', delivery='delivered')
        self.instructions()
