"""Data-only repository copies, using ON's bounded metadata reader and EX1 manifests."""
import hashlib
import os
import stat
import struct
from pathlib import Path
import tempfile
import zlib
from contextlib import contextmanager

import intake
from artifacts import capture, digest, git_objects, require, restore, safe_path, validate_manifest


def example_copy(shipped, destination):
    """Make one initial commit with a fixed identity; no Git write commands/config."""
    manifest = capture(shipped, digest('Vibe Control example v1'))
    root = restore(manifest, destination)
    mapping, objects = git_objects(manifest)
    identity = b'Vibe Control Example <example@example.invalid> 0 +0000'
    commit = (b'tree ' + mapping['git_tree_oid'].encode() + b'\nauthor ' + identity +
              b'\ncommitter ' + identity + b'\n\nBuilt-in example baseline\n')
    raw = b'commit %d\0' % len(commit) + commit
    oid = hashlib.sha1(raw).hexdigest()
    objects[oid] = raw
    for name, data in objects.items():
        target = root / '.git/objects' / name[:2] / name[2:]
        target.parent.mkdir(exist_ok=True)
        target.write_bytes(zlib.compress(data))
    (root / '.git/refs/heads').mkdir()
    (root / '.git/refs/heads/main').write_text(oid + '\n')
    (root / '.git/HEAD').write_text('ref: refs/heads/main\n')
    # Git index v2, using the same data-only encoding as ON's fixture generator.
    index = b'DIRC' + struct.pack('>II', 2, len(manifest['entries']))
    for entry in manifest['entries']:
        data = bytes.fromhex(entry['bytes_hex'])
        blob = hashlib.sha1(b'blob %d\0' % len(data) + data).digest()
        name = entry['path'].encode('utf-8')
        row = struct.pack('>10I20sH', 0, 0, 0, 0, 0, 0, int(entry['mode'], 8),
                          0, 0, len(data), blob, min(len(name), 0xfff)) + name + b'\0'
        index += row + b'\0' * (-len(row) % 8)
    (root / '.git/index').write_bytes(index + hashlib.sha1(index).digest())
    return root


@contextmanager
def metadata_copy(repository):
    """Reuse ON's metadata boundary for both base import and destination observation."""
    with tempfile.TemporaryDirectory(prefix='vibe-base-') as folder:
        metadata = Path(folder) / 'metadata'
        metadata.mkdir()
        # ON rejects linked parents. Open the path a component at a time here too.
        fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
        try:
            for part in Path(repository).parts[1:]:
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                os.close(fd)
                fd = child
            require(stat.S_ISDIR(os.stat('.git', dir_fd=fd, follow_symlinks=False).st_mode),
                    'Linked git worktrees are not supported; run it from the main checkout.')
            intake.snapshot_git(fd, metadata)
        finally:
            os.close(fd)
        yield metadata


MOVED = ('Your repository changed since this run started (checked-out branch or its latest '
         'commit moved). Nothing was delivered; the run is held.')


def push_destination(repository, branch, intake_branch, intake_base):
    """Bind delivery to the commit the candidate was built on, as recorded at intake."""
    ref = 'refs/heads/' + branch
    with metadata_copy(repository) as metadata:
        current_branch, current_base = intake.baseline(metadata)
        require((current_branch, current_base) == (intake_branch, intake_base), MOVED)
        refs = intake.git(metadata, 'for-each-ref', '--format=%(refname)', ref).decode().splitlines()
        require(ref not in refs, 'Destination branch already exists; not approved.')
    return dict(kind='push', repository='local', ref=ref,
                expected_remote_digest=digest(dict(ref=ref, head=None, base=intake_base)))


# Match EX1's existing import ceiling.
BASE_BYTE_LIMIT = 4 * 1024 * 1024
SIZE_MESSAGE = 'Repository exceeds the journey limit: 4 MiB of tracked files and 1000 files.'


def inspect_tracked(repository, project_id):
    """Inspect only HEAD/index paths; never list or open other workspace entries."""
    root = Path(repository).absolute()
    with metadata_copy(root) as metadata:
        branch, commit = intake.baseline(metadata)
        require(commit is not None, 'Repository needs a committed base.')
        paths, expected = intake.listed_paths(metadata, commit)
        require(len(paths) <= 1000, SIZE_MESSAGE)
        # Reject staged paths before opening them: they may point at untracked data.
        staged = (metadata / 'index').exists() and intake.git(
            metadata, 'diff-index', '--cached', '--raw', '--no-renames',
            '--no-ext-diff', '--no-textconv', commit, '--')
        require(not staged, 'Repository must be clean: staged changes are present.')
        files, total = {}, 0
        fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
        try:
            for part in root.parts[1:]:
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                os.close(fd)
                fd = child
            for path in sorted(paths):
                safe_path(path)
                parent = os.dup(fd)
                try:
                    parts = path.split('/')
                    for part in parts[:-1]:
                        child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
                        os.close(parent)
                        parent = child
                    info = os.stat(parts[-1], dir_fd=parent, follow_symlinks=False)
                    require(stat.S_ISREG(info.st_mode), 'Tracked files must be regular files.')
                    total += info.st_size
                    require(total <= BASE_BYTE_LIMIT, SIZE_MESSAGE)
                    files[path] = (intake.read_file(parent, parts[-1], [0]), bool(info.st_mode & 0o111))
                except FileNotFoundError:
                    raise ValueError('Repository must be clean: tracked file deleted.') from None
                finally:
                    os.close(parent)
        finally:
            os.close(fd)
        clean = intake.working_tree(metadata, commit, files, expected, set(), False)
        require(clean == 'clean', 'Repository must be clean: tracked files are modified.')
        compatible, stack, reasons = intake.compatibility(files)
        return dict(project=dict(id=project_id), source=dict(kind='local', path=str(root)),
                    branch=branch, baseline_commit=commit, working_tree=clean,
                    compatible=compatible, status='compatible' if compatible else 'incompatible',
                    stack=stack, reasons=reasons, notes=[],
                    tracked_files=len(paths), tracked_bytes=total)


def require_build_room(observation):
    # Keep the import ceiling; reserve a little room for the requested edits.
    require(observation['tracked_files'] <= 1000 - 16 and
            observation['tracked_bytes'] <= BASE_BYTE_LIMIT - 64 * 1024,
            'Not enough room for edits: the candidate limit is 4 MiB and 1000 files. '
            'Keep at least 64 KiB and 16 files of room before starting a build. Nothing was delivered.')


def base_manifest(repository, observation):
    """Read the observed commit, never build from mutable working-directory bytes."""
    with metadata_copy(repository) as metadata:
        branch, commit = intake.baseline(metadata)
        require(commit is not None and commit == observation['baseline_commit'] and
                branch == observation['branch'], 'repository HEAD changed during intake')
        entries, total = [], 0
        for row in intake.git(metadata, 'ls-tree', '-rz', '--full-tree', commit).split(b'\0'):
            if not row:
                continue
            info, name = row.split(b'\t', 1)
            mode, kind, oid = info.split()
            require(kind == b'blob' and mode in (b'100644', b'100755'),
                    'base contains unsupported file type')
            size = int(intake.git(metadata, 'cat-file', '-s', oid.decode()).strip())
            total += size
            require(len(entries) < 1000 and total <= BASE_BYTE_LIMIT, SIZE_MESSAGE)
            data = intake.git(metadata, 'cat-file', 'blob', oid.decode())
            entries.append(dict(path=name.decode('utf-8'), type='file', mode=mode.decode(),
                                bytes_hex=data.hex()))
        manifest = validate_manifest(dict(base_digest=digest(dict(git_commit=commit)),
                                          entries=sorted(entries, key=lambda e: e['path'])))
    current = inspect_tracked(repository, 'project_local')
    require(all(current[key] == observation[key] for key in
                ('branch', 'baseline_commit', 'working_tree')), 'repository changed during intake')
    return manifest
