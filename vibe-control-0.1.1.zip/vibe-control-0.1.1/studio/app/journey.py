"""J1 orchestration over EX1's journal and frozen-candidate publisher."""
from contextlib import contextmanager
from dataclasses import asdict
import difflib
import json
import os
import re
from pathlib import Path
import signal
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

STUDIO = Path(__file__).resolve().parents[1]
for _folder in ('execution', 'providers', 'limits', 'onboarding', 'licence', 'publisher'):
    _path = str(STUDIO / _folder)
    if _path not in sys.path:
        sys.path.insert(0, _path)

from adapters import Capture
from artifacts import Refused, digest, require, restore
from claude_code import ClaudeCode, ClaudeCodeAgent, FAMILY, _exited
from execution import Service
from licence import Licence
from limits import Limits, kill_trees, processes
from repositories import MOVED, base_manifest, example_copy, inspect_tracked, metadata_copy, push_destination, require_build_room
from publisher import Publisher, endpoint
import intake
from page import plain, write_page

SESSIONS = {role: dict(id='local-' + role, role=role, projects=['project_local'], family=family)
            for role, family in [('control_service', 'local-service'), ('customer', 'local-user'),
                                 ('checker', 'local-check'), ('reviewer', FAMILY)]}
SESSIONS['task_agent'] = dict(id='local-builder', role='task_agent',
                             projects=['project_local'], family=FAMILY)
DEPENDENCY_HINT = ('Checks run in a clean copy; if your tests need dependencies, include the install '
                   'step, for example --check "npm ci && npm test"')
FAILING_BASELINE_NOTICE = (
    'Your check already fails before any change. If you continue, the check can only tell you '
    'whether the change made things different, not that it works. Answer N to stop.')
DEMO_BASELINE_NOTICE = (
    'This is expected: the example starts with two failing tests on purpose, and making them pass '
    'is the job. Answering y is the normal next step.')
IDENTICAL_FAILURE_NOTICE = ('Check failed before and after the change, identically. '
                            'It does not show the change works.')


def check_could_not_start(result):
    """Command availability, not a list of particular test tools or ordinary failures."""
    if result.get('returncode') in (126, 127):
        return True
    output = result.get('output', '')
    if re.search(r"^(?:(?:/?(?:bin/)?(?:sh|bash|zsh)): (?:line \d+: |\d+: )?)?"
                 r"[A-Za-z_./~][^\s:]*: (?:command )?not found[ \t]*$|"
                 r"^(?:/?(?:bin/)?(?:sh|bash|zsh)): command not found: [^\s:]+[ \t]*$|npm[^\n]*missing script",
                 output, re.I | re.M):
        return True
    if re.search(r"(?:^|\n)(?:\S*sh|(?:/usr/bin/)?env):[^\n]*No such file or directory", output, re.I):
        return True
    if re.search(r"doesn't seem to have been installed|"
                 r"Local package\.json exists, but node_modules missing",
                 output, re.I):
        return True
    packages = re.findall(r"Cannot find (?:module|package) ['\"]([^'\"]+)['\"]", output, re.I)
    return any(not name.startswith(('.', '/', '\\')) for name in packages)


ANSI = re.compile(r'\x1b\[[0-9;?]*[ -/]*[@-~]')
NO_TESTS = 'no tests ran'
COUNT_NOT_SEEN = 'passed, number of tests not seen'
NO_TESTS_REASON = ('The check ran no tests, so it does not show the change works; not approved. '
                   'Run again with --check "<command>" naming a command that runs your tests.')
TESTS_UNCLEAR = 'held (the test summary did not show which tests ran)'
TESTS_UNCLEAR_REASON = ('The check output did not establish which tests ran, '
                        'so it does not show the change works; not approved.')
NO_TESTS_BASELINE_NOTICE = (
    'Your check did not show any test running before any change. Unless the change adds tests, '
    'the check cannot show that it works, and a check that shows no test running is never approved. '
    'Answer N to stop.')
COUNT_NOT_SEEN_NOTICE = ('The check passed, but its output did not show how many tests ran. '
                         'Look at the check output before you approve.')


def ran(parts, total):
    """Tests whose bodies ran (passed or failed); skipped, todo and pending ones did not.

    A total with no breakdown counts only when it is zero: a positive total alone does not
    show that anything ran.
    """
    seen = {}
    for number, word in parts:
        seen[word] = seen.get(word, 0) + int(number)
    if seen:
        return seen.get('passed', 0) + seen.get('failed', 0)
    return 0 if total == 0 else None


def summaries(output, workspace=None):
    """One entry per recognised runner summary: the tests it shows ran, or None when the
    summary is recognised but does not show which tests ran (a positive total alone).

    Recognised: node --test (TAP `# tests N`, spec `ℹ tests N`, then its pass and fail
    lines), Jest (`Tests: ... N total`, `No tests found`), Vitest (`Tests  ... (N)`,
    `No test files found`) and Mocha (`N passing` plus `N failing`). Skipped, todo and
    pending tests did not run and are not counted.
    """
    text = ANSI.sub('', output or '').replace('\r\n', '\n')
    counts = []
    # node --test: a block of `# key N` (TAP) or `ℹ key N` (spec) lines starting at `tests`.
    previous_end = 0
    for block in re.finditer(r'^([#\u2139]) tests (\d+)[ \t]*\n((?:\1 [a-z_]+ [\d.]+[ \t]*(?:\n|$))*)',
                             text + '\n', re.M):
        keys = dict(re.findall(r'^. ([a-z_]+) ([\d.]+)', block.group(3), re.M))
        total = int(block.group(2))
        if 'pass' in keys and 'fail' in keys:
            count = int(keys['pass']) + int(keys['fail'])
            if workspace is not None:
                # Script launchers such as npm may run Node indirectly. A passing file
                # wrapper has the same printed name as a real case named for its file.
                # Only the direct runner below can positively distinguish those cases.
                rows = text[previous_end:block.start()]
                pattern = (r'^ok [0-9]+ - (.+)$' if block.group(1) == '#' else
                           r'^✔ (.+) \([0-9.]+ms\)[ \t]*$')
                wrappers = sum(_possible_node_file(name, workspace)
                               for name in re.findall(pattern, rows, re.M))
                if wrappers:
                    count = max(0, count - wrappers)
                    if not count:
                        counts.append(None)
            counts.append(count)
        else:
            counts.append(0 if total == 0 else None)
        previous_end = block.end()
    word = r'(\d+) (passed|failed|skipped|todo|pending)'
    # Jest: `Tests:       1 skipped, 4 passed, 5 total`
    for line, total in re.findall(r'^[ \t]*Tests:[ \t]+((?:\d+ [a-z]+, )*)(\d+) total\b[^\n]*$', text, re.M):
        counts.append(ran(re.findall(word, line), int(total)))
    # Vitest: `      Tests  1 failed | 3 passed | 2 skipped (6)`
    for line, total in re.findall(r'^[ \t]*Tests[ \t]+([^\n]*)\((\d+)\)[ \t]*$', text, re.M):
        counts.append(ran(re.findall(word, line), int(total)))
    # Mocha: `  5 passing (12ms)`, `  1 pending`, `  2 failing`; pending did not run.
    counts += [int(n) for n in re.findall(r'^[ \t]*(\d+) (?:passing|failing)(?: \([^)\n]*\))?[ \t]*$', text, re.M)]
    if re.search(r'^[ \t]*(?:No tests found|No test files found)\b', text, re.M):
        counts.append(0)
    return counts


def _possible_node_file(name, workspace):
    name = name.replace(r'\#', '#').replace(r'\\', '\\')
    if re.search(r'\.(?:[cm]?[jt]sx?)$', name, re.I):
        return True
    try:
        path = Path(workspace) / name
        return '..' not in Path(name).parts and path.is_relative_to(workspace) and path.is_file()
    except (ValueError, OSError):
        return False


def tests_reported(output):
    """How many tests the runner's own summaries say ran, added up over every summary seen
    (for example `npm test && npm run e2e`), or None when no summary is recognised.
    Only the count is read; whether the check passed stays its exit status."""
    counts = [c for c in summaries(output) if c is not None]
    return sum(counts) if counts else None


def expects_node_cases(command, output, workspace):
    """A quiet package script may hide both Node's command line and its summary."""
    node_test = r'(?:^|[;&|]\s*)(?:[^\s]+/)?node\s+(?:[^;&|\n]+?\s+)?--test(?:\s|$)'
    if (re.search(node_test, command)
            or ('--test-name-pattern' in command and re.search(r'\b(?:node|npm|pnpm|yarn)\b', command))
            or any(re.search(node_test, line[2:]) for line in output.splitlines() if line.startswith('> '))):
        return True
    if workspace is None:
        return False
    manifest = Path(workspace) / 'package.json'
    try:
        if not manifest.is_file():
            return False
        package = json.loads(manifest.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return False
    scripts = package.get('scripts') if isinstance(package, dict) else None
    if not isinstance(scripts, dict):
        return False
    # Use the same script resolution as acceptance locking (npm, yarn, pnpm and node --run).
    return any(isinstance(scripts.get(name), str) and re.search(node_test, scripts[name])
               for name in script_runs(command, scripts))


def counted(result, workspace=None, command=''):
    """Read a finished check: a run whose summary shows zero tests is never a pass."""
    result = dict(result)
    if result.get('held') or result.get('timed_out'):
        result.setdefault('tests', None)
        result.setdefault('no_tests', False)
        result.setdefault('tests_unclear', False)
        return result
    if 'node_cases' in result:
        seen = [result['node_cases']]
    else:
        output = result.get('output', '')
        seen = summaries(output, workspace)
        # A redirected or opaque Node reporter may produce no human summary.
        # npm prints the script it is running on a line beginning with "> ".
        if not seen and expects_node_cases(command, output, workspace):
            seen = [None]
    known = [count for count in seen if count is not None]
    tests = sum(known) if known else None
    result['tests'] = tests
    result['no_tests'] = tests == 0 and None not in seen
    # A runner summary was recognised but does not show that any test ran: not a pass.
    result['tests_unclear'] = not result['no_tests'] and None in seen
    if result['no_tests'] or result['tests_unclear']:
        result['passed'] = False
    return result


UNIT_RESERVATION = 1000000
REVIEW_NOTICE = ('Reviewed by a second, fresh Claude Code session of the same model family. '
                 'This is not an independent review.')
REVIEW_PENDING = ('Not reviewed yet. Before any approval, the change will be reviewed by a second, fresh '
                  'Claude Code session of the same model family; that is not an independent review.')
LIMITS_LINE = ('Limits enforced: the time limit above and 2 tool turns (one build, one review). '
               'Tokens are recorded as Claude Code reports them; they are not capped and this is not a bill.')
SCRIPT_CHANGED = 'The change edited the test script'
TOUCHED = 'This change touched files your check may depend on: '
NOT_TYPED = ('The approval code was not typed correctly. Run the same command again to be asked again '
             'for this same result; nothing is rebuilt.')
# Caps on untrusted text a person reads (characters, lines, items).
BRIEF_LIMIT, OUTPUT_LIMIT, OUTPUT_LINES, FINDING_LIMIT, FINDINGS_SHOWN = 2000, 4000, 60, 500, 20
PATH_LIMIT, FILES_SHOWN, REASON_LIMIT = 200, 50, 1000
STOP_SIGNALS = (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)


def quoted(marker, text, lines=OUTPUT_LINES):
    """Untrusted (already plain) text, every line behind a fixed marker."""
    rows = text.split('\n')
    shown = ['  %s> %s' % (marker, row) for row in rows[:lines]]
    if len(rows) > lines:
        shown.append('  (%d more lines not shown)' % (len(rows) - lines))
    return shown


def recorded_check(result):
    """What the journal keeps of a check: plain, capped output; start test from the full output."""
    return dict(result, output=plain(result.get('output', ''), OUTPUT_LIMIT),
                could_not_start=check_could_not_start(result))


def recorded_details(details):
    details = dict(details or {})
    models = [plain(m, 100, newlines=False) for m in details.get('models_reported') or []]
    details['models_reported'] = models
    if isinstance(details.get('identity'), dict):
        details['identity'] = dict(details['identity'], models_reported=models)
    return details


def recorded_review(review):
    findings = review['findings']
    return dict(review, findings=[plain(f, FINDING_LIMIT) for f in findings[:FINDINGS_SHOWN]],
                findings_not_shown=max(0, len(findings) - FINDINGS_SHOWN),
                details=recorded_details(review.get('details')))


def review_notice(data):
    return REVIEW_NOTICE if (data.get('review') or {}).get('verdict') in ('approve', 'reject') else REVIEW_PENDING


INSTALL_SCRIPTS = ['preinstall', 'install', 'postinstall', 'preprepare', 'prepare', 'postprepare']
NPM_INSTALL = {'ci', 'install', 'i', 'in', 'ins', 'add', 'clean-install', 'install-clean', 'isntall'}
INSTALL_TEST = {'it', 'cit', 'install-test', 'install-ci-test', 'clean-install-test'}


def script_runs(command, scripts, depth=0):
    """Names of package.json scripts a check command runs through npm, yarn, pnpm or
    `node --run` (with their pre/post scripts and the scripts those run in turn)."""
    try:
        lexer = shlex.shlex(command, posix=True, punctuation_chars=True)
        lexer.whitespace_split = True
        tokens = list(lexer) + [';']
    except ValueError:
        return sorted(scripts) if re.search(r'\b(npm|yarn|pnpm|node)\b', command) else []
    names, words = [], []
    for token in tokens:
        if token and all(c in '();<>|&' for c in token):
            names += [n for n in _segment_runs(words, scripts, depth) if n not in names]
            words = []
        else:
            words.append(token)
    return names


def _segment_runs(words, scripts, depth):
    while words and (re.match(r'[A-Za-z_][A-Za-z0-9_]*=', words[0]) or
                     words[0] in ('env', 'exec', 'command', 'time', 'nice')):
        words = words[1:]
    if not words or depth > 4:
        return []
    tool = os.path.basename(words[0])
    if tool in ('sh', 'bash', 'zsh', 'dash') and '-c' in words[:-1]:
        return script_runs(words[words.index('-c') + 1], scripts, depth + 1)
    rest, readings = words[1:], []
    if tool == 'node':
        run = [w.split('=', 1)[1] if w.startswith('--run=') else words[i + 2]
               for i, w in enumerate(words[1:]) if (w == '--run' and i + 2 < len(words)) or w.startswith('--run=')]
        readings = [(False, run)]
    # Every reading of an option's possible value is resolved, and the union is locked.
    for i in _next_words(rest) if tool in ('npm', 'yarn', 'pnpm') else []:
        sub, after = (rest[i], rest[i + 1:]) if i < len(rest) else ('', [])
        named = [after[j] for j in _next_words(after) if j < len(after)]
        if tool == 'npm':
            run = (['test'] if sub in ('test', 't', 'tst') or sub in INSTALL_TEST else
                   [sub] if sub in ('start', 'stop', 'restart') else
                   named if sub in ('run', 'run-script', 'rum', 'urn') else [])
            install = sub in NPM_INSTALL or sub in INSTALL_TEST
        else:
            run = (['test'] if sub in ('test', 't') or sub in INSTALL_TEST else
                   named if sub in ('run', 'run-script') else
                   [sub] if sub in scripts else [])
            install = sub in ('', 'install', 'i', 'add') or sub in INSTALL_TEST
        readings.append((install, run))
    names = []
    for install, run in readings:
        found = list(INSTALL_SCRIPTS) if install else []
        for name in run:
            found += ['pre' + name, name, 'post' + name]
        names += [n for n in found if n not in names]
    for name in list(names):
        if isinstance(scripts.get(name), str):
            names += [n for n in script_runs(scripts[name], scripts, depth + 1) if n not in names]
    return names


def _next_words(words):
    """Indexes of the words that may be the next non-option word. A word straight after a bare
    option (`-x` or `--name`, no `=`) may be that option's value, so both readings are kept;
    len(words) stands for "no word" when every candidate may be a value."""
    found = []
    for i, word in enumerate(words):
        if not word.startswith('-'):
            found.append(i)
            if i == 0 or not words[i - 1].startswith('-') or '=' in words[i - 1]:
                return found
    return found + [len(words)]


def package_scripts(manifest):
    entry = next((e for e in manifest['entries'] if e['path'] == 'package.json'), None)
    try:
        scripts = json.loads(bytes.fromhex(entry['bytes_hex'])).get('scripts') if entry else None
    except (ValueError, AttributeError):
        scripts = None
    return scripts if isinstance(scripts, dict) else {}


LOCKFILES = {'package.json', 'package-lock.json', 'npm-shrinkwrap.json', 'yarn.lock',
             'pnpm-lock.yaml', 'bun.lock', 'bun.lockb'}


def check_may_depend(path):
    parts = path.split('/')
    return (parts[-1] in LOCKFILES or any(p in ('test', 'tests', '__tests__') for p in parts[:-1])
            or re.search(r'\.(test|spec)\.', parts[-1]) is not None)


# Node's parent summary includes a synthetic pass for a file that ran no cases.
# Its per-file summaries count real cases, even when a case is named for its file.
NODE_CASE_REPORTER = """export default async function* (events) {
  let cases = 0;
  let summaryFinished = false;
  let legacyCases = 0;
  let legacyFinished = false;
  for await (const {type, data} of events) {
    if (type === 'test:summary') {
      if (data.file) cases += data.counts.passed + data.counts.failed;
      else summaryFinished = true;
    }
    // Node 20 emits individual outcomes and a final plan, without file summaries.
    if (type === 'test:pass' || type === 'test:fail') {
      const fileWrapper = data.nesting === 0 && data.name === data.file &&
                          data.line === 1 && data.column === 1;
      if (!fileWrapper && !data.skip && !data.todo && data.details.type !== 'suite' &&
          data.details.error?.failureType !== 'cancelledByParent') legacyCases++;
    }
    if (type === 'test:plan' && data.nesting === 0 && !data.file) legacyFinished = true;
  }
  if (summaryFinished) yield String(cases);
  else if (legacyFinished) yield String(legacyCases);
}
"""


def observe_node_cases(command, directory):
    """Add a second reporter to a direct Node test invocation. Keep the original
    shell arguments and stdout reporter, and execute the tests only once."""
    prefix = re.match(r'^(\s*(?:[a-zA-Z0-9_./-]+/)?node)\s+--test(?=\s|$)', command)
    if not prefix or any(c in command for c in ('$', '`', '\n')):
        return command, None
    try:
        lexer = shlex.shlex(command, posix=True, punctuation_chars=True)
        lexer.whitespace_split = True
        words = list(lexer)
    except ValueError:
        return command, None
    if any(word and all(c in '();<>|&' for c in word) for word in words):
        return command, None
    # Explicit output destinations and non-default execution modes belong to the caller.
    if any(word.startswith(('--test-reporter-destination', '--test-isolation',
                            '--experimental-test-isolation')) for word in words):
        return command, None
    reporters = sum(word == '--test-reporter' or word.startswith('--test-reporter=') for word in words)
    if reporters > 1:
        return command, None
    reporter = Path(directory) / 'cases.mjs'
    report = Path(directory) / 'count'
    reporter.write_text(NODE_CASE_REPORTER, encoding='utf-8')
    # A pipe was already used by run_check. The default reporter for a pipe is
    # TAP on Node 22 and spec on Node 24. Delegate to the version's own reporter.
    if not reporters:
        stdout_reporter = Path(directory) / 'stdout.mjs'
        stdout_reporter.write_text(
            "import {spec, tap} from 'node:test/reporters';\n"
            "export default Number(process.versions.node.split('.')[0]) >= 23 ? spec : tap;\n",
            encoding='utf-8')
    flags = ['--test-reporter=' + reporter.as_uri(), '--test-reporter-destination=' + str(report),
             '--test-reporter-destination=stdout']
    if not reporters:
        flags.append('--test-reporter=' + stdout_reporter.as_uri())
    end = prefix.end(1)
    return command[:end] + ' ' + shlex.join(flags) + command[end:], report


# Passed through to the check unchanged. Nothing else from the user's environment is,
# so tokens and keys in exported variables stay out of model-written code (V7).
CHECK_ENV_NAMES = ('PATH', 'LANG', 'LANGUAGE', 'TERM', 'TZ', 'USER', 'LOGNAME', 'SHELL',
                   'NODE_EXTRA_CA_CERTS', 'SSL_CERT_FILE', 'SSL_CERT_DIR',
                   'NVM_DIR', 'NVM_BIN', 'VOLTA_HOME', 'COREPACK_HOME', 'FNM_DIR')
CHECK_PROXY_NAMES = ('HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'http_proxy', 'https_proxy', 'no_proxy')
# Node version managers keep their tools under the real home folder; point at those
# folders by full path when they exist, so a redirected HOME does not lose them.
CHECK_TOOL_HOMES = (('VOLTA_HOME', '.volta'), ('COREPACK_HOME', '.cache/node/corepack'))


def check_environment(scratch, source=None):
    """An allow-listed environment whose HOME, TMPDIR and caches are a throwaway folder.

    Not a sandbox: files elsewhere can still be read by full path."""
    source = os.environ if source is None else source
    env = {k: v for k, v in source.items() if k in CHECK_ENV_NAMES or k.startswith('LC_')}
    # A proxy address with a user name or password in it is a secret; leave it out.
    env.update((k, v) for k, v in source.items() if k in CHECK_PROXY_NAMES and '@' not in v)
    real_home = source.get('HOME')
    for name, below in CHECK_TOOL_HOMES:
        if name not in env and real_home and (Path(real_home) / below).is_dir():
            env[name] = str(Path(real_home) / below)
    env.setdefault('PATH', os.defpath)
    scratch = Path(scratch)
    for name in ('home', 'tmp', 'npm-cache', 'cache', 'config', 'data'):
        (scratch / name).mkdir(mode=0o700)
    env.update(HOME=str(scratch / 'home'), TMPDIR=str(scratch / 'tmp'),
               TMP=str(scratch / 'tmp'), TEMP=str(scratch / 'tmp'),
               npm_config_cache=str(scratch / 'npm-cache'),
               XDG_CACHE_HOME=str(scratch / 'cache'), XDG_CONFIG_HOME=str(scratch / 'config'),
               XDG_DATA_HOME=str(scratch / 'data'))
    return env


def check_parent():
    """Where restored check copies go: the system temporary folder, outside the home folder.

    Yarn reads every .yarnrc.yml above the working folder, so a copy under the real home
    (the default runs folder is ~/.vibe-control/runs) would pick up the user's own one."""
    base = Path(tempfile.gettempdir()).resolve()
    home = Path(os.environ.get('HOME') or '/').expanduser().resolve()
    if home != Path('/') and (base == home or home in base.parents):
        base = Path('/tmp').resolve()
    return base


def remove_tree(path):
    """Delete a throwaway folder, giving back owner access a check took away; Refused if it stays."""
    path = Path(path)
    if os.path.islink(path):
        # The check swapped the folder for a link: remove the link, never walk into it.
        os.unlink(path)
    shutil.rmtree(path, ignore_errors=True)
    if not os.path.lexists(path):
        return
    for folder, names, _ in os.walk(path):
        for name in [''] + names:
            target = os.path.join(folder, name) if name else folder
            if not os.path.islink(target):  # never follow a link out of the folder
                try:
                    os.chmod(target, 0o700)
                except OSError:
                    pass
    shutil.rmtree(path, ignore_errors=True)
    require(not os.path.lexists(path), 'check temporary folder could not be deleted: %s' % path)


def run_check(command, workspace, seconds, *, on_start=None, on_abort=None, on_finish=None):
    """User-supplied shell command, on a restored copy, with a throwaway HOME beside it."""
    scratch = tempfile.mkdtemp(prefix='check-home-', dir=Path(workspace).resolve().parent)
    try:
        result = _run_check(command, workspace, seconds, check_environment(scratch),
                            on_start=on_start, on_abort=on_abort, on_finish=on_finish)
    except BaseException:
        try:
            remove_tree(scratch)
        except Refused:
            pass  # the check's own error is the one to report
        raise
    remove_tree(scratch)
    return result


def _run_check(command, workspace, seconds, env, *, on_start=None, on_abort=None, on_finish=None):
    """LIM ends the check's process tree."""
    started = time.monotonic()
    with tempfile.TemporaryFile() as stream, tempfile.TemporaryDirectory() as directory:
        observed_command, report = observe_node_cases(command, directory)
        process = subprocess.Popen(observed_command, shell=True, executable='/bin/sh', cwd=workspace,
                                   stdin=subprocess.DEVNULL, stdout=stream, stderr=stream,
                                   start_new_session=True, env=env)
        known, cleaned = {}, False
        try:
            row = processes().get(process.pid)
            require(row is not None, 'check process identity unavailable')
            known[process.pid] = row['start']
            if on_start:
                on_start(process.pid)
            # RV-A's exit observer retains the leader until LIM has swept descendants.
            timed_out = not _exited(process.pid, seconds)
            if timed_out and on_abort:
                on_abort('Check time limit reached.')
            result = kill_trees(known, 5)
            if on_finish:
                on_finish(result)
            process.wait(timeout=5)
            cleaned = True
            require(result['complete'] and all(p['state'] == 'dead' for p in result['processes']),
                    'check descendants not confirmed stopped')
            stream.seek(0)
            output = stream.read(4 * 1024 * 1024 + 1)
            require(len(output) <= 4 * 1024 * 1024, 'check output exceeds 4 MiB: hold')
            checked = dict(returncode=None if timed_out else process.returncode,
                           output=output.decode('utf-8', 'replace'), timed_out=timed_out,
                           passed=not timed_out and process.returncode == 0,
                           wall_seconds=round(time.monotonic() - started, 3))
            if report is not None and not timed_out and report.is_file():
                with report.open('rb') as recorded:
                    count = recorded.read(24)
                if re.fullmatch(rb'[0-9]{1,16}', count):
                    checked['node_cases'] = int(count)
            return counted(checked, workspace, command)
        except KeyboardInterrupt:
            if on_abort:
                on_abort('Stopped during check by Ctrl-C.')
            raise
        finally:
            if not cleaned:
                try:
                    if known:
                        result = kill_trees(known, 5)
                        if on_finish:
                            on_finish(result)
                    else:
                        # The unreaped process still owns this group when ps is unavailable.
                        try:
                            os.killpg(process.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                except (Refused, OSError):
                    # Still our unreaped leader: end its group even if the tree scan failed.
                    # This does not prove detached descendants dead; the error remains a hold.
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    raise
                finally:
                    process.wait(timeout=5)


def changed_files(base, candidate):
    old = {e['path']: e for e in base['entries']}
    new = {e['path']: e for e in candidate['entries']}
    result = []
    for path in sorted(old.keys() | new.keys()):
        if old.get(path) == new.get(path):
            continue
        lines = []
        for files in (old, new):
            lines.append(bytes.fromhex(files.get(path, {}).get('bytes_hex', '')).decode(
                'utf-8', 'replace').splitlines())
        diff = list(difflib.ndiff(*lines))
        result.append(dict(path=path, added=sum(s.startswith('+ ') for s in diff),
                           removed=sum(s.startswith('- ') for s in diff)))
    return result


def check_line(result):
    if not result:
        return 'not run'
    if result.get('held'):
        return 'held, not run (%s)' % result['held']
    if result.get('timed_out'):
        return 'time limit reached'
    if result.get('no_tests'):
        return NO_TESTS + ('' if result.get('returncode') == 0 else ' (exit %s)' % result.get('returncode'))
    if result.get('tests_unclear'):
        return TESTS_UNCLEAR
    if result.get('passed'):
        tests = result.get('tests')
        if type(tests) is not int:
            return COUNT_NOT_SEEN
        return 'passed (%d test%s)' % (tests, '' if tests == 1 else 's')
    return 'failed (exit %s)' % result.get('returncode')


def summary(run_id, data):
    """Plain lines from the journal's `journey` entry (an export of Service.view).

    Untrusted text (reviewer findings, error text in the reason) comes first, behind fixed
    markers or labels and without control characters; the command's own facts follow it, so
    they are the last thing shown before the approval question.
    """
    text = ['Vibe Control run ' + run_id]
    review = data.get('review')
    if review and review['findings']:
        rows = ['Reviewer findings, as the reviewer wrote them:']
        for finding in review['findings']:
            rows += quoted('reviewer', plain(finding), lines=20)
        text.append('\n'.join(rows))
    if review and review.get('findings_not_shown'):
        text.append('%d more reviewer findings were not shown.' % review['findings_not_shown'])
    if data.get('reason'):
        text.append('Reason: ' + plain(data['reason'], REASON_LIMIT, newlines=False))
    text.append('State: ' + data.get('outcome', 'held'))
    if 'repository' in data:
        text.append('Repository: %s, new branch %s' % (plain(data['repository'], newlines=False),
                                                      data.get('branch')))
    if 'changes' in data:
        changes = data['changes']
        rows = ['Files changed: %d' % len(changes)] + [
            '  file> +%d -%d  %s' % (c['added'], c['removed'], plain(c['path'], PATH_LIMIT, newlines=False))
            for c in changes[:FILES_SHOWN]]
        if len(changes) > FILES_SHOWN:
            rows.append('  (%d more files not shown; receipt.json lists them all)' % (len(changes) - FILES_SHOWN))
        text.append('\n'.join(rows))
    touched = data.get('check_dependencies') or []
    if touched:
        text.append(TOUCHED + ', '.join(plain(p, PATH_LIMIT, newlines=False) for p in touched[:FILES_SHOWN]) +
                    (' and %d more' % (len(touched) - FILES_SHOWN) if len(touched) > FILES_SHOWN else ''))
    if 'check_command' in data:
        check = data.get('check')
        line = 'Check `%s`: %s; at baseline: %s.' % (plain(data['check_command'], newlines=False),
                                                     check_line(check), check_line(data.get('baseline')))
        if check and check.get('identical_failure_before_and_after'):
            line += ' ' + IDENTICAL_FAILURE_NOTICE
        text.append(line)
    if review:
        count = len(review['findings']) + review.get('findings_not_shown', 0)
        text.append('Review: %s (%d finding%s%s).' % (review['verdict'], count, '' if count == 1 else 's',
                                                    ', shown above' if count else ''))
    text.append(data.get('review_notice') or review_notice(data))
    usage = data.get('usage') or {}
    complete = [u for u in usage.get('usage', []) if u.get('complete')]
    if usage.get('observed_units'):
        text.append('Usage: %s%d tokens reported by Claude Code (not a bill).' % (
            '' if complete and len(complete) == len(usage['usage']) else 'at least ', usage['observed_units']))
    elif 'usage' in data:
        text.append('Usage: not recorded.')
    if 'wall_seconds' in data:
        text.append('Time taken: %.1f seconds.' % data['wall_seconds'])
    text.append('Approval: %s. Delivery: %s.' % (data.get('approval', 'not_run'), data.get('delivery', 'not_run')))
    for key in ('build_termination', 'termination'):
        if data.get(key, {}).get('error'):
            text.append('Stop could not be confirmed: ' + plain(data[key]['error'], REASON_LIMIT, newlines=False))
        elif key in data and not data[key]['complete']:
            text.append('The process scan did not finish in time; other descendants are not confirmed dead.')
    for process in data.get('processes', []):
        text.append('Process %d (%s): %s.' % (process['pid'], process['stage'],
            'confirmed dead' if process['state'] == 'dead' else 'not confirmed dead'))
    text.append('This page and receipt contain folder paths from this computer. Check before sharing them.')
    return text


def approval_warning(check):
    """The line shown beside the approval code when the check's pass needs a second look."""
    if check.get('identical_failure_before_and_after'):
        return IDENTICAL_FAILURE_NOTICE
    if check.get('passed') and type(check.get('tests')) is not int:
        return COUNT_NOT_SEEN_NOTICE
    return None


def awaiting_code(view):
    """A frozen, checked and reviewed result whose approval code was not typed (yet)."""
    record = view['records'].get(view['current']) if view['current'] else None
    return (record is not None and not view['stopped'] and
            view.get('journey', {}).get('approval') == 'not approved' and
            not record['approvals'] and not record['publications'])


def ask(input_fn, output, prompt):
    """End of input (Ctrl-D) is an empty answer: not approved."""
    try:
        return input_fn(prompt)
    except EOFError:
        output('')
        return ''


def approve_code(candidate_digest, destination, input_fn, interactive, output, warning=None, tries=3):
    """No CLI switch or pipe can substitute for terminal confirmation."""
    require(interactive, 'Final approval requires an interactive terminal; not approved.')
    short = candidate_digest.removeprefix('sha256:')[:8]
    output('Destination: %s\nCandidate: %s' % (plain(destination, newlines=False), short))
    if warning:
        output(warning)
    for left in range(tries - 1, -1, -1):
        try:
            answer = input_fn('Type %s to approve: ' % short)
        except EOFError:
            output('')
            return False
        if answer == short:
            return True
        if left:
            output('That is not the code. %d %s left.' % (left, 'try' if left == 1 else 'tries'))
    return False


class Journey:
    def __init__(self, options, *, tool_factory, input_fn=input, output=print,
                 interactive=False, licence=None, check_runner=run_check, launcher=None):
        self.options, self.tool_factory = options, tool_factory
        self.input, self.output, self.interactive = input_fn, output, interactive
        self.licence, self.check_runner = licence or Licence(), check_runner
        # Trusted in-process testing seam only; never supplied by CLI/file/environment.
        self.launcher = launcher
        self.service = self.limits = self.run_id = self.root = None
        self.started = time.monotonic()
        self.page_announced = False
        self.stopped_by = 'Ctrl-C'
        self.scripts = {}

    def interrupt(self, signum, frame):
        """SIGTERM and SIGHUP (closed terminal) take Ctrl-C's stop path."""
        self.stopped_by = {signal.SIGTERM: 'SIGTERM', signal.SIGHUP: 'a closed terminal (SIGHUP)'}.get(
            signum, 'Ctrl-C')
        raise KeyboardInterrupt()

    @contextmanager
    def finishing(self):
        """A second Ctrl-C (or SIGTERM/SIGHUP) cannot cut the stop and receipt short."""
        previous = {s: signal.signal(s, signal.SIG_IGN) for s in STOP_SIGNALS}
        try:
            yield
        finally:
            for s, handler in previous.items():
                signal.signal(s, handler)

    def page(self):
        # Both receipts and the page are disposable exports of the same view.
        try:
            view = self.service.view(self.run_id)
            self.root.joinpath('receipt.json').write_text(json.dumps(view, indent=2) + '\n')
            self.root.joinpath('receipt.md').write_text('\n\n'.join(summary(
                self.run_id, view.get('journey', {}))) + '\n')
            path = write_page(self.service, self.run_id, self.root)
        except (Refused, OSError, ValueError) as exc:
            self.output('Run page unavailable: ' + plain(exc, REASON_LIMIT, newlines=False))
            return
        if not self.page_announced:
            self.output('Run page: ' + str(path))
            self.page_announced = True

    def note(self, **fields):
        if fields.get('reason'):
            # Reasons can carry tool, check or repository error text.
            fields['reason'] = plain(fields['reason'], REASON_LIMIT, newlines=False)
        with self.service.journal.change('journey') as state:
            state['runs'][self.run_id].setdefault('journey', {}).update(fields)
        self.page()

    def receipt(self):
        started = self.service.view(self.run_id).get('journey', {}).get('started_at')
        elapsed = time.time() - started if started is not None else time.monotonic() - self.started
        self.note(wall_seconds=round(max(0, elapsed), 3), usage=self.limits.view(self.run_id),
                  review_notice=review_notice(self.service.view(self.run_id).get('journey', {})))
        view = self.service.view(self.run_id)
        data = view.get('journey', {})
        text = summary(self.run_id, data)
        self.root.joinpath('receipt.json').write_text(json.dumps(view, indent=2) + '\n')
        self.root.joinpath('receipt.md').write_text('\n\n'.join(text) + '\n')
        self.output('\n'.join(text))
        self.output('Receipt: ' + str(self.root / 'receipt.md'))
        return view

    def track(self, pid, stage):
        row = processes().get(pid)
        require(row is not None, 'Process identity unavailable: termination unconfirmed.')
        with self.service.journal.change('journey_process') as state:
            data = state['runs'][self.run_id].setdefault('journey', {})
            data.setdefault('processes', []).append(dict(pid=pid, start=row['start'],
                                                        stage=stage, state='running'))

    def record_termination(self, result, stage='cleanup', key='termination'):
        with self.service.journal.change('journey_termination') as state:
            data = state['runs'][self.run_id].setdefault('journey', {})
            for process in data.get('processes', []):
                for observed in result['processes']:
                    if (process['pid'], process['start']) == (observed['pid'], observed['start']):
                        process['state'] = observed['state']
            identities = {(p['pid'], p['start']) for p in data.get('processes', [])}
            for observed in result['processes']:
                if (observed['pid'], observed['start']) not in identities:
                    data.setdefault('processes', []).append(dict(observed, stage=stage))
            data[key] = result
        self.page()

    def fence(self, reason):
        self.service.revoke('customer', self.run_id, stop=True)
        self.note(outcome='held', reason=reason)

    def stop(self, reason):
        self.fence(reason)
        try:
            # LIM's builder sweep; its identities go in the same report as checks/reviewer.
            self.record_termination(self.limits.terminate('control_service', self.run_id),
                                    stage='build', key='build_termination')
        except (Refused, OSError) as exc:
            reason += '; termination unconfirmed: ' + str(exc)
        data = self.service.view(self.run_id).get('journey', {})
        known = {p['pid']: p['start'] for p in data.get('processes', []) if p['state'] != 'dead'}
        if known:
            try:
                self.record_termination(kill_trees(known, 5))
            except (Refused, OSError) as exc:
                self.note(termination=dict(complete=False, error=str(exc),
                    processes=[dict(pid=p, start=s, state='alive') for p, s in known.items()]))
                reason += '; check/reviewer termination unconfirmed: ' + str(exc)
        self.note(outcome='held', reason=reason)

    def check(self, command, manifest, folder, seconds):
        if self.check_runner is not run_check:
            workspace = restore(manifest, self.root / folder)
            return counted(self.check_runner(command, workspace, seconds), workspace, command)
        # Real checks run in a copy outside the home folder, deleted afterwards.
        outside = Path(tempfile.mkdtemp(prefix='vibe-check-', dir=check_parent())).resolve()
        try:
            result = run_check(command, restore(manifest, outside / folder), seconds,
                on_start=lambda pid: self.track(pid, folder), on_abort=self.fence,
                on_finish=self.record_termination)
        except BaseException:
            try:
                remove_tree(outside)
            except Refused:
                pass
            raise
        remove_tree(outside)
        return result

    def launch_reviewer(self, launch, workspace, prompt, seconds):
        """Fence a terminal SIGINT before RV-A handles its own process cleanup."""
        def started(pid):
            # Do not reenter SQLite from a signal while recording the new identity.
            mask = signal.pthread_sigmask(signal.SIG_BLOCK, set(STOP_SIGNALS))
            try:
                self.track(pid, 'review')
            finally:
                signal.pthread_sigmask(signal.SIG_SETMASK, mask)

        def interrupted(signum, frame):
            try:
                self.interrupt(signum, frame)
            except KeyboardInterrupt:
                self.fence('Stopped during review by %s.' % self.stopped_by)
                raise

        previous = {s: signal.signal(s, interrupted) for s in STOP_SIGNALS}
        try:
            return launch('reviewer', workspace, prompt, seconds, on_start=started)
        finally:
            for s, handler in previous.items():
                signal.signal(s, handler)

    def publisher(self):
        folder = self.root / 'publisher'
        folder.mkdir(exist_ok=True)
        repository = self.service.view(self.run_id)['journey']['repository']
        return endpoint(Publisher(folder, {'local': repository}))

    def restart(self):
        view = self.service.view(self.run_id)
        operations = [p for r in view['records'].values() for p in r['publications']]
        if not operations:
            if awaiting_code(view):
                self.output('Run %s: the same result is waiting for your approval code; '
                            'nothing is rebuilt.' % self.run_id)
                self.deliver(self.service.record(view))
                return
            self.stop('Existing run held after restart; no build or delivery was repeated. '
                      'Add --new to start a fresh run of the same brief.')
            return
        adapter = self.publisher()
        for op in operations:
            if op['outcome'] not in {'succeeded', 'failed'}:
                self.service.reconcile('control_service', self.run_id, op['id'], adapter)
        view = self.service.view(self.run_id)
        operations = [p for r in view['records'].values() for p in r['publications']]
        delivered = any(p['outcome'] == 'succeeded' and adapter.query(p['id'], p['body']) == 'landed'
                        for p in operations)
        self.note(outcome='delivered' if delivered else 'held',
                  delivery='delivered' if delivered else 'held',
                  reason='Previous delivery reconciled; no action was resent.' if delivered else
                         'Previous delivery reconciled or held; no action was resent.')
        if delivered:
            data = self.service.view(self.run_id)['journey']
            self.output('Already delivered: branch %s in %s. Nothing was sent again. '
                        'Add --new to start a fresh run of the same brief.' % (
                            data['branch'], plain(data['repository'], newlines=False)))
            self.instructions()

    def instructions(self):
        data = self.service.view(self.run_id)['journey']
        prefix = 'git -C %s push origin %s' % (shlex.quote(data['repository']), shlex.quote(data['branch']))
        self.output(plain('Run these yourself to push and open a pull request:\n' + prefix + '\n' +
                          'cd %s && gh pr create --head %s' % (
                              shlex.quote(data['repository']), shlex.quote(data['branch']))))

    def requests(self, key):
        """Runs of one request, oldest first: the first has task `key`, later --new runs number on."""
        runs, found = list(self.service.journal.read()['runs'].values()), []
        while True:
            task = key if not found else digest(dict(request=key, number=len(found)))
            match = [r for r in runs if r['task'] == task]
            if not match:
                return found
            found.append(match[0])

    def guarded(self, step, prefix=''):
        """Every stop or refusal after the run exists ends in a recorded hold and a receipt."""
        try:
            step()
        except KeyboardInterrupt:
            with self.finishing():
                self.stop('Stopped by %s. Delivery, if already admitted, requires reconciliation.'
                          % self.stopped_by)
                if self.service.unresolved(self.service.view(self.run_id)):
                    self.restart()
                return self.receipt()
        except (Refused, OSError, ValueError, subprocess.SubprocessError) as exc:
            reason = ('The build exceeded the candidate limit: 4 MiB and 1000 files. Nothing was delivered.'
                      if str(exc) == 'artifact size limit' else prefix + str(exc))
            self.stop(reason)
        return self.receipt()

    def make_root(self, runs, key):
        # A fresh folder per attempt: a refused or stopped earlier attempt never blocks this one.
        self.root = Path(tempfile.mkdtemp(prefix=key[7:23] + '-', dir=runs))
        return self.root

    def run(self):
        previous = {s: signal.signal(s, self.interrupt) for s in (signal.SIGTERM, signal.SIGHUP)}
        try:
            return self.journey()
        finally:
            for s, handler in previous.items():
                signal.signal(s, handler)

    def journey(self):
        opts = self.options
        shipped = STUDIO / 'example/project'
        repository = shipped if opts.command == 'demo' else Path(opts.repository).absolute()
        # The gate precedes reads of brief files, directory creation and tool discovery/version.
        gate = self.licence.gate(repository)
        require(gate.ok, gate.reason)
        brief = (STUDIO / 'example/brief.md').read_text() if opts.command == 'demo' else (
            Path(opts.brief_file).read_text() if opts.brief_file else opts.brief)
        require(isinstance(brief, str) and brief.strip(), 'A nonempty brief is required.')
        seconds = opts.time_limit * 60
        require(seconds > 0 and opts.model == 'sonnet', 'Positive time limit and sonnet required.')
        runs = Path(opts.runs_dir).expanduser().resolve()
        require(not runs.is_relative_to(repository.resolve()), 'Runs directory must be outside the repository.')
        runs.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.service = Service(runs / 'journal.sqlite', SESSIONS)
        self.limits = Limits(self.service)
        key = digest(dict(source=str(repository), brief=brief, check=opts.check,
                          seconds=seconds, model=opts.model))
        found = self.requests(key)
        if getattr(opts, 'new', False):
            # Exactly once: an unconfirmed delivery is reconciled by a plain rerun first.
            require(not any(self.service.unresolved(r) for r in found),
                    'An earlier run of this brief has a delivery that is not confirmed yet. Run the same '
                    'command without --new first to check what happened.')
        elif found and 'plan_approver' in found[-1]:
            # A plan was approved, so a build may exist: resume or hold, never rebuild.
            self.run_id = found[-1]['id']
            self.root = Path(found[-1].get('journey', {}).get('run_folder', runs / key[7:23]))
            return self.guarded(self.restart, prefix='Restart held: ')
        if found and any(p['state'] != 'dead' for p in found[-1].get('journey', {}).get('processes', [])):
            # Nothing was built, but end any recorded check before starting afresh.
            self.run_id = found[-1]['id']
            self.root = Path(found[-1]['journey']['run_folder'])
            self.stop('Replaced by a new run; nothing had been built.')
            self.run_id = self.root = None
        task = key if not found else digest(dict(request=key, number=len(found)))
        if opts.command == 'demo':
            repository = example_copy(shipped, self.make_root(runs, key) / 'repository')
        try:
            observation = inspect_tracked(repository, 'project_local')
        except OSError as exc:
            if exc.filename and Path(exc.filename).name == 'package.json':
                raise Refused('The package.json at the top of the repository could not be read. '
                              'Check that you have permission to read it and try again.') from None
            raise
        with self.service.journal.change('journey_intake') as state:
            state.setdefault('journey_intakes', []).append(observation)
        if observation['reasons'] == ['Missing or invalid root package.json dependency maps.']:
            with metadata_copy(repository) as metadata:
                names = intake.git(metadata, 'ls-tree', '--name-only', 'HEAD').decode().splitlines()
            reason = ('This does not look like a JavaScript project: there is no package.json at the top '
                      'of the repository. Vibe Control currently works on JavaScript and TypeScript projects only.'
                      if 'package.json' not in names else
                      'The package.json at the top of the repository cannot be read as a JavaScript project. '
                      'Check that it contains valid JSON and that its dependency lists are objects.')
            raise Refused(reason)
        require(observation['status'] == 'compatible', '; '.join(observation['reasons']))
        require(observation['working_tree'] == 'clean',
                'Repository must be clean; working tree is ' + observation['working_tree'])
        require_build_room(observation)
        manifest = base_manifest(repository, observation)
        package = next((e for e in manifest['entries'] if e['path'] == 'package.json'), None)
        package = json.loads(bytes.fromhex(package['bytes_hex'])) if package else {}
        command = opts.check or ('node --test' if opts.command == 'demo' else None)
        if command is None and isinstance(package.get('scripts'), dict) and package['scripts'].get('test'):
            command = 'npm test'
        require(command, '--check is required when package.json has no test script.')
        # The check is bound to the BASE's scripts; a candidate that edits them is held.
        base_scripts = package_scripts(manifest)
        self.scripts = {name: base_scripts.get(name) for name in script_runs(command, base_scripts)}
        tool = self.tool_factory()
        require(type(tool) is ClaudeCode, 'RV-A ClaudeCode tool required')
        if self.launcher is not None:
            tool.launch = self.launcher
        rule = dict(definition_digest=digest(dict(command=command, scripts=self.scripts,
            acceptance='passes-or-explicitly-consented-identical-started-failure-v2', base_digest=manifest['base_digest'])),
            environment_digest=digest(
            dict(platform=sys.platform, check='local-user-shell-v1')))
        policy = dict(version='j1-v2', independent_review=False, checks={'command': rule}, review=dict(
            definition_digest=tool.tool_digest('reviewer'), environment_digest=rule['environment_digest']))
        workspace = restore(manifest, (self.root or self.make_root(runs, key)) / 'workspace')
        self.run_id = self.service.create('control_service', project='project_local', task=task,
            brief=brief, plan_revision=1, policy=policy, workspace=workspace,
            base_digest=manifest['base_digest'], tool_digest=tool.tool_digest('builder'),
            time_limit_seconds=seconds)
        self.note(receipt_version='j1-v3', run_folder=str(self.root), repository=str(repository),
                  brief=plain(brief, BRIEF_LIMIT), intake=observation, check_command=plain(command),
                  check_scripts={plain(n, 100, newlines=False): None if t is None else plain(t, 500, newlines=False)
                                 for n, t in self.scripts.items()},
                  tool_version=tool.version, branch='vibe/' + self.run_id[:8], outcome='running',
                  review_notice=REVIEW_PENDING, approval='not_run', delivery='not_run', started_at=time.time())
        self.limits.set_limits('customer', self.run_id, max_units=2 * UNIT_RESERVATION,
                               max_turns=2, max_seconds=seconds)
        return self.guarded(lambda: self.execute(tool, brief, manifest, command, seconds))

    def execute(self, tool, brief, base, command, seconds):
        self.output('Working from commit %s. Untracked and ignored files (for example node_modules) '
                    'are not included.' % self.service.view(self.run_id)['journey']['intake']['baseline_commit'][:8])
        self.output(DEPENDENCY_HINT)
        self.output('The check command runs as you, on this machine, unsandboxed.')
        baseline = self.check(command, base, 'baseline', seconds)
        self.note(baseline=recorded_check(baseline))
        output = plain(baseline.get('output', ''), OUTPUT_LIMIT)
        self.output('\n'.join(['Baseline check: %s.' % check_line(baseline)] +
                              (['Its output, as the check printed it:'] + quoted('check', output) if output else [])))
        require(not baseline.get('timed_out'), 'Baseline time limit reached; task stopped.')
        if not baseline.get('passed') and check_could_not_start(baseline):
            self.note(outcome='held', reason='Baseline check could not start. ' + DEPENDENCY_HINT)
            self.output('Baseline check could not start; no build was started.')
            self.output(DEPENDENCY_HINT)
            return
        demo = self.options.command == 'demo' and not self.options.check  # the shipped example's own check
        if not baseline.get('passed') and not demo:
            self.output(NO_TESTS_BASELINE_NOTICE if baseline.get('no_tests') or baseline.get('tests_unclear')
                        else FAILING_BASELINE_NOTICE)
        if not baseline.get('passed'):
            if self.options.yes_plan and not self.options.allow_failing_baseline:
                self.note(outcome='held', reason='Failing baseline: --yes-plan requires --allow-failing-baseline; no build was started.')
                return
        view = self.service.view(self.run_id)
        data = view['journey']
        # Untrusted text first, behind markers; the plan's own facts follow, before the question.
        lines = ['Brief, as given:'] + quoted('brief', data['brief'])
        if self.scripts:
            lines.append('Scripts this check runs, read from package.json at commit %s:'
                         % data['intake']['baseline_commit'][:8])
            lines += ['  script> %s: %s' % (name, '(not defined)' if text is None else text)
                      for name, text in data['check_scripts'].items()]
        lines += ['Time limit: %s minutes' % self.options.time_limit,
                  'Tool: Claude Code %s (sonnet)' % tool.version,
                  'Check: ' + data['check_command'] + (
                      ' (it runs the package.json scripts listed above, as they are now; if the change '
                      'edits them, the check is held)' if self.scripts else ''),
                  'Destination: %s branch %s' % (plain(data['repository'], newlines=False), data['branch']),
                  'Tool digest: ' + view['plan']['tool_digest']]
        self.output('\n'.join(lines))
        self.output(REVIEW_PENDING)
        self.output(LIMITS_LINE)
        if demo and not baseline.get('passed'):
            self.output(DEMO_BASELINE_NOTICE)
        if not self.options.yes_plan and ask(self.input, self.output, 'Approve plan? (y/N) ').lower() != 'y':
            self.note(outcome='not approved', reason='Plan refused; no tool build was started. '
                      'Run the same command again to be asked again.')
            return
        self.service.approve_plan('customer', self.run_id, digest(view['plan']))
        self.page()
        execution_started = time.monotonic()
        launch = tool.launch

        def reserved_launch(role, workspace, prompt, timeout_seconds, **kwargs):
            if role == 'builder':
                # Both turns are reserved under the live lease, before either tool is started.
                for name in ('build', 'review'):
                    self.limits.reserve('control_service', self.run_id, name, UNIT_RESERVATION)
            self.page()
            result = (self.launch_reviewer(launch, workspace, prompt, timeout_seconds) if role == 'reviewer'
                      else launch(role, workspace, prompt, timeout_seconds, **kwargs))
            if role == 'reviewer':
                if result[1].get('timed_out'):
                    self.stop('Review time limit reached; no delivery was started.')
                known = {p['pid']: p['start'] for p in self.service.view(self.run_id)['journey'].get(
                    'processes', []) if p['stage'] == 'review' and p['state'] != 'dead'}
                if known:
                    # RV-A's (capture, details) is returned unchanged; this sweep is evidence only.
                    swept = kill_trees(known, 5)
                    self.record_termination(swept)
                    require(swept['complete'] and all(p['state'] == 'dead' for p in swept['processes']),
                            'Reviewer termination unconfirmed; delivery held.')
            return result

        tool.launch = reserved_launch
        agent = ClaudeCodeAgent(tool, brief, seconds, on_start=lambda pid: self.limits.register(
            'control_service', self.run_id, pid))
        try:
            self.service.dispatch('control_service', self.run_id, agent)
        finally:
            if agent.capture is not None:
                self.limits.settle('control_service', self.run_id, 'build', agent.capture)
                self.note(build=dict(capture=asdict(agent.capture), details=recorded_details(agent.details)))
                if agent.details.get('timed_out'):
                    self.stop('Build time limit reached. Nothing was published.')
        view = self.service.view(self.run_id)
        if self.limits._known(self.run_id):
            result = self.limits.terminate('control_service', self.run_id)
            require(result['complete'] and all(p['state'] == 'dead' for p in result['processes']),
                    'Builder termination unconfirmed; delivery held.')
        record = self.service.record(view)
        changes = changed_files(base, record['manifest'])
        self.note(changes=[dict(c, path=plain(c['path'], PATH_LIMIT, newlines=False)) for c in changes],
                  check_dependencies=[plain(c['path'], PATH_LIMIT, newlines=False)
                                      for c in changes if check_may_depend(c['path'])])
        remaining = seconds - (time.monotonic() - execution_started)
        if remaining <= 0:
            self.stop('Task time limit reached. Nothing was published.')
            return
        if self.scripts and {n: package_scripts(record['manifest']).get(n) for n in self.scripts} != self.scripts:
            # Never run the candidate's own edited script as the check.
            self.note(check=dict(passed=False, returncode=None, timed_out=False, output='', wall_seconds=0,
                                 held=SCRIPT_CHANGED, could_not_start=False,
                                 identical_failure_before_and_after=False))
            self.service.assess('checker', self.run_id, 'check', 'command',
                                self.service.binding(view, record, 'check', 'command'), 'held')
            self.note(outcome='held', reason=SCRIPT_CHANGED + ', so the check was not run and this change '
                      'cannot be approved. To check it with a command you choose, run again with '
                      '--check "<command>".')
            return
        check = self.check(command, record['manifest'], 'checks', remaining)
        # A run with no tests is never an inherited failure: it shows nothing either time.
        inherited = (not check['passed'] and not baseline['passed'] and
                     not check.get('no_tests') and not baseline.get('no_tests') and
                     not check.get('tests_unclear') and not baseline.get('tests_unclear') and
                     not check.get('timed_out') and not baseline.get('timed_out') and
                     not check_could_not_start(check) and not check_could_not_start(baseline) and
                     type(check['returncode']) is int and check['returncode'] != 0 and
                     check['returncode'] == baseline['returncode'] and check['output'] == baseline['output'])
        self.note(check=dict(recorded_check(check), identical_failure_before_and_after=inherited))
        if inherited:
            self.output(IDENTICAL_FAILURE_NOTICE)
        # The approved definition measures regression against the recorded immutable base.
        self.service.assess('checker', self.run_id, 'check', 'command',
            self.service.binding(view, record, 'check', 'command'),
            'held' if check.get('timed_out') else 'passed' if check['passed'] or inherited else 'failed')
        self.page()
        require(not check.get('timed_out'), 'Candidate check time limit reached; task stopped.')
        remaining = seconds - (time.monotonic() - execution_started)
        if remaining <= 0:
            self.stop('Task time limit reached before review. Nothing was published.')
            return
        review = tool.review(record['manifest'], brief, remaining)
        self.limits.settle('control_service', self.run_id, 'review', Capture(**review['capture']))
        self.note(review=recorded_review(review), usage=self.limits.view(self.run_id))
        self.note(review_notice=review_notice(self.service.view(self.run_id)['journey']))
        self.service.assess('reviewer', self.run_id, 'review', 'review',
                self.service.binding(view, record, 'review', 'review'),
                {'approve': 'passed', 'reject': 'failed'}.get(review['verdict'], 'held'))
        self.page()
        if check.get('no_tests'):
            self.note(outcome='held', reason=NO_TESTS_REASON)
            return
        if check.get('tests_unclear'):
            self.note(outcome='held', reason=TESTS_UNCLEAR_REASON)
            return
        if not (check['passed'] or inherited) or review['verdict'] != 'approve':
            self.note(outcome='held', reason='Checks or review did not pass; not approved.')
            return
        require(not self.service.view(self.run_id)['stopped'], 'Task stopped; not approved.')
        self.deliver(record)

    def deliver(self, record):
        view = self.service.view(self.run_id)
        data = view['journey']
        # The base is the commit recorded at intake (the candidate's build base), never a later HEAD.
        observed = lambda: push_destination(data['repository'], data['branch'],
                                            data['intake']['branch'], data['intake']['baseline_commit'])
        destination = observed()
        shown = self.service.display('customer', self.run_id, 'push', destination)
        self.note(outcome='awaiting approval', destination=destination)
        self.receipt()
        try:
            approved = approve_code(record['candidate']['digest'],
                data['repository'] + ' ' + destination['ref'], self.input, self.interactive, self.output,
                warning=approval_warning(data.get('check') or {}))
        except Refused as exc:
            self.note(outcome='not approved', approval='not approved', reason=str(exc))
            return
        if not approved:
            self.note(outcome='not approved', approval='not approved', reason=NOT_TYPED)
            return
        # Observe again after the (possibly long) question; the publisher checks once more before pushing.
        require(observed() == destination, MOVED)
        approval =self.service.confirm('customer', self.run_id, shown['reference'], shown['displayed'])
        self.note(approval='approved')
        operation = self.service.admit('customer', self.run_id, 'deliver-' + self.run_id,
                                       approval, shown['displayed'])
        self.page()
        try:
            self.service.fake_publish('control_service', self.run_id, operation['id'], self.publisher())
        except Refused as exc:
            raise Refused('Delivery not confirmed (%s). The run is held; run the same command '
                          'again to check what happened.' % exc) from None
        op = self.service.view(self.run_id)['records'][record['candidate']['id']]['publications'][-1]
        require(op['outcome'] == 'succeeded', 'Delivery outcome unresolved; restart to reconcile.')
        self.note(outcome='delivered', delivery='delivered')
        self.instructions()
