"""Read-only disk display. EX1 remains the source; missing facts stay null."""
from copy import deepcopy
import json
from pathlib import Path
import unicodedata


UI = Path(__file__).resolve().parents[1] / 'ui'
HIDDEN = ('Cc', 'Cf', 'Cs', 'Zl', 'Zp')  # controls, bidi/format marks, surrogates, separators


def plain(value, limit=None, newlines=True):
    """Text a person reads: every control, format and line/paragraph separator
    character except (optionally) newline is shown as a visible escape; text
    over `limit` characters is cut, saying how much."""
    text, cut = str(value), 0
    if limit is not None and len(text) > limit:
        text, cut = text[:limit], len(text) - limit
    if not all(part.isprintable() for part in text.split('\n')) or (not newlines and '\n' in text):
        text = ''.join(ch if (ch == '\n' and newlines) or unicodedata.category(ch) not in HIDDEN
                       else '\\x%02x' % ord(ch) if ord(ch) < 0x100 else '\\u%04x' % ord(ch)
                       for ch in text)
    return text + (' [%d more characters not shown]' % cut if cut else '')


def scrub(value):
    """The same escapes for every string in exported page data (no length cut)."""
    if isinstance(value, str):
        return plain(value)
    if isinstance(value, list):
        return [scrub(item) for item in value]
    if isinstance(value, dict):
        return {scrub(key): scrub(item) for key, item in value.items()}
    return value


def display_state(run):
    """Execution completion alone cannot describe the whole journey."""
    data = run.get('journey', {})
    if run['stopped'] or data.get('outcome') == 'held':
        return 'held'
    if any(p['outcome'] in ('received', 'uncertain', 'held')
           for r in run['records'].values() for p in r['publications']):
        return 'held'
    if data.get('outcome') == 'awaiting approval':
        return 'awaiting_input'
    if data.get('outcome') == 'delivered':
        return 'completed'
    if data.get('outcome') == 'not approved':
        return 'completed' if run['current'] else 'held'
    # The builder's attempt is already completed while checks/review still run.
    if run['current']:
        return 'checking'
    return run['attempts'][-1]['state']


def project(view, replay, usage=None):
    """Adapt the view/replay for the existing display binding, without new authority."""
    attempt = view['attempts'][-1]
    scope = dict(project_id=view['project'], task_id='task_' + view['task'].split(':')[-1],
                 run_id='run_' + view['id'], attempt_id='attempt_' + attempt['id'])
    status = display_state(view)
    reason = view.get('journey', {}).get('reason') or attempt.get('error') or 'Not recorded'
    error = dict(code='uncertain_action', message=reason, retry='reconcile_or_hold')
    events = []
    for row in replay:
        historic = row['state']['runs'].get(view['id'])
        if not historic or historic['attempts'][-1]['id'] != attempt['id']:
            continue
        events.append(dict(id='event_' + str(row['sequence']), sequence=row['sequence'],
                           scope=scope, state=display_state(historic)))
    # A retained suffix is needed after terminal journeys are held on restart.
    # Keep journal sequence identities rather than inventing transition events.
    transitions = {'completed': set(), 'failed': set(), 'cancelled': set(),
        'queued': {'running', 'held', 'cancelled', 'failed'},
        'running': {'awaiting_input', 'checking', 'held', 'failed', 'cancelled', 'completed'},
        'awaiting_input': {'running', 'held', 'failed', 'cancelled'},
        'checking': {'running', 'awaiting_input', 'held', 'failed', 'cancelled', 'completed'},
        'held': {'running', 'checking', 'awaiting_input', 'cancelled', 'failed'}}
    start = 0
    for i in range(1, len(events)):
        before, after = events[i - 1]['state'], events[i]['state']
        if before != after and before in transitions and after not in transitions[before]:
            start = i
    events = events[start:]
    candidates, checks, reviews = [], [], []
    for record in view['records'].values():
        if record['attempt_id'] != attempt['id']:
            continue
        candidates.append(dict(ref=record['candidate'], scope=scope,
                               **{k: record[k] for k in ('base_digest', 'manifest',
                                  'git_tree_digest', 'artifact_digest')}))
        for collection, output in (('checks', checks), ('reviews', reviews)):
            for item in record[collection]:
                binding = {k: item['binding'][k] for k in (
                    'candidate', 'definition_digest', 'environment_digest')}
                actor = dict(id=item['actor']['id'], kind='protected_service',
                             authentication_ref=item['actor']['session_id'])
                output.append(dict(id=item['id'], request=dict(
                    id='request_' + item['id'], actor=actor, scope=scope, binding=binding,
                    issued_sequence=None), result=dict(
                    id='result_' + item['id'], request_id='request_' + item['id'],
                    actor=actor, scope=scope, binding=binding, outcome=item['verdict'],
                    error=None if item['verdict'] == 'passed' else error,
                    recorded_sequence=None)))
    usage = usage if usage is not None else view.get('journey', {}).get('usage') or {}
    limits = usage.get('limits') or dict(unit='synthetic_token', max_units=0, exhausted=True)
    current = view['records'][view['current']]['candidate'] if view['current'] else None
    snapshot = dict(contract_version='0.2.0', fixture='local_run', open_decisions={},
        project=dict(id=view['project'], runtime_container_id=None),
        task=dict(id=scope['task_id'], project_id=view['project'], isolation=dict(
            decision='G1: open', kind='user', id=None, runtime_container_id=None)),
        run=dict(id=scope['run_id'], project_id=view['project'], task_id=scope['task_id'],
                 state=status, current_candidate=current,
                 error=error if status in ('held', 'failed', 'cancelled') else None),
        attempt=dict(id=scope['attempt_id'], run_id=scope['run_id'], ordinal=attempt['ordinal']),
        candidates=candidates, checks=checks, reviews=reviews, previews=[], approvals=[],
        usage=[dict(item, scope=scope) for item in usage.get('usage', [])], limits=limits,
        commands=[], cancellation=usage.get('cancellation') or dict(requested=False, command_id=None,
                                      in_flight_command_ids=[], resolution='none'),
        events=events, reconnect=dict(after_sequence=0, mode='snapshot_required' if
            events[0]['sequence'] > 1 else 'replay', next_sequence=events[-1]['sequence'] + 1),
        authority=None, run_records=[], admissions=[])
    from journey import check_could_not_start
    # The journey records this from the full output; recompute only for older journals.
    could_not_start = {key: bool(view.get('journey', {}).get(key)) and view['journey'][key].get(
                       'could_not_start', check_could_not_start(view['journey'][key]))
                       for key in ('baseline', 'check')}
    shown = deepcopy(view)
    review = shown.get('journey', {}).get('review') or {}
    if review.get('findings_not_shown'):
        review['findings'].append('%d more reviewer findings were not shown.' % review['findings_not_shown'])
    return scrub(dict(snapshot=snapshot, view=shown, journal=deepcopy(replay),
                      could_not_start=could_not_start))


def write_page(service, run_id, folder=None):
    """Write a self-contained folder, atomically replacing each exported file.

    Read view between equal journal high-water marks so concurrent steps cannot
    combine a new view with an older replay. A busy writer yields an explicit hold.
    """
    from artifacts import Refused
    from limits import Limits
    for _ in range(3):
        replay = service.journal.replay(0)
        view = service.view(run_id)
        usage = Limits(service).view(run_id)
        if service.journal.replay(replay[-1]['sequence']) == []:
            break
    else:
        raise Refused('Run changed during page export; refresh the page export again.')
    root = Path(folder or view.get('journey', {}).get('run_folder', ''))
    if not root.is_absolute() or not root.is_dir():
        raise Refused('Run folder not recorded or unavailable.')
    page = root / 'page'
    if page.is_symlink():
        raise Refused('Linked page export folder refused.')
    page.mkdir(exist_ok=True)
    enforced = replay[-1]['state'].get('limits', {}).get(run_id, {})
    replay = [dict(sequence=row['sequence'], event=row['event'],
                   state=dict(runs={run_id: row['state']['runs'][run_id]}))
              for row in replay if run_id in row['state']['runs']]
    payload = project(view, replay, usage)
    payload['enforced_limits'] = {key: enforced.get(key) for key in ('max_seconds', 'max_turns')}
    # JSON.parse consumes a JSON string literal. No candidate byte becomes code,
    # a tag, URL or callback, even if the file is embedded in HTML later.
    literal = json.dumps(json.dumps(payload, ensure_ascii=True), ensure_ascii=True)
    literal = literal.replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    files = {name: (UI / name).read_text() for name in (
        'index.html', 'style.css', 'state.js', 'render.js', 'app.js')}
    files['index.html'] = files['index.html'].replace('src="fixtures.js"', 'src="snapshot.js"')
    files['snapshot.js'] = 'globalThis.StudioRun = JSON.parse(' + literal + ');\n'
    for name, contents in files.items():
        target = page / name
        temporary = page / (name + '.tmp')
        if target.is_symlink() or temporary.is_symlink():
            raise Refused('Linked page export file refused.')
        temporary.write_text(contents, encoding='utf-8')
        temporary.replace(target)
    return page / 'index.html'
