"""One-command local journey. Needs Python 3.11 or newer; no other dependencies."""
import argparse
import getpass
from pathlib import Path
import shutil
import sys

from journey import Journey, ClaudeCode, Licence, Refused
from page import plain
from journey import Service, SESSIONS
from page import write_page


class CommandParser(argparse.ArgumentParser):
    def error(self, message):
        # argparse errors can repeat a key supplied in a malformed command.
        super().error('Invalid command. Run ./vibe --help for usage. '
                      'For a licence key, run ./vibe licence activate and enter it when asked.')


def parser():
    result = CommandParser(description='Vibe Control local repository journey')
    commands = result.add_subparsers(dest='command', required=True)
    for name in ('demo', 'run'):
        command = commands.add_parser(name)
        if name == 'run':
            command.add_argument('repository')
            brief = command.add_mutually_exclusive_group(required=True)
            brief.add_argument('--brief')
            brief.add_argument('--brief-file')
        command.add_argument('--time-limit', type=int, default=10, metavar='MINUTES')
        # RV-A fixes sonnet in its trusted argv and tool digest. No file selects a model.
        command.add_argument('--model', choices=('sonnet',), default='sonnet')
        command.add_argument('--check')
        command.add_argument('--runs-dir', default='~/.vibe-control/runs')
        command.add_argument('--yes-plan', action='store_true')
        command.add_argument('--allow-failing-baseline', action='store_true',
                             help='Allow --yes-plan to continue when a check ran and failed.')
        command.add_argument('--new', action='store_true',
                             help='Start a fresh run of the same brief on the same repository.')
    page = commands.add_parser('page')
    page.add_argument('run_id')
    page.add_argument('--runs-dir', default='~/.vibe-control/runs')
    licence = commands.add_parser('licence').add_subparsers(dest='licence_command', required=True)
    licence.add_parser('activate')
    licence.add_parser('status')
    licence.add_parser('deactivate')
    return result


KEY_ON_COMMAND_LINE = ('The licence key is not given on the command line. Run ./vibe licence activate '
                       'and enter the key when asked.')


def installed_tool():
    path = shutil.which('claude')
    if not path:
        raise Refused('Claude Code was not found on PATH.')
    return ClaudeCode(str(Path(path).absolute()))


def main(argv=None, *, input_fn=input, output=print, interactive=None, licence=None,
         tool_factory=installed_tool, check_runner=None, launcher=None, stdin=None,
         hidden_input=getpass.getpass):
    argv = sys.argv[1:] if argv is None else list(argv)
    if argv[:2] == ['licence', 'activate'] and argv[2:]:
        output(KEY_ON_COMMAND_LINE)
        return 2
    opts = parser().parse_args(argv)
    licence = licence or Licence()
    journey = None
    try:
        if opts.command == 'page':
            journal = Path(opts.runs_dir).expanduser().resolve() / 'journal.sqlite'
            if not journal.is_file():
                raise Refused('Run journal not found.')
            service = Service(journal, SESSIONS)
            if opts.run_id not in service.journal.read()['runs']:
                raise Refused('Run not found: ' + opts.run_id)
            output(str(write_page(service, opts.run_id)))
            return 0
        if opts.command == 'licence':
            if opts.licence_command == 'activate':
                stdin = sys.stdin if stdin is None else stdin
                # As in studio/licence: a hidden prompt or standard input, never the command line.
                key = (hidden_input('Licence key: ') if stdin.isatty() else stdin.readline()).strip()
                verdict = licence.activate(key)
            else:
                verdict = getattr(licence, opts.licence_command)()
            output(verdict.reason)
            return 0 if verdict.ok else 1
        if interactive is None:
            interactive = sys.stdin.isatty() and sys.stdout.isatty()
        kwargs = dict(tool_factory=tool_factory, input_fn=input_fn, output=output,
                      interactive=interactive, licence=licence, launcher=launcher)
        if check_runner is not None:
            kwargs['check_runner'] = check_runner
        journey = Journey(opts, **kwargs)
        view = journey.run()
        return 0 if view['journey']['outcome'] == 'delivered' else 1
    except (Refused, OSError, ValueError) as exc:
        output(plain(exc, 1000))
        return 1
    except KeyboardInterrupt:
        if journey is None or journey.run_id is None:
            output('Stopped before a run started; nothing was built or published.')
        else:
            output('Stopped while finishing run %s. Run the same command again to see what '
                   'happened; nothing is rebuilt or sent again.' % journey.run_id)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
