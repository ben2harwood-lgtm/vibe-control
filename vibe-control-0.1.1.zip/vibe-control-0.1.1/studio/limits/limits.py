"""LIM: task limits, stop with in-flight reconciliation and observed usage (stdlib only).

Builds on EX1's `Service` (its journal, roles, `live` check and `revoke(stop=True)`)
and PV's `Capture`. Limits state lives in the same EX1 journal, serialized with
every EX1 change; there is no second store. No provider, network or account use.
Process control is POSIX only: process groups, signals and `/bin/ps`.
"""
from copy import deepcopy
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

_HERE = Path(__file__).resolve().parent
for _folder in ('execution', 'providers'):
    _path = str(_HERE.parent / _folder)
    if _path not in sys.path:
        sys.path.insert(0, _path)

from adapters import Capture  # noqa: E402  PV's terminal capture
from artifacts import Refused, require  # noqa: E402,F401  EX1's refusal type
from execution import Service  # noqa: E402

UNIT = 'synthetic_token'
PS = '/bin/ps'
KEY = re.compile(r'[a-z][a-z0-9_-]{0,39}')


# ---------------------------------------------------------------- processes

def processes():
    """Every visible process: pid -> ppid, pgid, zombie flag and start time."""
    try:
        out = subprocess.run(
            [PS, '-A', '-o', 'pid=', '-o', 'ppid=', '-o', 'pgid=', '-o', 'stat=', '-o', 'lstart='],
            capture_output=True, text=True, check=True, timeout=10,
            env={'LC_ALL': 'C', 'TZ': 'UTC', 'PATH': '/usr/bin:/bin'}).stdout
    except (OSError, subprocess.SubprocessError) as exc:
        raise Refused('process table unavailable: hold') from exc
    rows = {}
    for line in out.splitlines():
        parts = line.split(None, 4)
        if len(parts) == 5 and parts[0].isdigit():
            rows[int(parts[0])] = dict(ppid=int(parts[1]), pgid=int(parts[2]),
                                       zombie=parts[3].startswith('Z'),
                                       start=' '.join(parts[4].split()))
    return rows


def _alive(rows, pid, start):
    row = rows.get(pid)
    return row is not None and not row['zombie'] and row['start'] == start


def _state(rows, pid, start):
    """`dead` only when the recorded identity is provably gone, else `alive` (not confirmed).

    A pid now showing a different start time is not confirmed (the text may have
    changed, not the process). A pid that is gone while live processes remain in
    its process group is not confirmed either: they may be its own children.
    """
    row = rows.get(pid)
    if row is None:
        held = any(r['pgid'] == pid and not r['zombie'] for r in rows.values())
        return 'alive' if held else 'dead'
    return 'dead' if row['zombie'] and row['start'] == start else 'alive'


def tree(rows, known):
    """Live members of the trees rooted at recorded `{pid: start}` identities.

    Members are found by parent links and by process group. A recorded leader's
    group is followed while the leader matches its record (alive or a zombie). Once
    the leader is gone its group is followed only while a recorded member that
    still matches its own record is in it: a bare group id may now be someone else's.
    A child that called setsid() is found while its parent is alive or once
    `observe` has recorded it; an unobserved orphan is outside this boundary.
    """
    members = {p: s for p, s in known.items() if _alive(rows, p, s)}
    matched = {p for p, s in known.items() if p in rows and rows[p]['start'] == s}
    groups = {p for p in known if p in matched or
              (p not in rows and any(rows[q]['pgid'] == p for q in matched))}
    while True:
        new = {p: r['start'] for p, r in rows.items() if p not in members and not r['zombie']
               and (r['ppid'] in members or r['pgid'] in groups)}
        if not new:
            return members
        members.update(new)
        groups.update(p for p in new if rows[p]['pgid'] == p)


def _signal(pid, sig, refused):
    try:
        os.kill(pid, sig)
    except ProcessLookupError:
        pass
    except PermissionError:
        refused.add(pid)


def kill_trees(known, deadline_seconds):
    """Freeze every member (no more forks), kill them all, then confirm by deadline.

    Returns each identity as `dead` or `alive`; `alive` means not confirmed dead.
    """
    end = time.monotonic() + deadline_seconds
    rows, targets, refused, complete = processes(), {}, set(), False
    while True:
        new = {p: s for p, s in tree(rows, {**known, **targets}).items() if p not in targets}
        if not new:
            complete = True
            break
        for pid in new:
            _signal(pid, signal.SIGSTOP, refused)
        targets.update(new)
        if time.monotonic() > end:
            break
        rows = processes()
    for pid in targets:
        _signal(pid, signal.SIGKILL, refused)
    for group in {rows[p]['pgid'] for p in targets if p in rows and rows[p]['pgid'] in targets}:
        try:
            os.killpg(group, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
    while True:
        for pid in targets:  # Reap our own children so they are not counted alive.
            try:
                os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                pass
        rows = processes()
        if all(_state(rows, p, s) == 'dead' for p, s in targets.items()) or time.monotonic() > end:
            break
        time.sleep(0.05)
    found = {**known, **targets}
    return dict(complete=complete, processes=[
        dict(pid=p, start=s, state=_state(rows, p, s)) for p, s in sorted(found.items())])


# ---------------------------------------------------------------- limits

def _charged(r):
    if r['state'] == 'settled':
        return r['observed_units']
    return max(r['units'], r['observed_units'])  # No refund until a complete capture.


def _refusal(lim, now, units):
    reservations = lim['reservations'].values()
    observed = sum(r['observed_units'] for r in reservations)
    if observed >= lim['max_units']:
        return 'budget exhausted: observed usage reached the limit'
    if sum(_charged(r) for r in reservations) + units > lim['max_units']:
        return 'budget exhausted: this request would exceed the limit'
    if len(lim['reservations']) >= lim['max_turns']:
        return 'turn limit reached'
    if lim['started_at'] is not None and now >= lim['started_at'] + lim['max_seconds']:
        return 'time limit reached'
    return None


def _count(n, word, many=None):
    return '%d %s' % (n, word if n == 1 else (many or word + 's'))


def exposure(*, refused, remaining, max_units, in_flight, reserved, unknown, actions, unconfirmed):
    """The plain sentence the UI shows about what in-flight work can still incur."""
    parts = ['New work is refused: %s.' % refused if refused else
             'New work is accepted only if it fits in the %d %s left of %d.' % (
                 remaining, UNIT, max_units)]
    if in_flight:
        parts.append('%s already in flight can still use usage: %d %s is reserved for %s, '
                     'and a provider can charge for work it already started even beyond that.' % (
                         _count(in_flight, 'request'), reserved, UNIT,
                         'it' if in_flight == 1 else 'them'))
    if unknown:
        parts.append('Final usage is unknown for %s until it is reconciled.' % _count(unknown, 'request'))
    if actions:
        parts.append('%s may already have landed and must be reconciled.' % _count(actions, 'outward action'))
    if unconfirmed:
        parts.append('%s could not be confirmed stopped and may still be running.' % _count(
            unconfirmed, 'process', 'processes'))
    if not (in_flight or actions or unconfirmed):
        parts.append('Nothing is recorded in flight for this task.')
    parts.append('These are synthetic units, not a bill.')
    return ' '.join(parts)


class Limits:
    """Per-task limits over one EX1 service. Every check runs in an EX1 transaction."""

    def __init__(self, service):
        require(type(service) is Service, 'EX1 service required')
        self.service = service
        self.journal = service.journal

    def _entry(self, state, run_id, token, role):
        run = state['runs'].get(run_id)
        require(run is not None, 'unknown run')
        self.service.principal(token, role, run['project'])
        lim = state.setdefault('limits', {}).setdefault(run_id, dict(
            max_units=None, max_turns=None, max_seconds=None, started_at=None,
            reservations={}, processes={}, termination=None))
        return run, lim

    def _running(self, state, run):
        self.service.live(state, run)  # exact approved plan, not stopped, current generation
        attempt = run['attempts'][-1]
        require(attempt['state'] == 'running' and attempt['lease'] is not None, 'no running lease')
        return attempt

    def set_limits(self, token, run_id, *, max_units, max_turns, max_seconds):
        for value in (max_units, max_turns, max_seconds):
            require(type(value) is int and value > 0, 'limits must be positive integers')
        with self.journal.change('limits_set') as state:
            run, lim = self._entry(state, run_id, token, 'customer')
            require(lim['max_units'] is None, 'limits already set')
            require(not run['stopped'], 'stopped task')
            lim.update(max_units=max_units, max_turns=max_turns, max_seconds=max_seconds)

    def reserve(self, token, run_id, key, units):
        """Reserve before each chargeable turn; refuse work that would exceed known limits."""
        require(type(key) is str and KEY.fullmatch(key), 'reservation key')
        require(type(units) is int and units > 0, 'reservation units')
        with self.journal.change('limits_reserve') as state:
            run, lim = self._entry(state, run_id, token, 'control_service')
            old = lim['reservations'].get(key)
            if old is not None:  # A retry of the same open turn replays it, with no new charge.
                require(old['units'] == units, 'reservation key conflict')
                require(old['state'] == 'reserved', 'reservation key already used')
            require(lim['max_units'] is not None, 'no task limits set')
            attempt = self._running(state, run)
            require(old is None or old['attempt'] == attempt['id'],
                    'reservation belongs to a superseded attempt')
            now = self.service.clock()
            if lim['started_at'] is None:
                lim['started_at'] = now
            others = {k: r for k, r in lim['reservations'].items() if k != key}
            reason = _refusal(dict(lim, reservations=others), now, units)
            require(reason is None, reason)
            if old is not None:
                return deepcopy(old)
            reservation = dict(key=key, units=units, attempt=attempt['id'], state='reserved',
                               observed_units=0, complete=False, outcome=None, reason=None)
            lim['reservations'][key] = reservation
        return deepcopy(reservation)

    def settle(self, token, run_id, key, capture):
        """Record PV's observed usage. Incomplete usage stays charged at the reservation."""
        require(type(capture) is Capture and type(capture.fixture_only) is bool and
                type(capture.observed_units) is int and capture.observed_units >= 0 and
                type(capture.complete) is bool, 'PV capture required')
        with self.journal.change('limits_settle') as state:
            _, lim = self._entry(state, run_id, token, 'control_service')
            r = lim['reservations'].get(key)
            require(r is not None, 'unknown reservation')
            fields = dict(observed_units=capture.observed_units, complete=capture.complete,
                          outcome=capture.outcome, reason=capture.reason)
            if r['state'] == 'settled':
                require(all(r[k] == v for k, v in fields.items()), 'settled usage cannot change')
                return deepcopy(r)
            require(capture.observed_units >= r['observed_units'], 'observed usage cannot decrease')
            r.update(fields, state='settled' if capture.complete else 'unknown')
        return deepcopy(r)

    def register(self, token, run_id, pid):
        """Record a task process the launcher started with its own session/group."""
        rows = processes()
        row = rows.get(pid) if type(pid) is int else None
        require(row is not None and pid > 1 and not row['zombie'] and row['pgid'] == pid and
                pid != os.getpgrp(), 'task process must lead its own process group')
        with self.journal.change('limits_process') as state:
            run, lim = self._entry(state, run_id, token, 'control_service')
            attempt = self._running(state, run)
            lim['processes'].setdefault('%d:%s' % (pid, row['start']), dict(
                pid=pid, start=row['start'], attempt=attempt['id'], state='running'))

    def _known(self, run_id):
        lim = self.journal.read().get('limits', {}).get(run_id) or dict(processes={})
        return {p['pid']: p['start'] for p in lim['processes'].values() if p['state'] != 'dead'}

    def _record(self, lim, run, found, state='running'):
        for pid, start in found.items():
            lim['processes'].setdefault('%d:%s' % (pid, start), dict(
                pid=pid, start=start, attempt=run['attempts'][-1]['id'], state=state))

    def observe(self, token, run_id):
        """Record current descendants, so one that detaches later is still stopped."""
        found = tree(processes(), self._known(run_id))
        with self.journal.change('limits_observe') as state:
            run, lim = self._entry(state, run_id, token, 'control_service')
            self._record(lim, run, found)

    def terminate(self, token, run_id, deadline_seconds=5.0):
        """Kill every recorded process tree; record each as dead or not confirmed dead."""
        with self.journal.change('limits_terminate_start') as state:
            self._entry(state, run_id, token, 'control_service')
        result = kill_trees(self._known(run_id), deadline_seconds)
        with self.journal.change('limits_terminate') as state:
            run, lim = self._entry(state, run_id, token, 'control_service')
            self._record(lim, run, {p['pid']: p['start'] for p in result['processes']})
            for item in result['processes']:
                lim['processes']['%d:%s' % (item['pid'], item['start'])]['state'] = item['state']
            lim['termination'] = dict(complete=result['complete'], at=self.service.clock())
        return result

    def stop(self, customer_token, service_token, run_id, deadline_seconds=5.0):
        """Fence first (EX1 revoke with stop), then kill the trees, then report."""
        self.service.revoke(customer_token, run_id, stop=True)
        self.terminate(service_token, run_id, deadline_seconds)
        return self.view(run_id)

    def termination_proven(self, run_id):
        """True only after a complete termination confirmed every recorded process dead."""
        lim = self.journal.read().get('limits', {}).get(run_id)
        return bool(lim and lim['termination'] and lim['termination']['complete'] and
                    all(p['state'] == 'dead' for p in lim['processes'].values()))

    def view(self, run_id):
        """What the UI reads: contract-shaped limits/usage/cancellation plus the exposure line."""
        state = self.journal.read()
        run = state['runs'][run_id]
        lim = deepcopy(state.get('limits', {}).get(run_id) or dict(
            max_units=None, reservations={}, processes={}, termination=None))
        reservations = [lim['reservations'][k] for k in sorted(lim['reservations'])]
        open_ = [r for r in reservations if r['state'] != 'settled']
        actions = ['command_' + op['id'] for record in run['records'].values()
                   for op in record['publications'] if op['outcome'] in {'received', 'uncertain', 'held'}]
        unconfirmed = [p for p in lim['processes'].values() if p['state'] != 'dead']
        observed = sum(r['observed_units'] for r in reservations)
        if lim['max_units'] is None:
            refused, remaining = 'no task limits set', 0
        else:
            remaining = max(0, lim['max_units'] - sum(_charged(r) for r in reservations))
            refused = ('task stopped' if run['stopped'] else
                       _refusal(lim, self.service.clock(), 1))
        stopped = run['stopped']
        if not stopped:
            resolution = 'none'
        elif lim['termination'] is None:
            resolution = 'pending'
        elif open_ or actions or unconfirmed or not lim['termination']['complete']:
            resolution = 'held'
        else:
            resolution = 'reconciled'

        def scope(attempt):
            return dict(project_id=run['project'], task_id=run['task'],
                        run_id='run_' + run['id'], attempt_id='attempt_' + attempt)

        return dict(
            state='cancelled' if resolution == 'reconciled' else 'held' if stopped
            else run['attempts'][-1]['state'],
            limits=None if lim['max_units'] is None else dict(
                unit=UNIT, max_units=lim['max_units'], exhausted=observed >= lim['max_units']),
            usage=[dict(id='usage_' + r['key'], scope=scope(r['attempt']), observed_units=r['observed_units'],
                        unit=UNIT, complete=r['complete']) for r in reservations if r['state'] != 'reserved'],
            cancellation=dict(
                requested=stopped, command_id='cancel_' + run['id'] if stopped else None,
                in_flight_command_ids=(['reservation_' + r['key'] for r in open_] + actions)
                if stopped else [], resolution=resolution),
            refusing_new_work=refused is not None, refusal=refused,
            observed_units=observed, reserved_units=sum(_charged(r) for r in open_),
            turns_used=len(reservations), processes=sorted(lim['processes'].values(),
                                                           key=lambda p: (p['pid'], p['start'])),
            termination_proven=self.termination_proven(run_id),
            exposure=exposure(refused=refused, remaining=remaining, max_units=lim['max_units'] or 0,
                              in_flight=len(open_), reserved=sum(_charged(r) for r in open_),
                              unknown=sum(r['state'] == 'unknown' for r in reservations),
                              actions=len(actions), unconfirmed=len(unconfirmed)))
