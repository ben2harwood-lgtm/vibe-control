"""PV fake-only launch descriptions and candidate-bound review wiring (stdlib).

No process launcher, credential input, environment access or provider client lives
here. Command shapes are hypotheses for RV-A/RV-O, not verified CLI contracts.
"""
from dataclasses import asdict, dataclass
import hashlib
import json
import re
from typing import Protocol
from uuid import uuid4


COMMANDS = {
    'claude': ('claude', '--print', '--output-format', 'json'),
    'codex': ('codex', 'exec', '--json', '-'),
}


def digest(data: bytes) -> str:
    return 'sha256:' + hashlib.sha256(data).hexdigest()


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r'[a-z][a-z0-9_-]{0,79}', value):
        raise ValueError('invalid identifier')


@dataclass(frozen=True)
class Binding:
    candidate_id: str
    candidate_digest: str
    definition_digest: str
    environment_digest: str

    def __post_init__(self):
        identifier(self.candidate_id)
        for value in (self.candidate_digest, self.definition_digest, self.environment_digest):
            if not isinstance(value, str) or not re.fullmatch(r'sha256:[0-9a-f]{64}', value):
                raise ValueError('invalid digest')

    def record(self):
        return dict(candidate=dict(id=self.candidate_id, digest=self.candidate_digest),
                    definition_digest=self.definition_digest,
                    environment_digest=self.environment_digest)


@dataclass(frozen=True)
class Invocation:
    family: str
    role: str
    binding: Binding
    context_id: str
    argv: tuple[str, ...]
    stdin: str
    timeout_seconds: int
    max_units: int


def invocation(family, role, binding, candidate: bytes, *, timeout_seconds=30, max_units=100):
    """Describe a new one-shot CLI context; never execute it or resume a session.

    Candidate text goes only into stdin data, never argv or shell syntax. The
    future trusted launcher owns runtime isolation and built-in authentication.
    """
    if family not in {'claude', 'codex'} or role not in {'builder', 'reviewer'}:
        raise ValueError('unsupported family or role')
    if type(timeout_seconds) is not int or timeout_seconds <= 0:
        raise ValueError('invalid timeout')
    if type(max_units) is not int or max_units <= 0:
        raise ValueError('invalid synthetic limit')
    if digest(candidate) != binding.candidate_digest:
        raise ValueError('candidate bytes changed')
    # No options, model names, settings, auth modes or executables from candidate data.
    argv = COMMANDS[family]
    context = 'context_' + uuid4().hex
    payload = json.dumps(dict(fixture_only=True, role=role, context_id=context,
                              binding=binding.record(), untrusted_candidate=candidate.decode('utf-8')))
    return Invocation(family, role, binding, context, argv, payload, timeout_seconds, max_units)


@dataclass(frozen=True)
class Capture:
    outcome: str
    reason: str | None
    observed_units: int
    complete: bool
    identity: str = 'UNVERIFIABLE'
    fixture_only: bool = True


class Adapter(Protocol):
    """Invocation -> terminal capture; no credential parameter or raw output log."""
    def run(self, command: Invocation) -> Capture: ...


# B02 has a closed error-code set. Keep provider-specific reasons in this module;
# export the closest conservative contract error without extending that contract.
ERRORS = {
    'refusal': ('denied', 'never'),
    'authentication_failure': ('denied', 'never'),
    'quota_exhausted': ('budget_exhausted', 'new_attempt'),
    'limit_exhausted': ('budget_exhausted', 'new_attempt'),
    'timeout': ('provider_timeout', 'reconcile_or_hold'),
    'partial_stream': ('uncertain_action', 'reconcile_or_hold'),
    'unavailable': ('uncertain_action', 'reconcile_or_hold'),
    'malformed_output': ('uncertain_action', 'reconcile_or_hold'),
    'cancelled': ('cancelled', 'new_attempt'),
    'identity_unverifiable': ('denied', 'never'),
    'review_rejected': ('denied', 'new_attempt'),
}


def capture(family, raw, max_units):
    """Parse only our tiny synthetic envelopes, never real-provider output.

    Invalid or partial output supplies no reliable usage total. Unknown usage is
    incomplete zero observed units, never a claim of zero cost or success.
    """
    try:
        row = json.loads(raw)
        keys = ('type', 'status', 'units') if family == 'claude' else ('event', 'outcome', 'units')
        tag = 'fake.result' if family == 'claude' else 'fake.turn.completed'
        if family not in {'claude', 'codex'} or set(row) != set(keys) or row[keys[0]] != tag:
            raise ValueError()
        status, units = row[keys[1]], row['units']
        if status not in {'success', *ERRORS} or type(units) is not int or units < 0:
            raise ValueError()
    except (ValueError, TypeError, KeyError):
        return Capture('uncertain', 'malformed_output', 0, False)
    if status in {'timeout', 'partial_stream', 'unavailable', 'malformed_output'}:
        return Capture('uncertain', status, units, False)
    if units >= max_units:
        return Capture('denied', 'limit_exhausted', units, True)
    if status == 'success':
        return Capture('passed', None, units, True)
    outcome = 'cancelled' if status == 'cancelled' else 'failed' if status == 'review_rejected' else 'denied'
    return Capture(outcome, status, units, True)


class FakeProvider:
    """Deterministic fake outcome selection; never imports or executes a CLI.

    Unknown scenarios fail before dispatch. There is no paid fallback or retry.
    The timeout case simulates elapsed-time expiry without sleeping.
    """
    def __init__(self, scenario='success'):
        if scenario not in {'success', *ERRORS}:
            raise ValueError('unknown fake scenario')
        self.scenario = scenario

    def run(self, command):
        # Consume the proposed command shape and its stdin, rather than accepting
        # an arbitrary executable, resume flag or provider-chosen binding.
        if command.family not in COMMANDS or command.argv != COMMANDS[command.family]:
            raise ValueError('unsupported fake command shape')
        payload = json.loads(command.stdin)
        expected = dict(fixture_only=True, role=command.role, context_id=command.context_id,
                        binding=command.binding.record(), untrusted_candidate=payload['untrusted_candidate'])
        if (payload != expected or command.role not in {'builder', 'reviewer'}
                or digest(payload['untrusted_candidate'].encode('utf-8')) != command.binding.candidate_digest):
            raise ValueError('fake command payload mismatch')
        status = self.scenario
        units = 12
        if status == 'malformed_output':
            raw = '{'
        elif command.family == 'claude':
            raw = json.dumps(dict(type='fake.result', status=status, units=units))
        else:
            raw = json.dumps(dict(event='fake.turn.completed', outcome=status, units=units))
        return capture(command.family, raw, command.max_units)


def review(adapter: Adapter, *, family, builder_family, binding, candidate,
           scope, requester, reviewer, issued_sequence, recorded_sequence,
           timeout_seconds=30, max_units=100):
    """Return B02 request/result and usage, plus explicit synthetic provenance.

    scope/requester/reviewer and the contract 0.2.0 journal sequences MUST come
    from the protected control service, never from the candidate or provider.
    This function does not authenticate callers or assign journal positions.
    No provider response may choose a binding, actor, result ID or verdict field.
    """
    if builder_family not in {'claude', 'codex'} or builder_family == family:
        raise ValueError('review needs a different family')
    if not (type(issued_sequence) is int and type(recorded_sequence) is int and
            0 < issued_sequence < recorded_sequence):
        raise ValueError('invalid journal sequence')
    command = invocation(family, 'reviewer', binding, candidate,
                         timeout_seconds=timeout_seconds, max_units=max_units)
    # Snapshot caller records before provider execution; never take them from output.
    scope, requester, reviewer = (dict(value) for value in (scope, requester, reviewer))
    if set(scope) != {'project_id', 'task_id', 'run_id', 'attempt_id'}:
        raise ValueError('invalid scope')
    for actor in (requester, reviewer):
        if set(actor) != {'id', 'kind', 'authentication_ref'} or actor['kind'] not in {'local_user', 'protected_service'}:
            raise ValueError('invalid actor')
        identifier(actor['id'])
        identifier(actor['authentication_ref'])
    for value in scope.values():
        identifier(value)
    if requester['id'] == reviewer['id']:
        raise ValueError('reviewer must be distinct from requester')
    observed = adapter.run(command)
    error = None
    if observed.reason is not None:
        code, retry = ERRORS[observed.reason]
        error = dict(code=code, message='Fake provider: ' + observed.reason, retry=retry)
    request_id = 'request_' + uuid4().hex
    request = dict(id=request_id, actor=requester, scope=scope, binding=binding.record(),
                   issued_sequence=issued_sequence)
    result = dict(id='result_' + uuid4().hex, request_id=request_id, actor=reviewer,
                  scope=dict(scope), binding=binding.record(), outcome=observed.outcome, error=error,
                  recorded_sequence=recorded_sequence)
    return dict(id='review_' + uuid4().hex, request=request, result=result), dict(
        id='usage_' + uuid4().hex, scope=dict(scope), observed_units=observed.observed_units,
        unit='synthetic_token', complete=observed.complete), dict(
        capture=asdict(observed), context_id=command.context_id, family=family,
        builder_family=builder_family, real_provider_compatibility='unproven')


def current_review(assessment, *, binding, scope, request_id):
    """Check freshness for display/routing only; never establishes acceptance."""
    request, result = assessment['request'], assessment['result']
    return (result is not None and request['id'] == request_id == result['request_id']
            and request['scope'] == result['scope'] == scope
            and request['binding'] == result['binding'] == binding.record())
