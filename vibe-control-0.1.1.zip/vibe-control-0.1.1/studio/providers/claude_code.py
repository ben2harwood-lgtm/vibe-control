"""RV-A: launch the unmodified, user-signed-in Claude Code CLI as builder or reviewer.

Stdlib only. The trusted launcher fixes the executable (absolute path) and reads
its version once; options are constants in this file. Brief and candidate text go
in on stdin only, never into argv, environment, model, settings or paths. This
module never reads the tool's sign-in, keychain or credential files: it passes the
user's HOME and USER so the tool can find its own sign-in. Process-tree stop
reuses LIM (`limits.kill_trees`); there is no second killer here.
"""
from contextlib import closing
from dataclasses import asdict
import json
import os
from pathlib import Path
import re
import select
import signal
import subprocess
import sys
import tempfile
import threading
import time

_HERE = Path(__file__).resolve().parent
for _folder in ('providers', 'execution', 'limits'):
    _path = str(_HERE.parent / _folder)
    if _path not in sys.path:
        sys.path.insert(0, _path)

from adapters import COMMANDS, Capture, digest  # noqa: E402
from artifacts import Refused, require, restore  # noqa: E402
from limits import kill_trees, processes  # noqa: E402

FAMILY = 'claude-code'
MODEL = 'sonnet'
VERDICT_SCHEMA = dict(
    type='object', additionalProperties=False, required=['verdict', 'findings'],
    properties=dict(verdict=dict(type='string', enum=['approve', 'reject']),
                    findings=dict(type='array', items=dict(type='string'))))
_COMMON = ('--print', '--output-format', 'json', '--model', MODEL, '--restricted',
           '--strict-mcp-config', '--safe-mode', '--disable-slash-commands',
           '--permission-prompts', 'none', '--no-session-persistence')
OPTIONS = {
    # File read, search and edit only; edits inside the workspace accepted, all else denied.
    'builder': _COMMON + ('--tools', 'Read,Grep,Glob,Edit,Write', '--permission-mode', 'acceptEdits'),
    # Read-only tools; structured verdict.
    'reviewer': _COMMON + ('--tools', 'Read,Grep,Glob', '--permission-mode', 'dontAsk',
                           '--json-schema', json.dumps(VERDICT_SCHEMA, sort_keys=True,
                                                       separators=(',', ':'))),
}
PASSED_ENV = ('HOME', 'USER', 'LANG', 'TMPDIR')
SECRET = re.compile(r'KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL', re.IGNORECASE)
NOT_SIGNED_IN = ('Claude Code is not signed in, or its account cannot be used right now (sign-in or billing). Run `claude` once and check it works, then start a fresh '
                 'run with --new (for the demo: `./vibe demo --new`).')
SIGN_IN = re.compile(r'log ?in|sign ?in|api key|billed|billing|credit balance', re.IGNORECASE)
KILL_DEADLINE = 5.0


def environment(executable):
    """Only what the tool needs to find the user's own sign-in and run."""
    env = {name: os.environ[name] for name in PASSED_ENV
           if name in os.environ and not SECRET.search(name)}
    env['PATH'] = str(Path(executable).parent) + ':/usr/bin:/bin'
    return env  # CLAUDECODE, CLAUDE_CODE_ENTRYPOINT and everything else are dropped.


def parse(raw, *, returncode, timed_out, max_units=None):
    """Map one real `--output-format json` reply to an honest Capture plus details.

    Never `passed` on timeout, non-zero exit, is_error, malformed JSON or any
    permission denial. Usage is input + output tokens as observed units; missing
    usage is unknown and incomplete, never zero cost.
    """
    details = dict(usage=None, cache=None, models_reported=[], permission_denials=None,
                   result_text=None, structured_output=None, returncode=returncode,
                   timed_out=timed_out, subtype=None)
    try:
        row = json.loads(raw)
        require(isinstance(row, dict) and row.get('type') == 'result', 'not a result object')
    except (ValueError, TypeError):
        row = None
    units, complete = 0, False
    if row is not None:
        usage = row.get('usage')
        if (isinstance(usage, dict) and all(type(usage.get(k)) is int and usage[k] >= 0
                                            for k in ('input_tokens', 'output_tokens'))):
            units, complete = usage['input_tokens'] + usage['output_tokens'], True
            details['usage'] = dict(input_tokens=usage['input_tokens'],
                                    output_tokens=usage['output_tokens'])
            details['cache'] = {k: usage[k] for k in ('cache_creation_input_tokens',
                                                      'cache_read_input_tokens') if k in usage}
        models = row.get('modelUsage')
        details['models_reported'] = sorted(models) if isinstance(models, dict) else []
        details.update(permission_denials=row.get('permission_denials'),
                       result_text=row.get('result') if isinstance(row.get('result'), str) else None,
                       structured_output=row.get('structured_output'), subtype=row.get('subtype'))

    def out(outcome, reason):
        return Capture(outcome, reason, units, complete and outcome != 'uncertain',
                       fixture_only=False), details

    if timed_out:
        return out('uncertain', 'timeout')
    if row is None:
        return out('uncertain', 'malformed_output')
    if returncode is None:  # exit status never observed: a success reply alone is not a pass
        return out('uncertain', 'unavailable')
    if row.get('is_error') is not False or returncode != 0 or row.get('subtype') != 'success':
        if SIGN_IN.search(details['result_text'] or ''):
            return out('denied', 'authentication_failure')
        return out('uncertain' if returncode != 0 else 'failed', 'unavailable')
    denials = row.get('permission_denials')
    if not isinstance(denials, list):
        return out('uncertain', 'malformed_output')
    if denials:
        return out('denied', 'refusal')
    if max_units is not None and complete and units >= max_units:
        return out('denied', 'limit_exhausted')
    return out('passed', None)


def verdict(capture, details):
    """approve / reject only from an exact structured reply; anything else is uncertain."""
    value = details.get('structured_output')
    if (capture.outcome == 'passed' and isinstance(value, dict) and set(value) == {'verdict', 'findings'}
            and type(value['verdict']) is str and value['verdict'] in {'approve', 'reject'} and isinstance(value['findings'], list)
            and all(isinstance(f, str) for f in value['findings'])):
        return value['verdict'], list(value['findings'])
    return 'uncertain', []


def _pump(proc, data):
    """Feed stdin and drain stdout and stderr in threads, so the tool never blocks on a pipe.

    Returns `collect(seconds)`: stdout once both readers finish, or b'' if a
    surviving process still holds the pipe open.
    """
    out = []

    def feed():
        try:
            proc.stdin.write(data)
        except OSError:
            pass
        finally:
            try:
                proc.stdin.close()
            except OSError:
                pass

    def drain(stream, keep):
        chunk = stream.read()
        if keep:
            out.append(chunk)

    threads = [threading.Thread(target=feed, daemon=True),
               threading.Thread(target=drain, args=(proc.stdout, True), daemon=True),
               threading.Thread(target=drain, args=(proc.stderr, False), daemon=True)]
    for thread in threads:
        thread.start()

    def collect(seconds):
        end = time.monotonic() + seconds
        for thread in threads:
            thread.join(max(0, end - time.monotonic()))
        return out[0] if out and not any(t.is_alive() for t in threads) else b''
    return collect


def _watch(pid, seconds):
    """'exited' once our child `pid` has exited, WITHOUT reaping it; 'running' at the
    time limit; 'lost' if it was reaped elsewhere, so its exit status is unknowable."""
    if hasattr(select, 'kqueue'):  # macOS: an exit note; a zombie reports at once.
        with closing(select.kqueue()) as queue:
            note = select.kevent(pid, select.KQ_FILTER_PROC,
                                 select.KQ_EV_ADD | select.KQ_EV_ONESHOT, select.KQ_NOTE_EXIT)
            try:
                return 'exited' if queue.control([note], 1, seconds) else 'running'
            except ProcessLookupError:
                return 'exited'
    end = time.monotonic() + seconds
    while time.monotonic() < end:  # Linux
        try:
            if os.waitid(os.P_PID, pid, os.WEXITED | os.WNOWAIT | os.WNOHANG) is not None:
                return 'exited'
        except ChildProcessError:
            return 'lost'  # another part of this process already reaped the tool
        time.sleep(0.02)
    return 'running'


def _exited(pid, seconds):
    """True once our child `pid` has exited, WITHOUT reaping it; False at the time limit."""
    return _watch(pid, seconds) != 'running'


def _identity(path):
    """The real file behind `path` and enough of its state to notice a swap or an edit."""
    real = Path(path).resolve(strict=True)
    info = real.stat()
    return dict(real=str(real), dev=info.st_dev, ino=info.st_ino, size=info.st_size,
                mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns)


class ClaudeCode:
    """The trusted launcher's fixed tool: absolute executable path and its version."""

    def __init__(self, executable):
        require(isinstance(executable, str) and os.path.isabs(executable) and
                os.path.isfile(executable) and os.access(executable, os.X_OK),
                'absolute path to the Claude Code executable required')
        self.executable = executable  # launched by the path it was found at
        self.identity = _identity(executable)
        try:
            done = subprocess.run([executable, '--version'], capture_output=True, text=True,
                                  timeout=30, env=environment(executable), stdin=subprocess.DEVNULL,
                                  cwd=tempfile.gettempdir())
        except (OSError, subprocess.SubprocessError) as exc:
            raise Refused('tool version unavailable') from exc
        line = done.stdout.strip().splitlines()[0] if done.stdout.strip() else ''
        require(done.returncode == 0 and re.fullmatch(r'[0-9][0-9A-Za-z.+-]* \(Claude Code\)', line),
                'unrecognised tool version')
        self.version = line
        self.verify()

    def verify(self):
        """Refuse unless the file behind the path is the one the version was read from."""
        try:
            same = _identity(self.executable) == self.identity
        except (OSError, RuntimeError):
            same = False
        require(same, 'Claude Code changed since this run was set up; start a new run')

    def argv(self, role):
        return [self.executable, *OPTIONS[role]]

    def tool_digest(self, role):
        return digest(json.dumps(dict(version=self.version, options=list(OPTIONS[role])),
                                 sort_keys=True).encode())

    def launch(self, role, workspace, prompt, timeout_seconds, *, max_units=None, on_start=None):
        """One fresh one-shot run with `workspace` as its only working directory."""
        require(role in OPTIONS and isinstance(prompt, str), 'role and prompt')
        require(type(timeout_seconds) in (int, float) and timeout_seconds > 0, 'time limit')
        self.verify()  # immediately before every launch
        argv = self.argv(role)
        started = time.monotonic()
        proc = subprocess.Popen(argv, cwd=str(workspace), env=environment(self.executable),
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, start_new_session=True)
        try:
            row = processes().get(proc.pid)
        except Refused:
            # No recorded identity to sweep by. The unreaped tool still owns its pid and
            # group, so stopping that group is safe; the run is not passed.
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                pass
            proc.communicate()
            return self._finish(role, started, Capture('uncertain', 'unavailable', 0, False,
                                                       fixture_only=False),
                                dict(returncode=proc.returncode, timed_out=False,
                                     error='process table unavailable at launch'), None, [])
        known = {proc.pid: row['start']} if row else {}
        timed_out, stop, collect, lost = False, None, None, False
        try:
            if on_start is not None:
                on_start(proc.pid)
            collect = _pump(proc, prompt.encode('utf-8'))
            state = _watch(proc.pid, timeout_seconds)
            lost = state == 'lost'
            if state == 'running':
                timed_out = True
                stop = kill_trees(known, KILL_DEADLINE)
        except BaseException:
            kill_trees(known, KILL_DEADLINE)
            if collect is None:
                proc.communicate()
            else:
                proc.wait()
                collect(KILL_DEADLINE)
            raise
        # The tool has exited but is not reaped yet: it is a zombie whose pid and start
        # time still match the record, so LIM follows its process group and stops
        # anything left in it. Only then is it reaped.
        leftover = kill_trees(known, KILL_DEADLINE)
        proc.wait()
        out = collect(KILL_DEADLINE)
        capture, details = parse(out.decode('utf-8', 'replace'), returncode=None if lost else proc.returncode,
                                 timed_out=timed_out, max_units=max_units)
        if lost:
            details['error'] = 'exit status not observed'
        return self._finish(role, started, capture, details, stop,
                            [p for p in leftover['processes'] if p['pid'] != proc.pid])

    def _finish(self, role, started, capture, details, stop, leftover):
        details.update(
            tool=dict(executable=self.executable, version=self.version, options=list(OPTIONS[role]),
                      tool_digest=self.tool_digest(role)),
            identity=dict(models_reported=details.get('models_reported', []), status='REPORTED',
                          verified='UNVERIFIABLE'),
            wall_seconds=round(time.monotonic() - started, 3),
            stop=stop, leftover_processes=leftover)
        return capture, details

    def run(self, command):
        """Adapter.run(Invocation) -> Capture in a fresh empty folder; stdin is the prompt."""
        require(command.family == 'claude' and command.argv == COMMANDS['claude'] and
                command.role in OPTIONS, 'unsupported command shape')
        with tempfile.TemporaryDirectory() as folder:
            capture, details = self.launch(command.role, folder, command.stdin,
                                           command.timeout_seconds, max_units=command.max_units)
        result = verdict(capture, details)[0] if command.role == 'reviewer' else 'approve'
        if capture.outcome == 'passed' and result == 'reject':
            return Capture('failed', 'review_rejected', capture.observed_units, capture.complete,
                           fixture_only=False)
        if capture.outcome == 'passed' and result == 'uncertain':
            return Capture('uncertain', 'malformed_output', capture.observed_units, False,
                           fixture_only=False)
        return capture

    def review(self, manifest, brief, timeout_seconds):
        """Fresh reviewer run on a restored copy of the frozen candidate, never a live workspace."""
        with tempfile.TemporaryDirectory() as folder:
            copy = restore(manifest, Path(folder).resolve() / 'candidate')
            prompt = ('Review the files in the current folder against the brief below. '
                      'Approve only if the brief is met. Return your verdict.\n\nBRIEF:\n' + brief)
            capture, details = self.launch('reviewer', copy, prompt, timeout_seconds)
        result, findings = verdict(capture, details)
        return dict(verdict=result, findings=findings, capture=asdict(capture), details=details)


class ClaudeCodeAgent:
    """EX1's second trusted agent type: the real builder role on the task workspace."""
    family = FAMILY

    def __init__(self, tool, brief, time_limit_seconds, *, on_start=None):
        require(type(tool) is ClaudeCode and isinstance(brief, str), 'trusted tool and brief')
        require(type(time_limit_seconds) is int and time_limit_seconds > 0, 'time limit')
        self.tool, self.brief, self.time_limit_seconds = tool, brief, time_limit_seconds
        self.on_start = on_start
        self.tool_digest = tool.tool_digest('builder')
        self.capture = self.details = None

    def run(self, workspace):
        self.capture, self.details = self.tool.launch(
            'builder', workspace, self.brief, self.time_limit_seconds, on_start=self.on_start)
        require(self.capture.reason != 'authentication_failure', NOT_SIGNED_IN)
        require(self.capture.outcome == 'passed',
                'builder run not passed: %s %s' % (self.capture.outcome, self.capture.reason))
