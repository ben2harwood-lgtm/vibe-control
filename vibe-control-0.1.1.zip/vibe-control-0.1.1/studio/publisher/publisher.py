"""PR (P5d): branch and pull request from a frozen candidate, after EX1 admission.

`Publisher` has EX1's endpoint shape (`write`/`query`). It pushes only objects built
from the protected manifest into a fresh repository it creates itself, never a task
worktree, with a clean environment and candidate/user Git routes switched off, then
optionally opens a pull request through an injected function. Remotes are local
bare or non-bare repositories and the pull-request API is a fake; no network or credentials.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import unicodedata
import zlib

_EX1 = str(Path(__file__).resolve().parents[1] / 'execution')
if _EX1 not in sys.path:
    sys.path.insert(0, _EX1)

from artifacts import Refused, digest, git_objects, require, validate_manifest  # noqa: E402
from execution import FakeEndpoint, destination_check  # noqa: E402

OPERATION = re.compile(r'[0-9a-f]{32}\Z')
OID = re.compile(r'[0-9a-f]{40}\Z')
IDENTITY = b'AAC Studio publisher <publisher@studio.invalid>'
# On every local call. Remote receive-pack does not inherit these switches;
# hooks installed in the remote repository run as the remote owner's code.
SAFE = ['-c', 'core.hooksPath=/dev/null', '-c', 'credential.helper=',
        '-c', 'core.fsmonitor=false', '-c', 'core.attributesFile=/dev/null',
        '-c', 'push.recurseSubmodules=no', '-c', 'protocol.allow=never',
        '-c', 'protocol.file.allow=always']


def pr_metadata(candidate_digest):
    """The exact PR text the publisher sends; approval binds its digest."""
    return dict(title='Studio candidate ' + candidate_digest[7:19],
                body='Built by AAC Studio from candidate ' + candidate_digest + '.')


def endpoint(publisher):
    """EX1 accepts only its own `FakeEndpoint` type, so hand it one that delegates.

    Outside this folder, EX1 should accept a trusted adapter instead (README).
    """
    adapter = FakeEndpoint()
    adapter.write, adapter.query = publisher.write, publisher.query
    return adapter


class Publisher:
    def __init__(self, workdir, remotes, pulls=None, *, git='/usr/bin/git', clock=time.time):
        self.workdir = Path(workdir)
        require(self.workdir.is_absolute() and self.workdir.is_dir() and
                not self.workdir.is_symlink(), 'protected publisher directory')
        require(Path(git).is_absolute(), 'protected git path')
        for url in remotes.values():
            # Local path or file:// only; never a task/candidate-chosen transport.
            require(isinstance(url, str) and (url.startswith('/') or url.startswith('file:///'))
                    and '::' not in url and all(ord(c) >= 32 for c in url),
                    'unsupported transport')
        self.remotes, self.pulls, self.git_path, self.clock = dict(remotes), pulls, git, clock

    def git(self, operation, *args):
        try:
            return self.git_bytes(operation, *args).decode('utf-8')
        except UnicodeDecodeError:
            raise Refused('remote answer is not UTF-8: hold') from None

    def git_bytes(self, operation, *args, input_bytes=None):
        repo = self.workdir / operation / 'repo.git'
        env = {'PATH': '/usr/bin:/bin', 'HOME': str(self.workdir / operation / 'home'),
               'GIT_DIR': str(repo), 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null',
               'GIT_TERMINAL_PROMPT': '0', 'LC_ALL': 'C'}
        result = subprocess.run([self.git_path, *SAFE, *args], cwd=str(repo), env=env,
                                stdin=subprocess.DEVNULL if input_bytes is None else None,
                                input=input_bytes, capture_output=True, timeout=60)
        require(result.returncode == 0, 'git %s failed: %s' % (
            args[0], result.stderr.decode(errors='replace')[-300:]))
        return result.stdout

    def heads(self, operation, url, *names):
        found = {}
        for line in self.git(operation, 'ls-remote', '--heads', url,
                             *['refs/heads/' + n for n in names]).splitlines():
            oid, ref = line.split('\t')
            require(OID.match(oid), 'remote answer')
            found[ref] = oid
        return found

    def write(self, operation, body, manifest):
        require(isinstance(operation, str) and OPERATION.match(operation), 'operation id')
        action = body.get('action')
        d = body['destination']
        require(action == 'pull_request' or (action == 'push' and d.get('kind') == 'push'),
                'publisher supports pull requests only or structured push')
        destination_check(action, d)
        require(action != 'pull_request' or self.pulls is not None, 'pull-request API required')
        require(digest(validate_manifest(manifest)) == body['candidate']['digest'],
                'manifest is not the approved candidate')
        require(action != 'pull_request' or
                d['metadata_digest'] == digest(pr_metadata(body['candidate']['digest'])),
                'approved PR metadata differs')
        require(d['repository'] in self.remotes, 'unknown repository')
        url = self.remotes[d['repository']]
        ref = d['ref'] if action == 'push' else 'refs/heads/' + d['head']
        leaf = ref.rsplit('/', 1)[-1]
        require(leaf != 'HEAD' and not leaf.startswith('-'), 'reserved branch name')
        root = self.workdir / operation
        try:
            root.mkdir()  # one attempt per operation, ever
        except FileExistsError:
            raise Refused('operation already attempted: reconcile') from None
        (root / 'home').mkdir()
        repo = root / 'repo.git'
        for part in ('objects', 'refs'):
            (repo / part).mkdir(parents=True)
        (repo / 'HEAD').write_text('ref: refs/heads/unused\n')
        (repo / 'config').write_text('[core]\n\trepositoryformatversion = 0\n\tbare = true\n')
        remote = self.heads(operation, url)  # All heads, including packed and Unicode names.
        folded = lambda name: unicodedata.normalize('NFC', name).casefold()
        def prefixes(name):
            parts = name.split('/')
            return ['/'.join(parts[:i]) for i in range(3, len(parts) + 1)]
        require(all(a == b or folded(a) != folded(b)
                    for existing in remote for a in prefixes(existing) for b in prefixes(ref))
                and all(not (folded(existing) == folded(ref) or
                             folded(existing).startswith(folded(ref) + '/') or
                             folded(ref).startswith(folded(existing) + '/')) for existing in remote),
                'remote already has this branch (case/normalisation alias): hold')
        if action == 'push':
            ref = d['ref']
            # HEAD chooses the base; approval binds that exact commit and absence.
            answer = self.git(operation, 'ls-remote', '--symref', url, 'HEAD', ref)
            refs, current = {}, None
            for line in answer.splitlines():
                value, name = line.split('\t')
                if name == 'HEAD' and value.startswith('ref: '):
                    current = value[5:]
                else:
                    refs[name] = value
            base = refs.get('HEAD')
            require(base is not None and OID.match(base), 'remote HEAD base missing')
            require(ref != current and ref not in refs,
                    'remote already has this branch or is current: hold')
            require(d['expected_remote_digest'] == digest(dict(ref=ref, head=None, base=base)),
                    'approved remote state changed: hold')
            base_ref = 'HEAD'
        else:
            ref = 'refs/heads/' + d['head']
            require(ref not in remote and not self.pulls.find(d['repository'], d['head']),
                    'remote already has this branch or PR: hold')
            base = remote.get('refs/heads/' + d['base'])
            require(base is not None, 'remote base branch missing')
            base_ref = 'refs/heads/' + d['base']
        self.git(operation, 'fetch', '--no-tags', url, base_ref + ':refs/studio/base')
        require(self.git(operation, 'rev-parse', 'refs/studio/base').strip() == base,
                'remote base moved: hold')
        mapping, objects = git_objects(manifest)
        require(mapping['git_tree_oid'] != self.git(
            operation, 'rev-parse', 'refs/studio/base^{tree}').strip(), 'candidate has no change from base')
        stamp = b'%d +0000' % int(self.clock())
        commit = b'tree %s\nparent %s\nauthor %s %s\ncommitter %s %s\n\n%s\n\nStudio-Operation: %s\n' % (
            mapping['git_tree_oid'].encode(), base.encode(), IDENTITY, stamp, IDENTITY, stamp,
            pr_metadata(body['candidate']['digest'])['title'].encode(), operation.encode())
        commit = b'commit %d\0' % len(commit) + commit
        for raw in [*objects.values(), commit]:
            oid = hashlib.sha1(raw).hexdigest()
            self.store_object(operation, repo, oid, raw)
        expected = hashlib.sha1(commit).hexdigest()
        # Durable expected remote state BEFORE the push, so query can reconcile a crash.
        saved = dict(body=body, commit=expected, base=base, tree=mapping['git_tree_oid'],
                     push_started_at=self.clock(), push_observed=False)
        self.save_intent(root, saved)
        # Lease on absence: never overwrite a branch that appeared after the compare.
        try:
            self.git(operation, 'push', '--porcelain', '--no-verify',
                     '--force-with-lease=%s:' % ref, url, '%s:%s' % (expected, ref))
        except Refused:
            saved['push_observed'] = True  # git returned a definite failure
            self.save_intent(root, saved)
            raise
        saved['push_observed'] = True
        self.save_intent(root, saved)
        if action == 'pull_request':
            self.pulls.open(repository=d['repository'], base=d['base'], head=d['head'],
                            marker=operation, **pr_metadata(body['candidate']['digest']))

    def save_intent(self, root, saved):
        intent = root / 'intent.json'
        with open(str(intent) + '.tmp', 'w') as stream:
            json.dump(saved, stream, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(str(intent) + '.tmp', str(intent))
        fd = os.open(str(root), os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)

    def absent(self, saved, settle_seconds):
        if saved.get('push_observed'):
            return 'not_landed'
        if (settle_seconds is not None and 'push_started_at' in saved and
                self.clock() - saved['push_started_at'] >= settle_seconds):
            return 'not_landed'
        return 'unavailable'  # lost push result: absence alone cannot prove failure

    def store_object(self, operation, repo, oid, raw):
        """Verify and reuse fetched loose/packed objects; never replace one."""
        target = repo / 'objects' / oid[:2] / oid[2:]
        if target.exists():
            try:
                existing = zlib.decompress(target.read_bytes())
            except (OSError, zlib.error) as exc:
                raise Refused('unreadable existing object') from exc
            require(existing == raw, 'existing object differs from candidate')
            return
        # Batch output preserves binary tree/blob content and distinguishes missing
        # from corrupt/unreadable packed objects (which must refuse, never replace).
        found = self.git_bytes(operation, 'cat-file', '--batch', input_bytes=(oid + '\n').encode())
        if found != (oid + ' missing\n').encode():
            header, content = raw.split(b'\0', 1)
            require(found == oid.encode() + b' ' + header + b'\n' + content + b'\n',
                    'existing packed object differs from candidate')
            return
        target.parent.mkdir(exist_ok=True)
        try:
            with target.open('xb') as stream:
                stream.write(zlib.compress(raw))
        except FileExistsError as exc:
            raise Refused('object appeared during construction: hold') from exc

    def query(self, operation, body, *, settle_seconds=None):
        """landed / not_landed, or a held answer: partial, divergent, duplicate, unavailable."""
        require(settle_seconds is None or
                (type(settle_seconds) in (int, float) and 0 <= settle_seconds < float('inf')),
                'settle time must be a finite nonnegative interval')
        intent = self.workdir / operation / 'intent.json'
        if not OPERATION.match(operation) or not intent.exists():
            return 'not_landed'  # the intent is written before any remote write
        saved = json.loads(intent.read_text())
        if saved['body'] != body:
            return 'divergent'
        d = body['destination']
        try:
            if body['action'] == 'push':
                return self.query_push(operation, d, saved, settle_seconds)
            head = self.heads(operation, self.remotes[d['repository']], d['head']).get(
                'refs/heads/' + d['head'])
            pulls = list(self.pulls.find(d['repository'], d['head']))
        except (Refused, OSError, KeyError, subprocess.SubprocessError):
            return 'unavailable'
        if len(pulls) > 1:
            return 'duplicate'
        if head is None and not pulls:
            return self.absent(saved, settle_seconds)
        if head == saved['commit'] and not pulls:
            return 'partial'  # branch pushed, PR not opened: hold, never re-push
        if head == saved['commit'] and pulls[0]['marker'] == operation and \
                pulls[0]['base'] == d['base']:
            return 'landed'
        return 'divergent'

    def query_push(self, operation, destination, saved, settle_seconds=None):
        url, ref = self.remotes[destination['repository']], destination['ref']
        head = self.heads(operation, url, ref[len('refs/heads/'):]).get(ref)
        if head is None:
            return self.absent(saved, settle_seconds)
        self.git(operation, 'fetch', '--no-tags', url, '+' + ref + ':refs/studio/observed')
        observed = self.git(operation, 'rev-parse', 'refs/studio/observed').strip()
        if observed != head:
            return 'divergent'
        lines = self.git(operation, 'cat-file', 'commit', observed).split('\n\n', 1)[0].splitlines()
        trees = [line[5:] for line in lines if line.startswith('tree ')]
        parents = [line[7:] for line in lines if line.startswith('parent ')]
        return 'landed' if trees == [saved['tree']] and parents == [saved['base']] else 'divergent'
