Finish the greeting function in greeting.js. Trim whitespace around a supplied
name. When the name is undefined, null, empty, or only whitespace, use "friend".
Keep the format "Hello, NAME!" and the existing named greeting behaviour.
Do not change the tests or add dependencies. The check is `node --test`.
