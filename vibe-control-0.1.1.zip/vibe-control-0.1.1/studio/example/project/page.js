import { greeting } from './greeting.js';
document.querySelector('#greeting').textContent = greeting('Developer');
