import test from 'node:test';
import assert from 'node:assert/strict';
import { greeting } from '../greeting.js';

test('greets a named visitor', () => {
  assert.equal(greeting('Ada'), 'Hello, Ada!');
});
test('trims spaces around a visitor name', () => {
  assert.equal(greeting('  Ada  '), 'Hello, Ada!');
});
test('greets an unnamed visitor', () => {
  for (const name of [undefined, null, '', '   ']) {
    assert.equal(greeting(name), 'Hello, friend!');
  }
});
