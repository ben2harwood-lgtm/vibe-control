"""Read-only local intake. Repository bytes never become commands or Git config."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import stat
import subprocess
import tempfile
import time

FILE_LIMIT = 1024 * 1024
TOTAL_LIMIT = 64 * FILE_LIMIT
ENTRY_LIMIT = 250000
METADATA_LIMIT = 1024 * FILE_LIMIT
INDEX_LIMIT = 64 * FILE_LIMIT
OBJECT_LIMIT = 512 * FILE_LIMIT
GIT_OUTPUT_LIMIT = 32 * FILE_LIMIT
ID = re.compile(r"[a-z][a-z0-9_-]{0,79}\Z")


class IntakeError(ValueError):
    pass


def read_file(parent, name, budget, limit=FILE_LIMIT):
    """Open relative to an already opened directory; never follow links."""
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise IntakeError(f'non-regular or oversize file: {name}')
        data = stream.read(limit + 1)
    budget[0] += len(data)
    if len(data) > limit or budget[0] > TOTAL_LIMIT:
        raise IntakeError('file or total byte limit exceeded')
    return data


def listed_paths(metadata, commit):
    expected = {}
    if commit:
        for row in git(metadata, 'ls-tree', '-r', '-z', commit).split(b'\0'):
            if row:
                fields, path = row.split(b'\t', 1)
                mode, kind, digest = fields.decode('ascii').split()
                if kind != 'blob' or mode not in ('100644', '100755', '120000'):
                    raise IntakeError('submodules need later support')
                expected[os.fsdecode(path)] = (digest, mode == '100755')
    paths = set(expected)
    if (metadata / 'index').exists():
        for row in git(metadata, 'ls-files', '--stage', '-z').split(b'\0'):
            if row:
                _, path = row.split(b'\t', 1)
                paths.add(os.fsdecode(path))
    if len(paths) > ENTRY_LIMIT:
        raise IntakeError('tracked entry limit exceeded')
    return paths, expected


def outside_link(parent, name, relative, root):
    # Lexical validation only: never open the link target, even for an internal link.
    target = os.readlink(name, dir_fd=parent)
    combined = (os.path.relpath(target, root) if os.path.isabs(target) else
                os.path.normpath(os.path.join(os.path.dirname(relative), target)))
    return combined == '..' or combined.startswith('../')


def scan(fd, paths, notes, root):
    files, skipped, budget = {}, set(), [0]
    directory_entries = {'': set(os.listdir(fd)) - {'.git'}}
    known_entries = {'': set()}
    for path in sorted(paths):
        parts = path.split('/')
        if any(part in ('', '.', '..', '.git') for part in parts):
            raise IntakeError('unsafe tracked path')
        for index, part in enumerate(parts):
            known_entries.setdefault('/'.join(parts[:index]), set()).add(part)
        parent = os.dup(fd)
        try:
            for index, part in enumerate(parts[:-1]):
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
                os.close(parent)
                parent = child
                directory = '/'.join(parts[:index + 1])
                if directory not in directory_entries:
                    directory_entries[directory] = set(os.listdir(parent))
            info = os.stat(parts[-1], dir_fd=parent, follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode):
                if outside_link(parent, parts[-1], path, root):
                    raise IntakeError(f'outside symlink refused: {path}')
                notes.append(f'Symlink not followed: {path}')
                skipped.add(path)
            elif stat.S_ISREG(info.st_mode) and info.st_size > FILE_LIMIT and path != 'package.json':
                notes.append(f'Large file not read: {path}')
                skipped.add(path)
            else:
                files[path] = (read_file(parent, parts[-1], budget), bool(info.st_mode & 0o111))
        except FileNotFoundError:
            pass  # A deleted tracked file is a working-tree change.
        finally:
            os.close(parent)
    # Preserve the root special-file safety preflight without traversing untracked
    # directories or reading untracked content (including ignored dependencies).
    for name in os.listdir(fd):
        if name == '.git' or name in paths:
            continue
        info = os.stat(name, dir_fd=fd, follow_symlinks=False)
        if stat.S_ISLNK(info.st_mode) and outside_link(fd, name, name, root):
            raise IntakeError(f'outside symlink refused: {name}')
        if not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode)):
            raise IntakeError(f'non-regular root entry: {name}')
    untracked = any(entries - known_entries.get(directory, set())
                    for directory, entries in directory_entries.items())
    if untracked:
        notes.append('Untracked entries may exist; ignore rules were not evaluated.')
    return files, skipped, untracked


def copy_file(parent, name, target, budget, limit):
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
    with os.fdopen(fd, 'rb') as source, target.open('xb') as output:
        info = os.fstat(source.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise IntakeError(f'Git metadata file type/size limit: {name}')
        size = 0
        while chunk := source.read(FILE_LIMIT):
            size += len(chunk)
            budget[0] += len(chunk)
            if size > limit or budget[0] > METADATA_LIMIT:
                raise IntakeError('Git metadata byte limit exceeded')
            output.write(chunk)


def snapshot_git(root_fd, destination):
    """Copy only Git data, omitting config, hooks, attributes and alternates."""
    fd = os.open('.git', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=root_fd)
    budget = [0]
    try:
        for name in ('HEAD', 'packed-refs', 'shallow', 'index'):
            try:
                copy_file(fd, name, destination / name, budget,
                          INDEX_LIMIT if name == 'index' else FILE_LIMIT)
            except FileNotFoundError:
                if name == 'HEAD':
                    raise IntakeError('missing Git HEAD')
        for name in ('objects', 'refs'):
            child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            try:
                # Object info may contain alternates; never copy it. Only object and ref data.
                copy_data(child, destination / name, budget, objects=name == 'objects')
            finally:
                os.close(child)
    finally:
        os.close(fd)


def copy_data(fd, target, budget, objects=False, depth=0, entries=None):
    entries = [0] if entries is None else entries
    if depth > 32:
        raise IntakeError('Git metadata nesting limit exceeded')
    target.mkdir(exist_ok=True)
    for name in sorted(os.listdir(fd)):
        if objects and depth == 0 and name == 'info':
            continue
        entries[0] += 1
        if entries[0] > ENTRY_LIMIT:
            raise IntakeError('Git metadata entry limit exceeded')
        info = os.stat(name, dir_fd=fd, follow_symlinks=False)
        if stat.S_ISDIR(info.st_mode):
            child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            try:
                copy_data(child, target / name, budget, objects, depth + 1, entries)
            finally:
                os.close(child)
        else:
            copy_file(fd, name, target / name, budget, OBJECT_LIMIT if objects else FILE_LIMIT)


def git(metadata, *args):
    executable = shutil.which('git', path=os.defpath)
    if not executable:
        raise IntakeError('Git unavailable on system path')
    env = {'PATH': os.defpath, 'LC_ALL': 'C', 'HOME': str(metadata.parent),
           'XDG_CONFIG_HOME': str(metadata.parent), 'GIT_CONFIG_NOSYSTEM': '1',
           'GIT_CONFIG_SYSTEM': os.devnull, 'GIT_CONFIG_GLOBAL': os.devnull,
           'GIT_ATTR_NOSYSTEM': '1', 'GIT_OPTIONAL_LOCKS': '0',
           'GIT_NO_REPLACE_OBJECTS': '1', 'GIT_NO_LAZY_FETCH': '1',
           'GIT_TERMINAL_PROMPT': '0'}
    command = [executable, '--no-pager', '--no-replace-objects',
               '--git-dir=' + str(metadata), '-c', 'core.hooksPath=' + os.devnull,
               '-c', 'core.attributesFile=' + os.devnull, *args]
    # Bound decompressed Git output too, including malicious tree objects.
    with subprocess.Popen(command, cwd=metadata.parent, env=env,
                          stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.DEVNULL) as process:
        chunks, size, deadline = [], 0, time.monotonic() + 10
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ)
                while True:
                    if time.monotonic() >= deadline:
                        raise IntakeError('Git timed out')
                    if not selector.select(0.1):
                        continue
                    chunk = os.read(process.stdout.fileno(), 65536)
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > GIT_OUTPUT_LIMIT:
                        raise IntakeError('Git output limit exceeded')
                    chunks.append(chunk)
            if process.wait(timeout=max(0.01, deadline - time.monotonic())):
                raise IntakeError('invalid or unsupported Git metadata')
            return b''.join(chunks)
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()


def baseline(metadata):
    head = (metadata / 'HEAD').read_text().strip()
    branch = None
    if head.startswith('ref: refs/heads/'):
        ref = head[5:]
        git(metadata, 'check-ref-format', ref)
        branch = ref[len('refs/heads/'):]
        packed = (metadata / 'packed-refs')
        exists = (metadata / ref).is_file() or (packed.exists() and any(
            line.endswith(' ' + ref) for line in packed.read_text().splitlines()))
        if not exists:
            return branch, None
    elif not re.fullmatch('[0-9a-f]{40}', head):
        raise IntakeError('unsupported HEAD (expected branch or detached SHA-1)')
    commit = git(metadata, 'rev-parse', '--verify', 'HEAD^{commit}').decode().strip()
    if not re.fullmatch('[0-9a-f]{40}', commit):
        raise IntakeError('unsupported commit identity')
    return branch, commit


def working_tree(metadata, commit, files, expected, skipped, untracked):
    actual = {path: (hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), mode)
              for path, (data, mode) in files.items()}
    expected = {path: value for path, value in expected.items() if path not in skipped}
    staged = bool(commit and (metadata / 'index').exists() and git(
        metadata, 'diff-index', '--cached', '--raw', '--no-renames',
        '--no-ext-diff', '--no-textconv', commit, '--'))
    if actual != expected or staged:
        return 'changed'
    return 'unknown' if skipped or untracked else 'clean'


def compatibility(files, source_paths=None):
    try:
        package = json.loads(files['package.json'][0])
        dependencies = {}
        for field in ('dependencies', 'devDependencies'):
            value = package.get(field, {})
            if not isinstance(value, dict):
                raise ValueError('dependency map must be an object')
            dependencies.update(value)
    except (KeyError, ValueError, TypeError, AttributeError, UnicodeError, RecursionError):
        return False, None, ['Missing or invalid root package.json dependency maps.']
    source = any(Path(p).suffix in {'.js', '.jsx', '.ts', '.tsx', '.mjs', '.cjs', '.vue', '.svelte', '.astro'} for p in (files if source_paths is None else source_paths))
    frameworks = [('next', 'next'), ('@sveltejs/kit', 'sveltekit'), ('nuxt', 'nuxt'),
                  ('@remix-run/react', 'remix'), ('@remix-run/dev', 'remix'),
                  ('react-scripts', 'cra'), ('@angular/core', 'angular'),
                  ('astro', 'astro'), ('vite', 'vite'), ('@vue/cli-service', 'vue'),
                  ('gatsby', 'gatsby')]
    for dependency, stack in frameworks:
        if source and dependency in dependencies:
            return True, stack, [f'Web framework/build dependency {dependency} and web source found.']
    if source and 'index.html' in files and not any(p.endswith('.py') for p in files):
        return True, 'web', ['HTML entry and JavaScript/TypeScript source found.']
    return False, None, ['Need JavaScript/TypeScript web source and a web framework/build dependency in package.json.']


def inspect(repository, project_id):
    if not ID.fullmatch(project_id):
        raise IntakeError('project id must match contract identity syntax')
    root = Path(os.path.abspath(repository))
    result = {'contract_version': '0.1.0', 'project': {'id': project_id},
              'source': {'kind': 'local', 'path': str(root)}, 'branch': None,
              'baseline_commit': None, 'working_tree': 'unknown',
              'compatible': False, 'status': 'could_not_finish', 'stack': None, 'reasons': [], 'notes': [],
              'inherited_checks': 'not_run',
              'D1': {'status': 'open', 'working_assumption': 'Developers who already use coding agents; existing JavaScript/TypeScript web repository.'}}
    try:
        # Reject symlinked path components, not just the final directory.
        fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
        try:
            for part in root.parts[1:]:
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                os.close(fd)
                fd = child
            with tempfile.TemporaryDirectory(prefix='aac-intake-') as temporary:
                metadata = Path(temporary) / 'metadata'
                metadata.mkdir()
                snapshot_git(fd, metadata)
                result['branch'], result['baseline_commit'] = baseline(metadata)
                paths, expected = listed_paths(metadata, result['baseline_commit'])
                files, skipped, untracked = scan(fd, paths, result['notes'], root)
                result['working_tree'] = working_tree(metadata, result['baseline_commit'], files, expected, skipped, untracked)
                if 'package.json' in skipped:
                    raise IntakeError('package.json was not read (symlink)')
                result['compatible'], result['stack'], result['reasons'] = compatibility(files, set(files) | skipped)
                result['status'] = 'compatible' if result['compatible'] else 'incompatible'
        finally:
            os.close(fd)
    except (OSError, ValueError, subprocess.SubprocessError, RecursionError) as error:
        result.update(compatible=False, stack=None, working_tree='unknown',
                      status='could_not_finish', reasons=[f"Couldn't finish safe inspection: {error}"])
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repository')
    parser.add_argument('--project-id', required=True)
    parser.add_argument('--output', help='Create a new JSON record; existing paths are refused.')
    args = parser.parse_args()
    try:
        result = inspect(args.repository, args.project_id)
    except IntakeError as error:
        parser.error(str(error))
    record = json.dumps(result, indent=2) + '\n'
    if args.output:
        try:
            with open(args.output, 'x', encoding='utf-8') as stream:
                stream.write(record)
        except OSError as error:
            parser.error(str(error))
    else:
        print(record, end='')
    return 3 if result['status'] == 'could_not_finish' else (0 if result['compatible'] else 1)


if __name__ == '__main__':
    raise SystemExit(main())
