"""Protected record consistency, not authentication or a runtime grant engine."""
import hashlib
import json
import re
import unicodedata
from pathlib import PurePosixPath


def digest(value):
    """Canonical UTF-8 JSON: sorted keys, no spaces, no ASCII escaping."""
    return 'sha256:' + hashlib.sha256(json.dumps(
        value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()


def validate_authority(d, require, identity):
    a = d['authority']
    scope = dict(project_id=d['project']['id'], task_id=d['task']['id'],
                 run_id=d['run']['id'], attempt_id=d['attempt']['id'])
    principals = a['principals']
    require(len({p['actor']['id'] for p in principals}) == len(principals), 'duplicate principal')

    def principal(actor, role=None):
        matches = [p for p in principals if p['actor'] == actor]
        require(len(matches) == 1, 'unauthenticated principal')
        p = matches[0]
        require(p['installation_id'] == a['installation_id'] and
                scope['project_id'] in p['project_ids'], 'principal project/installation mismatch')
        require(role is None or p['role'] == role, 'customer-only approver or issuer role mismatch')
        require((p['role'] != 'customer' or actor['kind'] == 'local_user') and
                (p['role'] != 'task_agent' or actor['kind'] == 'task_agent') and
                (p['role'] != 'control_service' or actor['kind'] == 'protected_service'),
                'principal kind/role mismatch')
        return p

    def actors(value):
        if isinstance(value, dict):
            if 'actor' in value:
                principal(value['actor'])
            for child in value.values():
                actors(child)
        elif isinstance(value, list):
            for child in value:
                actors(child)
    actors(d)
    plan, lease = a['plan'], a['lease']
    require(all(r['revoked_sequence'] is None or r['revoked_sequence'] <= a['sequence']
                for r in [plan, lease, *d['approvals']]), 'revocation ahead of journal')
    for record in [plan, lease, *d['run_records'], *d['admissions']]:
        identity(record)
    principal(plan['actor'], 'customer')
    principal(lease['issuer'], 'control_service')
    principal(lease['principal'], 'task_agent')
    require(plan['scope'] == lease['scope'] == scope, 'plan/lease scope mismatch')
    require(lease['plan_id'] == plan['id'] and lease['plan_revision'] == plan['revision'] and
            lease['policy_digest'] == plan['policy_digest'], 'lease plan/policy mismatch')
    require(plan['approved_sequence'] < lease['issued_sequence'] < lease['expires_sequence'] and
            (plan['revoked_sequence'] is None or lease['issued_sequence'] < plan['revoked_sequence']) and
            lease['issued_at'] < lease['expires_at'] and
            lease['issued_sequence'] <= a['sequence'],
            'lease requires approved plan and expiry')
    require(lease['isolation'] == d['task']['isolation'] and lease['write_roots'] and
            lease['tools'] and lease['reservation_units'] <= lease['ceilings']['usage_units'] and
            lease['ceilings']['usage_units'] == d['limits']['max_units'], 'lease isolation/limits mismatch')
    for root in lease['write_roots']:
        require(root.startswith('/') and '..' not in PurePosixPath(root).parts and
                str(PurePosixPath(root)) == root, 'noncanonical write root')
    candidates = {c['ref']['id']: c for c in d['candidates']}
    for c in candidates.values():
        m = c['manifest']
        require(m['base_digest'] == c['base_digest'] and digest(m) == c['ref']['digest'],
                'canonical manifest digest mismatch')
        paths = [e['path'] for e in m['entries']]
        require(paths == sorted(set(paths)), 'manifest paths not unique/sorted')
        for path in paths:
            require(path == unicodedata.normalize('NFC', path) and not path.startswith('/') and
                    '\\' not in path and all(ord(ch) >= 32 for ch in path) and
                    all(part not in {'', '.', '..', '.git'} for part in path.split('/')),
                    'unsafe manifest path')
        # Separate protected mappings; EX1 must construct and verify actual artifacts.
    records = {r['id']: r for r in d['run_records']}
    require(len(records) == len(d['run_records']) == len(candidates), 'one run record per candidate required')
    require({r['candidate']['id'] for r in records.values()} == set(candidates), 'run record candidate coverage')
    for r in records.values():
        c = candidates.get(r['candidate']['id'])
        require(c is not None and r['candidate'] == c['ref'] and r['scope'] == scope and
                r['base_digest'] == c['base_digest'] and
                c['base_digest'] in {lease['base_digest'], *(x['ref']['digest'] for x in candidates.values())} and
                r['checkpoint_digest'] == lease['checkpoint_digest'] and r['lease_id'] == lease['id'] and
                r['plan_id'] == plan['id'] and r['plan_revision'] == plan['revision'] and
                r['policy_digest'] == plan['policy_digest'] and
                r['git_tree_digest'] == c['git_tree_digest'] and
                r['artifact_digest'] == c['artifact_digest'], 'EX1 run record binding mismatch')
        required = r['acceptance_policy']['required']
        require(required and {e['collection'] for e in required} == {'checks', 'reviews'},
                'acceptance policy requires checks and review')
    approvals = {p['id']: p for p in d['approvals']}
    confirmations = set()
    for p in approvals.values():
        who = principal(p['actor'], 'customer')
        conf = p['confirmation']
        require(conf['reference'] not in confirmations, 'confirmation reference replayed')
        confirmations.add(conf['reference'])
        require(conf['session_id'] == who['session_id'] and conf['displayed'] == {
            k: p[k] for k in ('scope', 'candidate', 'action', 'destination')} and
            conf['displayed_sequence'] < conf['consumed_sequence'] == p['approved_sequence'],
            'exact active approval confirmation tuple/session mismatch')
        destination = p['destination']
        for key in ('ref', 'base', 'head'):
            if key in destination:
                value = destination[key]
                require(re.fullmatch(r'[A-Za-z0-9_/-]+', value) is not None and
                        not value.startswith(('/', '-')) and not value.endswith('/') and
                        '//' not in value and
                        (key != 'ref' or value.startswith('refs/heads/')),
                        'destination ref is not normalised/supported')
        require(p['destination']['kind'] == p['action'], 'exact active approval destination mismatch')
        require((p['state'] == 'active') == (p['revoked_sequence'] is None), 'approval revocation mismatch')
        require(p['revoked_sequence'] is None or p['revoked_sequence'] > p['approved_sequence'],
                'approval revocation ordering')
    admissions = {i['id']: i for i in d['admissions']}
    require(len(admissions) == len(d['admissions']), 'duplicate admission')
    used = set()
    command_ids = {c['id']: c for c in d['commands']}
    for i in admissions.values():
        p = approvals.get(i['approval_id']); r = records.get(i['run_record_id'])
        cmd = command_ids.get(i['command_id'])
        principal(i['issuer'], 'control_service')
        require(p is not None and r is not None and cmd is not None,
                'outward action lacks exact active approval/admission')
        require(i['approval_id'] not in used, 'approval consumed for second operation')
        used.add(i['approval_id'])
        require(cmd['admission_id'] == i['id'] and
                all(cmd['body'][k] == p[k] for k in ('candidate','action','destination')) and
                r['candidate'] == p['candidate'], 'outward action lacks exact active approval binding')
        seq = i['sequence']
        require(p['approved_sequence'] < seq and all(
            revoked is None or seq < revoked for revoked in
            (p['revoked_sequence'], plan['revoked_sequence'], lease['revoked_sequence'])) and
            lease['issued_sequence'] <= seq < lease['expires_sequence'] and seq <= a['sequence'] and
            lease['issued_at'] <= i['admitted_at'] < lease['expires_at'] and
            i['admitted_at'] <= a['observed_time'],
            'admission after revocation/expiry or before approval')
        require(i['lease_id'] == lease['id'] and all(i[k] == lease[k] for k in
                ('installation_id','key_generation','fence')) and
                all(lease[k] == a[k] for k in ('installation_id','key_generation','fence')),
                'recovery fence/key mismatch')
        require(i['expected_remote_digest'] == p['destination']['expected_remote_digest'],
                'expected remote state mismatch')
        for e in r['acceptance_policy']['required']:
            assessment = next((x for x in d[e['collection']] if x['id'] == e['assessment_id']), None)
            require(assessment is not None and assessment['request']['binding'] == e['binding'] and
                    e['binding']['candidate'] == r['candidate'] and assessment['result'] is not None and
                    assessment['result']['outcome'] == 'passed' and
                    assessment['request']['issued_sequence'] <
                    assessment['result']['recorded_sequence'] < seq,
                    'admission lacks current required evidence')
            reviewer = principal(assessment['result']['actor'])
            require(reviewer['family'] == e['reviewer_family'] and
                    (e['collection'] != 'reviews' or not r['acceptance_policy']['independent_review'] or
                     reviewer['family'] != r['builder_family']), 'reviewer family mismatch')
        if p['action'] == 'deploy':
            require(p['destination']['artifact_digest'] == candidates[p['candidate']['id']]['artifact_digest'],
                    'deployment artifact mismatch')
        rec = i['reconciliation']
        require(cmd['outcome'] not in {'failed', 'cancelled'} or rec is not None,
                'admitted failure/cancellation requires reconciliation')
        if rec is not None:
            require(seq < rec['sequence'] <= a['sequence'] and
                    ((rec['outcome'] == 'landed' and cmd['outcome'] == 'succeeded') or
                     (rec['outcome'] == 'not_landed' and cmd['outcome'] in {'failed','cancelled'}) or
                     (rec['outcome'] == 'held' and cmd['outcome'] == 'uncertain')),
                    'reconciliation outcome/order mismatch')
    for cmd in d['commands']:
        outward = cmd['body']['action'] in {'push','pull_request','deploy'}
        if outward and cmd['outcome'] in {'received','succeeded','uncertain','failed','cancelled'}:
            require(cmd['admission_id'] in admissions, 'outward action lacks exact active approval/admission')
        if cmd['admission_id'] is not None:
            i = admissions.get(cmd['admission_id'])
            original = command_ids.get(i['command_id']) if i else None
            require(original is not None and (cmd['actor'],cmd['idempotency_key'],cmd['body']) ==
                    (original['actor'],original['idempotency_key'],original['body']),
                    'admission replay identity mismatch')
