(function () {
'use strict';
const selector = document.getElementById('fixture');
const root = document.getElementById('workspace');
const fixtures = globalThis.StudioFixtures || {};
let binding, source;
const supplied = globalThis.StudioRun;
if (supplied) {
    document.title = 'Vibe Control run';
    for (const picker of document.querySelectorAll('.fixture-picker')) picker.hidden = true;
    source = StudioState.live.fakeSource(supplied.snapshot);
    binding = StudioState.live.session(source, view => {
        const model = StudioState.workspace(view.snapshot, view.snapshot ? 'ready' : 'loading');
        model.runPage = supplied;
        root.innerHTML = StudioRender.render(model);
    });
    binding.connect();
    return;
}
for (const key of Object.keys(fixtures)) {
    const option = document.createElement('option');
    option.value = key;
    option.textContent = key.replaceAll('_', ' ');
    selector.append(option);
}
function draw(view) {
    const model = StudioState.workspace(view.snapshot, view.snapshot ? 'ready' : 'loading');
    model.live = { ...view, fixture: selector.value };
    if (view.snapshot && !view.status.startsWith('Connected')) {
        model.status = `Uncertain · Last recorded ${view.snapshot.run.state}`;
    }
    root.innerHTML = StudioRender.render(model);
}
function update(stepwise = false) {
    if (binding) binding.disconnect();
    binding = null;
    const key = selector.value;
    const snapshot = fixtures[key];
    const mode = ['loading', 'empty', 'failure'].includes(key) ? key : snapshot ? 'ready' : 'failure';
    if (mode !== 'ready') {
        root.innerHTML = StudioRender.render(StudioState.workspace(null, mode));
        return;
    }
    source = StudioState.live.fakeSource(snapshot);
    binding = StudioState.live.session(source, draw);
    if (stepwise) binding.start();
    else binding.connect();
}
selector.addEventListener('change', () => update());
// Static controls live outside the rendered candidate/fixture surface.
for (const [id, action] of Object.entries({
    disconnect: () => binding?.disconnect(),
    reconnect: () => binding?.connect(),
    replay: () => update(true),
    next: () => { if (binding?.view().connected && !source.next()) binding.connect(); },
})) {
    const button = document.getElementById(id);
    if (button?.addEventListener) button.addEventListener('click', action);
}
selector.value = fixtures.successful_run ? 'successful_run' : 'failure';
update();
})();
