(function () {
'use strict';
const sections = ['Plan', 'Agents', 'Preview', 'Changes', 'Checks', 'Spend'];
const sameCandidate = (a, b) => Boolean(a && b && a.id === b.id && a.digest === b.digest);
const errorText = error => error ? `${error.code}: ${error.message} · Retry: ${error.retry}` : '';
const candidateText = ref => ref ? `${ref.id} · ${ref.digest}` : 'No candidate';

function evidence(record, current) {
    if (!record.result) return { ...record, status: 'Not run', stale: false };
    const request = record.request.binding;
    const result = record.result.binding;
    const stale = !sameCandidate(request.candidate, current) ||
        !sameCandidate(result.candidate, current) ||
        request.definition_digest !== result.definition_digest ||
        request.environment_digest !== result.environment_digest;
    return { ...record, stale, status: stale ? `Stale · historical ${record.result.outcome}` : record.result.outcome };
}

function workspace(snapshot, mode = 'ready') {
    if (mode !== 'ready' || !snapshot) {
        const status = { loading: 'Loading fixture', empty: 'No project selected', failure: 'Fixture unavailable' }[mode] || 'No project selected';
        return { mode, status, sections };
    }
    const current = snapshot.run.current_candidate;
    const usage = [...new Map(snapshot.usage.map(item => [item.id, item])).values()];
    return {
        mode, sections, snapshot, current, status: snapshot.run.state,
        previews: snapshot.previews.map(p => ({ ...p, stale: p.state === 'stale' || !sameCandidate(p.candidate, current) })),
        checks: snapshot.checks.map(c => evidence(c, current)),
        reviews: snapshot.reviews.map(r => evidence(r, current)),
        approvals: snapshot.approvals.map(a => ({ ...a, stale: a.state !== 'active' || !sameCandidate(a.candidate, current) })),
        observed: usage.reduce((sum, item) => sum + item.observed_units, 0),
        complete: usage.every(item => item.complete),
        exhausted: snapshot.limits.exhausted || usage.reduce((sum, item) => sum + item.observed_units, 0) >= snapshot.limits.max_units,
    };
}
// Display-only projection of contract/validate.py TRANSITIONS; never grants authority.
const transitions = {
    queued: ['running', 'held', 'cancelled', 'failed'],
    running: ['awaiting_input', 'checking', 'held', 'failed', 'cancelled', 'completed'],
    awaiting_input: ['running', 'held', 'cancelled', 'failed'],
    checking: ['running', 'awaiting_input', 'held', 'failed', 'cancelled', 'completed'],
    held: ['running', 'checking', 'awaiting_input', 'cancelled', 'failed'],
    failed: [], cancelled: [], completed: [],
};
const clone = value => JSON.parse(JSON.stringify(value));
const scopeOf = d => ({ project_id: d.project.id, task_id: d.task.id, run_id: d.run.id, attempt_id: d.attempt.id });
const sameScope = (a, b) => a && b && Object.keys(a).length === 4 &&
    Object.keys(b).length === 4 && Object.keys(a).every(key => a[key] === b[key]);
const equalEvent = (a, b) => a.id === b.id && a.sequence === b.sequence && a.state === b.state && sameScope(a.scope, b.scope);
const require = (ok, message) => { if (!ok) throw Error(message); };
function validEvent(event, scope) {
    require(event && Number.isSafeInteger(event.sequence) && event.sequence > 0 &&
        typeof event.id === 'string' && Object.hasOwn(transitions, event.state) && sameScope(event.scope, scope), 'Invalid event or scope');
}
function follows(previous, event) {
    require(event.sequence === previous.sequence + 1, 'Sequence gap or out-of-order event');
    require(event.state === previous.state || transitions[previous.state].includes(event.state), 'Invalid state transition');
}
function validateSnapshot(d, scope) {
    require(d && sameScope(scopeOf(d), scope) && d.contract_version === '0.2.0', 'Snapshot scope/version mismatch');
    require(Array.isArray(d.events) && d.events.length > 0, 'Missing journal');
    const ids = new Set();
    d.events.forEach((event, i) => {
        validEvent(event, scope);
        require(!ids.has(event.id), 'Duplicate event identity');
        ids.add(event.id);
        if (i) follows(d.events[i - 1], event);
    });
    require(d.events.at(-1).state === d.run.state, 'Snapshot/event state mismatch');
    const unresolved = d.commands.some(c => ['received', 'uncertain'].includes(c.outcome));
    require(d.run.state !== 'completed' || !unresolved, 'Completion has unresolved commands');
    require(!d.commands.some(c => c.outcome === 'uncertain') || d.run.state === 'held', 'Uncertain action must hold');
    require(!['pending', 'held'].includes(d.cancellation.resolution) || d.run.state === 'held', 'Stop must hold');
    require(d.run.state !== 'cancelled' || (d.cancellation.requested &&
        d.cancellation.resolution === 'reconciled' && !unresolved), 'Stop is not reconciled');
}

function session(source, changed = () => {}) {
    const scope = clone(source.scope);
    let cursor = 0, events = [], snapshot = null, connected = false, unsubscribe;
    let status = 'Uncertain · Not connected';
    const view = () => clone({ cursor, events, snapshot, connected, status });
    const notify = () => changed(view());
    function hold(message) {
        status = `Uncertain · ${message}`;
        notify();
        return false;
    }
    function acceptEvent(event) {
        if (!connected) return false;
        try {
            validEvent(event, scope);
            if (event.sequence <= cursor) {
                const known = events.find(e => e.sequence === event.sequence);
                require(known && equalEvent(known, event), 'Conflicting or unretained duplicate');
                return true;
            }
            require(!events.some(e => e.id === event.id), 'Reused event identity');
            if (events.length) follows(events.at(-1), event);
            else require(event.sequence === 1, 'Expired cursor requires snapshot');
            cursor = event.sequence;
            events.push(clone(event));
            // Notifications cannot establish completion or refresh candidate evidence.
            snapshot = null;
            status = 'Uncertain · Event received; matching snapshot required';
            notify();
            return true;
        } catch (error) { return hold(error.message); }
    }
    function start() {
        connected = true;
        if (!unsubscribe) unsubscribe = source.subscribe(acceptEvent);
        status = 'Uncertain · Waiting for matching snapshot';
        notify();
    }
    function connect() {
        start();
        try {
            const packet = source.read(cursor);
            require(packet.after_sequence === cursor, 'Reconnect cursor mismatch');
            const d = packet.snapshot;
            validateSnapshot(d, scope);
            const first = d.events[0].sequence, last = d.events.at(-1).sequence;
            require(cursor <= last, 'Reconnect cursor ahead of journal');
            require(packet.next_sequence === last + 1, 'Incorrect high-water mark');
            const expired = cursor < first - 1;
            require(packet.mode === (expired ? 'snapshot_required' : 'replay'), 'Incorrect reconnect mode');
            const expected = expired ? [] : d.events.filter(e => e.sequence > cursor);
            require(Array.isArray(packet.events) && packet.events.length === expected.length &&
                packet.events.every((e, i) => equalEvent(e, expected[i])), 'Incomplete or out-of-order replay');
            for (const known of events) {
                require(!d.events.some(e => e.id === known.id && e.sequence !== known.sequence), 'Reused event identity');
                const retained = d.events.find(e => e.sequence === known.sequence);
                require(!retained || equalEvent(known, retained), 'Journal changed at recorded sequence');
            }
            const previous = events.at(-1);
            if (previous && last > cursor) {
                if (expected.length) follows(previous, expected[0]);
                else require(transitions[previous.state].length > 0 || d.events.every(e => e.state === previous.state), 'Terminal attempt resumed');
            }
            // Commit atomically only after validating the entire replay and snapshot.
            events = clone(d.events);
            cursor = last;
            snapshot = clone(d);
            status = expired ? 'Connected · Snapshot resynchronised' : 'Connected · Replay up to date';
            notify();
            return true;
        } catch (error) { return hold(error.message); }
    }
    function disconnect() {
        connected = false;
        if (unsubscribe) unsubscribe();
        unsubscribe = null;
        status = 'Uncertain · Disconnected; last snapshot may be stale';
        notify();
    }
    return { start, connect, disconnect, view };
}

// All data is in memory. No timers, transport, provider, execution or control API.
function fakeSource(snapshot) {
    const journal = clone(snapshot);
    const scope = scopeOf(journal);
    validateSnapshot(journal, scope);
    const listeners = new Set();
    let next = 0;
    return {
        scope,
        subscribe(listener) { listeners.add(listener); return () => listeners.delete(listener); },
        read(after) {
            const last = journal.events.at(-1).sequence;
            if (!Number.isSafeInteger(after) || after < 0 || after > last) throw Error('Reconnect cursor ahead of journal or invalid');
            const expired = after < journal.events[0].sequence - 1;
            return clone({ after_sequence: after, next_sequence: last + 1,
                mode: expired ? 'snapshot_required' : 'replay',
                events: expired ? [] : journal.events.filter(e => e.sequence > after), snapshot: journal });
        },
        next() {
            if (next >= journal.events.length) return false;
            const event = journal.events[next++];
            for (const listener of listeners) listener(clone(event));
            return true;
        },
    };
}

const api = { sections, workspace, sameCandidate, errorText, candidateText,
    live: { session, fakeSource, scopeOf, validateSnapshot } };
if (typeof module !== 'undefined') module.exports = api;
else globalThis.StudioState = api;
})();
