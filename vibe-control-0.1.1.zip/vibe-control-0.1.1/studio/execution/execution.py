"""EX1: one-task, fake-only control service. No providers, network or shell runner.

Sessions and adapters below are trusted test ports, NOT an authentication server
or process sandbox. Candidate data never supplies policy, actors or executable
callbacks. SQLite is the sole durable authority for record views and admissions.
"""
from contextlib import closing, contextmanager
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import secrets
import sqlite3
import sys
import time

from artifacts import Refused, capture, digest, git_objects, require, restore, validate_manifest


def claude_code_agent():
    """RV-A's real builder type, the only trusted agent besides FakeAgent (lazy, no cycle)."""
    folder = str(Path(__file__).resolve().parent.parent / 'providers')
    if folder not in sys.path:
        sys.path.insert(0, folder)
    from claude_code import ClaudeCodeAgent
    return ClaudeCodeAgent


def uid():
    return secrets.token_hex(16)


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def policy_check(policy):
    require(set(policy) in ({'version', 'checks', 'review'},
                            {'version', 'checks', 'review', 'independent_review'}) and
            type(policy.get('independent_review', True)) is bool and
            isinstance(policy['version'], str) and policy['version'] and
            isinstance(policy['checks'], dict) and policy['checks'] and
            isinstance(policy['review'], dict), 'required checks and review policy')
    for rule in [*policy['checks'].values(), policy['review']]:
        require(set(rule) == {'definition_digest', 'environment_digest'}, 'evidence rule')
        for value in rule.values():
            require(isinstance(value, str) and len(value) == 71 and
                    value.startswith('sha256:') and
                    all(c in '0123456789abcdef' for c in value[7:]), 'evidence digest')


def destination_check(action, destination):
    """Only structured synthetic destinations; never transport URLs or commands."""
    fields = {
        'push': {'kind', 'repository', 'ref', 'expected_remote_digest'},
        'pull_request': {'kind', 'repository', 'base', 'head', 'metadata_digest'},
        'deploy': {'kind', 'project', 'environment', 'artifact_digest', 'configuration_digest'},
    }
    require(action in fields and isinstance(destination, dict) and
            set(destination) == fields[action] and destination['kind'] == action,
            'unsupported action/destination')
    for key, value in destination.items():
        require(isinstance(value, str) and value, 'destination field')
        if key.endswith('_digest'):
            require(len(value) == 71 and value.startswith('sha256:') and
                    all(c in '0123456789abcdef' for c in value[7:]), 'destination digest')
        else:
            require(all(c in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_/-'
                        for c in value) and not value.startswith(('/', '-')) and
                    not value.endswith('/') and '//' not in value and
                    '..' not in value, 'unsafe destination')
    require(action != 'push' or destination['ref'].startswith('refs/heads/'), 'push ref')


class Journal:
    """Append-only checked snapshots, serialized with BEGIN IMMEDIATE and FULL sync.

    Snapshots are historical journal entries, not separately editable run views.
    Hash chaining detects corrupt/gapped history, not privileged whole-file rollback.
    Custody of this file and authenticated sessions is an RT deployment obligation.
    """
    def __init__(self, path):
        self.path = Path(path).absolute()
        require(not self.path.is_symlink(), 'linked journal')
        existed = self.path.exists()
        with closing(self.connect()) as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('CREATE TABLE IF NOT EXISTS journal ('
                       'seq INTEGER PRIMARY KEY, previous TEXT NOT NULL, '
                       'digest TEXT NOT NULL, payload TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS blobs ('
                       'digest TEXT PRIMARY KEY, content BLOB NOT NULL)')
            if not db.execute('SELECT 1 FROM journal').fetchone():
                require(not existed, 'empty existing journal: hold')
                state = dict(generation=1, runs={}, denials=[])
                self.append(db, 1, '', state, 'installation')
            self.load(db)
            db.commit()

    def connect(self):
        db = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        db.execute('PRAGMA synchronous=FULL')
        return db

    @staticmethod
    def append(db, seq, previous, state, event):
        # Match the old inline JSON round trip before recording reference paths:
        # JSON coerces numeric/bool/null keys and turns tuples into lists.
        try:
            state = json.loads(encoded(state).encode('utf-8'))
        except (TypeError, ValueError, UnicodeError, RecursionError) as exc:
            raise Refused('journal state is not JSON serializable') from exc
        references, blobs = [], {}

        def freeze(value, path):
            if isinstance(value, str) and (path[-1:] == ['bytes_hex'] or len(value) > 4096):
                if value not in blobs:
                    content = value.encode('utf-8')
                    checksum = 'sha256:' + hashlib.sha256(content).hexdigest()
                    blobs[value] = checksum
                    db.execute('INSERT OR IGNORE INTO blobs VALUES (?, ?)', (checksum, content))
                references.append([path, blobs[value]])
                return None
            if isinstance(value, dict):
                return {key: freeze(item, path + [key]) for key, item in value.items()}
            if isinstance(value, list):
                return [freeze(item, path + [i]) for i, item in enumerate(value)]
            return value

        payload = encoded(dict(format=2, event=event, state=freeze(state, []),
                               strings=references))
        checksum = digest(dict(seq=seq, previous=previous, payload=payload))
        db.execute('INSERT INTO journal VALUES (?, ?, ?, ?)', (seq, previous, checksum, payload))

    @staticmethod
    def checked_rows(db):
        """Check history and the exact blob inventory once, without expanding history."""
        previous, sequence, latest, referenced = '', 0, None, set()
        for seq, prior, checksum, payload in db.execute('SELECT * FROM journal ORDER BY seq'):
            require(seq == sequence + 1 and prior == previous and checksum == digest(
                dict(seq=seq, previous=prior, payload=payload)), 'corrupt journal: hold')
            row = json.loads(payload)
            if 'format' in row:
                require(row['format'] == 2, 'corrupt journal: hold')
                referenced.update(checksum for _, checksum in row['strings'])
            latest = row
            sequence, previous = seq, checksum
        require(latest is not None, 'missing journal: hold')
        # Check even historical-only and extra blobs. Resolve only requested rows below.
        found = set()
        try:
            inventory = db.execute('SELECT digest, content FROM blobs')
        except sqlite3.OperationalError as exc:
            if str(exc) == 'no such table: blobs':
                raise Refused('journal blob missing or changed') from exc
            raise
        for checksum, content in inventory:
            require(isinstance(content, bytes) and checksum ==
                    'sha256:' + hashlib.sha256(content).hexdigest(),
                    'journal blob missing or changed')
            found.add(checksum)
        require(found == referenced, 'journal blob missing or changed')
        return sequence, previous, latest

    @staticmethod
    def expand(db, row):
        state = row['state']
        values = {}
        for path, checksum in row.get('strings', []):
            if checksum not in values:
                content = db.execute('SELECT content FROM blobs WHERE digest = ?',
                                     (checksum,)).fetchone()
                require(content is not None and isinstance(content[0], bytes) and checksum ==
                        'sha256:' + hashlib.sha256(content[0]).hexdigest(),
                        'journal blob missing or changed')
                values[checksum] = content[0].decode('utf-8')
            target = state
            for key in path[:-1]:
                target = target[key]
            require(target[path[-1]] is None, 'corrupt journal: hold')
            target[path[-1]] = values[checksum]
        return dict(event=row['event'], state=state)

    @staticmethod
    def load(db):
        sequence, previous, latest = Journal.checked_rows(db)
        return sequence, previous, Journal.expand(db, latest)['state']

    @contextmanager
    def change(self, event):
        db = self.connect()
        failure = None
        try:
            db.execute('BEGIN IMMEDIATE')
            seq, previous, state = self.load(db)
            original = deepcopy(state)
            try:
                yield state
            except Refused as exc:
                state = original
                state['denials'].append(dict(operation=event, error=str(exc)))
                failure = exc
            self.append(db, seq + 1, previous, state, 'denied:' + event if failure else event)
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()
        if failure:
            raise failure

    def read(self):
        with closing(self.connect()) as db:
            db.execute('BEGIN')
            return self.load(db)[2]

    def replay(self, after):
        with closing(self.connect()) as db:
            db.execute('BEGIN')
            high, _, _ = self.checked_rows(db)
            require(type(after) is int and 0 <= after <= high, 'invalid replay cursor')
            return [dict(sequence=seq, **self.expand(db, json.loads(payload)))
                    for seq, payload in db.execute(
                        'SELECT seq, payload FROM journal WHERE seq > ? ORDER BY seq', (after,))]


class FakeAgent:
    """Fixed data edits, no subprocess, account, credential or model access."""
    family = 'fake-builder'
    tool_digest = digest('EX1 fixed data agent v1')

    def __init__(self, edits):
        self.edits = deepcopy(edits)

    def run(self, workspace):
        # Manifest validation happens before any file write.
        manifest = dict(base_digest=digest('fake edits'), entries=sorted(
            self.edits, key=lambda e: e['path']))
        validate_manifest(manifest)
        for entry in manifest['entries']:
            path = Path(workspace) / entry['path']
            # Existing workspace was checked immediately before launch; still
            # reject links/aliases instead of following candidate paths.
            for parent in [path, *path.parents]:
                if parent == Path(workspace).parent:
                    break
                require(not parent.is_symlink(), 'linked edit target')
            require(not path.exists() or path.stat().st_nlink == 1, 'hardlinked edit target')
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(bytes.fromhex(entry['bytes_hex']))
            path.chmod(0o755 if entry['mode'] == '100755' else 0o644)


class Service:
    def __init__(self, journal, sessions, clock=time.time):
        self.journal = Journal(journal)
        # Supplied only by trusted harness; tokens are never candidate actor JSON.
        self.sessions = deepcopy(sessions)
        for token, principal in self.sessions.items():
            principal.setdefault('session_id', digest(token))
        self.clock = clock

    def principal(self, token, role, project):
        p = self.sessions.get(token)
        require(p is not None and p['role'] == role and project in p['projects'],
                'authenticated role/project required: ' + role)
        return p

    @staticmethod
    def attempt(run):
        return run['attempts'][-1]

    @staticmethod
    def invalidate(run):
        for record in run['records'].values():
            for approval in record['approvals']:
                if approval['state'] == 'active':
                    approval['state'] = 'invalidated'
        run['confirmations'] = {}

    def live(self, state, run):
        require(run['plan_approval'] == digest(run['plan']) and not run['stopped'],
                'exact approved plan required')
        a = self.attempt(run)
        require(a['generation'] == state['generation'], 'stale generation')

    def create(self, token, *, project, task, brief, plan_revision, policy, workspace, base_digest,
               tool_digest=None, time_limit_seconds=None):
        """Default plan is the fake agent's; a real-tool plan binds its digest and time limit."""
        policy_check(policy)
        plan = dict(revision=plan_revision, policy=deepcopy(policy), brief_digest=digest(brief),
                    base_digest=base_digest, tool_digest=FakeAgent.tool_digest)
        if tool_digest is not None or time_limit_seconds is not None:
            require(isinstance(tool_digest, str) and tool_digest != FakeAgent.tool_digest and
                    type(time_limit_seconds) is int and time_limit_seconds > 0,
                    'real tool plan needs its tool digest and a time limit')
            plan.update(tool_digest=tool_digest, time_limit_seconds=time_limit_seconds)
        workspace = Path(workspace).absolute()
        require(workspace.resolve() == workspace and not self.journal.path.is_relative_to(workspace),
                'workspace must be separate from protected state')
        checkpoint = capture(workspace, base_digest)
        run_id = uid()
        with self.journal.change('create') as state:
            self.principal(token, 'control_service', project)
            require(not any(r['project'] == project and r['task'] == task
                            for r in state['runs'].values()), 'task already issued')
            state['runs'][run_id] = dict(
                id=run_id, project=project, task=task, brief_digest=digest(brief),
                plan=plan,
                plan_approval=None, checkpoint=checkpoint, checkpoint_digest=digest(checkpoint),
                current=None, stopped=False, records={}, confirmations={},
                attempts=[dict(id=uid(), ordinal=1, state='queued', error=None,
                               workspace=str(workspace), generation=state['generation'], lease=None)])
        return run_id

    def approve_plan(self, token, run_id, plan_digest):
        with self.journal.change('approve_plan') as state:
            run = state['runs'][run_id]
            p = self.principal(token, 'customer', run['project'])
            require(plan_digest == digest(run['plan']), 'plan revision changed')
            run['plan_approval'] = plan_digest
            run['plan_approver'] = deepcopy(p)

    def dispatch(self, token, run_id, agent, *, crash=None):
        # No arbitrary callable or subclass from candidate content can execute.
        real = type(agent) is not FakeAgent
        require(not real or type(agent) is claude_code_agent(),
                'only the fake data agent or the Claude Code agent is supported')
        with self.journal.change('dispatch') as state:
            run = state['runs'][run_id]
            self.principal(token, 'control_service', run['project'])
            self.live(state, run)
            a = self.attempt(run)
            require(a['state'] == 'queued', 'attempt cannot resume')
            require(agent.tool_digest == run['plan']['tool_digest'], 'tool changed')
            builders = [p for p in self.sessions.values() if p['role'] == 'task_agent' and
                        run['project'] in p['projects'] and p['family'] == agent.family]
            require(run['plan']['policy'].get('independent_review', True) or len(builders) == 1,
                    'same-family policy needs one authenticated builder identity')
            builder = deepcopy(builders[0]) if len(builders) == 1 else None
            seconds = 60
            if real:  # Lease lasts the plan's time limit, which the agent also enforces.
                seconds = run['plan'].get('time_limit_seconds')
                require(type(seconds) is int and seconds == agent.time_limit_seconds,
                        'time limit changed')
                require(digest(agent.brief) == run['plan']['brief_digest'], 'brief changed')
            lease = dict(id=uid(), attempt=a['id'], generation=state['generation'],
                         plan_digest=digest(run['plan']), workspace=a['workspace'],
                         tool_digest=agent.tool_digest, expires_at=self.clock() + seconds)
            a.update(state='running', lease=lease)
            workspace, base = a['workspace'], run['plan']['base_digest']
        if crash == 'before_agent':
            return None  # Intentional test crash: durable running intent exists.
        try:
            capture(workspace, base)
            agent.run(workspace)
            manifest = capture(workspace, base)
            mapping, _ = git_objects(manifest)
            if crash == 'before_candidate':
                return None
            with self.journal.change('candidate') as state:
                run = state['runs'][run_id]
                self.live(state, run)
                a = self.attempt(run)
                require(a['state'] == 'running' and a['lease'] == lease and
                        self.clock() < lease['expires_at'], 'stale/expired lease')
                candidate_id = uid()
                ref = dict(id=candidate_id, digest=digest(manifest))
                record = dict(id=uid(), run_id=run_id, project=run['project'], task=run['task'],
                              attempt_id=a['id'], candidate=ref, manifest=manifest,
                              brief_digest=run['brief_digest'], plan=deepcopy(run['plan']),
                              policy_digest=digest(run['plan']['policy']),
                              acceptance_policy=dict(deepcopy(run['plan']['policy']),
                                  independent_review=run['plan']['policy'].get('independent_review', True)),
                              base_digest=base, checkpoint_digest=run['checkpoint_digest'],
                              lease=lease, builder_family=agent.family, builder=builder, **mapping,
                              checks=[], reviews=[], approvals=[], publications=[])
                run['records'][candidate_id] = record
                run['current'] = candidate_id
                a.update(state='completed', error=None)
            return ref
        except Exception as exc:
            with self.journal.change('dispatch_hold') as state:
                run = state['runs'][run_id]
                a = self.attempt(run)
                if a['lease'] == lease:
                    a.update(state='held', error=str(exc))
            raise

    def drive(self, token, run_id, agent):
        """Drain one queued task; never restart an interrupted dispatch implicitly."""
        while True:
            with self.journal.change('dispatch_loop') as state:
                run = state['runs'][run_id]
                self.principal(token, 'control_service', run['project'])
                a = self.attempt(run)
                status = a['state']
                if status == 'running':
                    state['generation'] += 1
                    self.invalidate(run)
                    a.update(state='held', error='interrupted dispatch requires recovery proof')
                    status = 'held'
            if status == 'queued':
                self.dispatch(token, run_id, agent)
            else:
                require(status in {'held', 'completed'}, 'unknown attempt state: hold')
                return self.view(run_id)

    @staticmethod
    def record(run):
        require(run['current'] is not None, 'no current candidate')
        r = run['records'][run['current']]
        require(r['candidate']['digest'] == digest(validate_manifest(r['manifest'])),
                'frozen candidate corrupted')
        mapping, _ = git_objects(r['manifest'])
        require(all(r[k] == v for k, v in mapping.items()), 'artifact mapping corrupted')
        return r

    @staticmethod
    def binding(run, record, kind, name):
        policy = run['plan']['policy']
        rule = policy['checks'].get(name) if kind == 'check' else policy['review']
        require(rule is not None and kind in {'check', 'review'}, 'unknown check definition')
        return dict(candidate=record['candidate'], policy_digest=digest(policy), **rule)

    @staticmethod
    def review_actor(run, record, actor):
        require(actor['role'] == 'reviewer' and run['project'] in actor['projects'],
                'authenticated reviewer role/project required')
        if run['plan']['policy'].get('independent_review', True):
            require(actor['family'] != record['builder_family'], 'independent family required')
        else:
            builder = record.get('builder')
            require(builder is not None and actor['id'] != builder['id'] and
                    actor['session_id'] != builder['session_id'], 'builder cannot review')

    def assess(self, token, run_id, kind, name, binding, verdict):
        with self.journal.change('assessment') as state:
            run = state['runs'][run_id]
            p = self.principal(token, 'checker' if kind == 'check' else 'reviewer', run['project'])
            record = self.record(run)
            require(binding == self.binding(run, record, kind, name), 'stale assessment binding')
            require(verdict in {'passed', 'failed', 'held'}, 'assessment verdict')
            if kind == 'review':
                self.review_actor(run, record, p)
            self.invalidate(run)
            record['checks' if kind == 'check' else 'reviews'].append(dict(
                id=uid(), name=name, binding=deepcopy(binding), actor=deepcopy(p), verdict=verdict))

    def eligible(self, state, run):
        self.live(state, run)
        record = self.record(run)
        require(self.attempt(run)['state'] == 'completed', 'execution incomplete')
        for kind, names, collection in [('check', run['plan']['policy']['checks'], 'checks'),
                                         ('review', ['review'], 'reviews')]:
            for name in names:
                binding = self.binding(run, record, kind, name)
                matches = [e for e in record[collection] if e['name'] == name and e['binding'] == binding]
                require(matches and matches[-1]['verdict'] == 'passed', 'current passing evidence required')
                if kind == 'review':
                    self.review_actor(run, record, matches[-1]['actor'])
        return record

    def set_policy(self, token, run_id, policy):
        policy_check(policy)
        with self.journal.change('policy') as state:
            run = state['runs'][run_id]
            self.principal(token, 'control_service', run['project'])
            require(not self.unresolved(run), 'unresolved publication: hold')
            require(self.attempt(run)['state'] != 'running', 'running lease must be fenced first')
            run['plan']['policy'] = deepcopy(policy)
            run['plan_approval'] = None
            self.invalidate(run)
            if run['current'] is not None:
                self.record(run)['acceptance_policy'] = dict(
                    deepcopy(policy), independent_review=policy.get('independent_review', True))

    def display(self, token, run_id, action, destination):
        destination_check(action, destination)
        with self.journal.change('display') as state:
            run = state['runs'][run_id]
            p = self.principal(token, 'customer', run['project'])
            record = self.eligible(state, run)
            require(action != 'deploy' or destination['artifact_digest'] == record['artifact_digest'],
                    'deploy artifact mismatch')
            reference = uid()
            shown = dict(scope=dict(project=run['project'], task=run['task'], run=run_id,
                                    attempt=record['attempt_id']),
                         candidate=record['candidate'], action=action, destination=deepcopy(destination),
                         policy_digest=digest(run['plan']['policy']),
                         evidence_digest=digest([record['checks'], record['reviews']]))
            run['confirmations'][reference] = dict(session=p['session_id'], actor=p['id'], tuple=shown)
        return dict(reference=reference, displayed=deepcopy(shown))

    def confirm(self, token, run_id, reference, displayed):
        with self.journal.change('confirm') as state:
            run = state['runs'][run_id]
            p = self.principal(token, 'customer', run['project'])
            record = self.eligible(state, run)
            conf = run['confirmations'].get(reference)
            require(conf and conf['session'] == p['session_id'] and conf['actor'] == p['id'] and
                    conf['tuple'] == displayed and displayed['candidate'] == record['candidate'] and
                    displayed['policy_digest'] == digest(run['plan']['policy']) and
                    displayed['evidence_digest'] == digest([record['checks'], record['reviews']]),
                    'stale/foreign/substituted confirmation')
            approval = dict(id=uid(), actor=deepcopy(p), confirmation=reference,
                            session_id=p['session_id'],
                            tuple=deepcopy(displayed), state='active', consumed_by=None)
            record['approvals'].append(approval)
            del run['confirmations'][reference]
        return approval['id']

    @staticmethod
    def unresolved(run):
        return any(p['outcome'] in {'received', 'uncertain', 'held'}
                   for r in run['records'].values() for p in r['publications'])

    def revoke(self, token, run_id, *, stop=False):
        with self.journal.change('revoke') as state:
            run = state['runs'][run_id]
            self.principal(token, 'customer', run['project'])
            self.invalidate(run)
            run['plan_approval'] = None
            if stop:
                run['stopped'] = True
                self.attempt(run).update(state='held', error='stop: termination/reconciliation required')

    def admit(self, token, run_id, key, approval_id, body):
        """Durable intent only. No outward action is performed by EX1."""
        with self.journal.change('admit') as state:
            run = state['runs'][run_id]
            p = self.principal(token, 'customer', run['project'])
            require(isinstance(key, str) and key, 'idempotency key required')
            old = [pub for other in state['runs'].values() if other['project'] == run['project']
                   for r in other['records'].values() for pub in r['publications']
                   if pub['actor']['id'] == p['id'] and pub['key'] == key]
            if old:
                require(old[0]['body'] == body and old[0]['approval_id'] == approval_id,
                        'idempotency conflict')
                return deepcopy(old[0])
            require(not self.unresolved(run), 'unresolved publication: hold')
            record = self.eligible(state, run)
            approval = next((a for a in record['approvals'] if a['id'] == approval_id), None)
            require(approval and approval['state'] == 'active' and not approval['consumed_by'] and
                    approval['actor']['id'] == p['id'] and approval['tuple'] == body,
                    'exact unconsumed approval required')
            destination_check(body['action'], body['destination'])
            require(body['candidate'] == record['candidate'] and
                    body['policy_digest'] == digest(run['plan']['policy']), 'stale approval')
            operation = dict(id=uid(), actor=deepcopy(p), key=key, approval_id=approval_id,
                             body=deepcopy(body), generation=state['generation'],
                             run_record_id=record['id'], outcome='received', error=None,
                             dispatched=False, reconciliation=None)
            approval['consumed_by'] = operation['id']
            record['publications'].append(operation)
        return deepcopy(operation)

    def fake_publish(self, token, run_id, operation_id, endpoint, *, crash=None):
        require(type(endpoint) is FakeEndpoint, 'only a fake local endpoint is supported')
        with self.journal.change('fake_dispatch') as state:
            run = state['runs'][run_id]
            self.principal(token, 'control_service', run['project'])
            self.eligible(state, run)
            record = self.record(run)
            op = next(p for p in record['publications'] if p['id'] == operation_id)
            require(op['generation'] == state['generation'] and not op['dispatched'] and
                    op['outcome'] == 'received', 'stale/already dispatched intent')
            approval = next(a for a in record['approvals'] if a['id'] == op['approval_id'])
            require(approval['state'] == 'active', 'revoked approval')
            op['dispatched'] = True  # Durable BEFORE crossing the fake write boundary.
            body = deepcopy(op['body'])
            frozen = deepcopy(record['manifest'])
        if crash == 'before_send':
            return
        # Serialize the fake boundary with revocation/recovery. The durable
        # dispatched marker above survives a crash inside this second transaction.
        with self.journal.change('fake_send') as state:
            run = state['runs'][run_id]
            self.eligible(state, run)
            record = self.record(run)
            op = next(p for p in record['publications'] if p['id'] == operation_id)
            approval = next(a for a in record['approvals'] if a['id'] == op['approval_id'])
            # Same serialized transaction as the write: any reconcile moves the
            # outcome off `received`, which fences a worker paused before here.
            require(op['generation'] == state['generation'] and approval['state'] == 'active' and
                    op['dispatched'] and op['outcome'] == 'received',
                    'fenced/revoked before send')
            endpoint.write(operation_id, body, frozen)
        if crash == 'after_send':
            return
        self.reconcile(token, run_id, operation_id, endpoint)

    def reconcile(self, token, run_id, operation_id, endpoint):
        require(type(endpoint) is FakeEndpoint, 'only a fake local endpoint is supported')
        with self.journal.change('reconcile') as state:
            run = state['runs'][run_id]
            self.principal(token, 'control_service', run['project'])
            op = next(p for r in run['records'].values() for p in r['publications']
                      if p['id'] == operation_id)
            require(op['outcome'] not in {'succeeded', 'failed'}, 'terminal outcome: no overwrite')
            observed = endpoint.query(op['id'], op['body'])
            op['reconciliation'] = dict(observed=observed, generation=state['generation'])
            op['outcome'] = {'landed': 'succeeded', 'not_landed': 'failed'}.get(observed, 'held')
            op['error'] = None if observed == 'landed' else 'reconciled ' + observed

    def recover(self, token, run_id, destination, *, workers_fenced, endpoint=None):
        """Never reuse the old workspace or conversation. Missing proof means hold."""
        with self.journal.change('recovery_fence') as state:
            run = state['runs'][run_id]
            self.principal(token, 'control_service', run['project'])
            state['generation'] += 1
            self.invalidate(run)
            a = self.attempt(run)
            a.update(state='held', error='restart fenced old attempt')
        # The fence MUST commit even when termination/checkpoint/reconciliation
        # later fails. Refusals below cannot restore the old worker's authority.
        with self.journal.change('recovery_proof') as state:
            run = state['runs'][run_id]
            require(workers_fenced is True, 'termination unproven: hold')
        run = self.view(run_id)
        pending = [op['id'] for r in run['records'].values() for op in r['publications']
                   if op['outcome'] in {'received', 'uncertain', 'held'}]
        for operation_id in pending:
            self.reconcile(token, run_id, operation_id, endpoint)
        with self.journal.change('recover') as state:
            run = state['runs'][run_id]
            a = self.attempt(run)
            require(not self.unresolved(run), 'publication unresolved: hold')
            require(not run['stopped'], 'stopped run remains held')
            checkpoint = run['checkpoint']
            require(digest(validate_manifest(checkpoint)) == run['checkpoint_digest'],
                    'checkpoint corrupted: hold')
            destination = Path(destination).absolute()
            require(not self.journal.path.is_relative_to(destination) and
                    destination != Path(a['workspace']), 'unsafe recovery workspace')
            # A filesystem failure leaves only scratch; no runnable attempt is granted.
            try:
                restore(checkpoint, destination)
            except OSError as exc:
                raise Refused('checkpoint restore failed: hold') from exc
            run['current'] = None
            run['attempts'].append(dict(id=uid(), ordinal=a['ordinal'] + 1,
                state='queued', error=None, workspace=str(destination),
                generation=state['generation'], lease=None))
        return self.view(run_id)

    def view(self, run_id):
        """UI, receipt and evidence export all call this same protected read."""
        run = self.journal.read()['runs'][run_id]
        if run['current'] is not None:
            self.record(run)
        run['independent_review'] = run['plan']['policy'].get('independent_review', True)
        for record in run['records'].values():
            record['acceptance_policy'].setdefault('independent_review', True)
        return deepcopy(run)


class FakeEndpoint:
    """Instrumented fake external state, durable across Service restarts in tests.

    No actual transport or PR publisher. PR owns real reconciliation adapters.
    """
    def __init__(self):
        self.writes = []
        self.observation = None

    def write(self, operation, body, manifest):
        require(digest(manifest) == body['candidate']['digest'], 'wrong frozen bytes')
        self.writes.append(dict(operation=operation, body=deepcopy(body), manifest=deepcopy(manifest)))

    def query(self, operation, body):
        if self.observation is not None:
            return self.observation
        matches = [w for w in self.writes if w['operation'] == operation]
        if len(matches) > 1:
            return 'duplicate'
        if matches and matches[0]['body'] == body:
            return 'landed'
        return 'not_landed' if not matches else 'divergent'
