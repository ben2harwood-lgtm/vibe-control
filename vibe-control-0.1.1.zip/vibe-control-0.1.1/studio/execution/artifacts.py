"""Data-only import for the local fake execution harness. Never reads Git config."""
import hashlib
import importlib.util
import os
from pathlib import Path
import stat
import unicodedata

_spec = importlib.util.spec_from_file_location(
    'studio_contract_bindings', Path(__file__).resolve().parents[1] / 'contract' / 'bindings.py')
_bindings = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_bindings)
digest = _bindings.digest


class Refused(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Refused(message)


def safe_path(path):
    require(isinstance(path, str) and path and not path.startswith('/') and
            path == unicodedata.normalize('NFC', path) and '\\' not in path and
            all(ord(c) >= 32 and ord(c) != 127 for c in path) and
            not any(0xD800 <= ord(c) <= 0xDFFF for c in path) and
            all(unicodedata.category(c) != 'Cf' for c in path) and  # HFS-ignored, e.g. .g‌it
            all(p not in {'', '.', '..'} and p.casefold() != '.git'
                for p in path.split('/')), 'unsafe artifact path')
    # Refuse HFS/NTFS aliases too; no platform-specific Git metadata aliases.
    require(all(not p.endswith(('.', ' ')) and ':' not in p and
                not p.casefold().startswith('git~') for p in path.split('/')),
            'ambiguous artifact path')


def validate_manifest(manifest):
    require(set(manifest) == {'base_digest', 'entries'}, 'manifest fields')
    require(isinstance(manifest['base_digest'], str) and
            len(manifest['base_digest']) == 71 and
            manifest['base_digest'].startswith('sha256:') and
            all(c in '0123456789abcdef' for c in manifest['base_digest'][7:]),
            'base digest')
    paths, aliases = [], set()
    total = 0
    for entry in manifest['entries']:
        require(set(entry) == {'path', 'type', 'mode', 'bytes_hex'}, 'entry fields')
        path = entry['path']
        safe_path(path)
        require(entry['type'] == 'file' and entry['mode'] in {'100644', '100755'},
                'unsupported file type/mode')
        encoded = entry['bytes_hex']
        require(isinstance(encoded, str) and len(encoded) % 2 == 0 and
                all(c in '0123456789abcdef' for c in encoded), 'noncanonical bytes')
        total += len(encoded) // 2
        parts = path.split('/')
        for i in range(1, len(parts) + 1):
            prefix = '/'.join(parts[:i])
            alias = prefix.casefold()
            require(not any(a == alias and p != prefix for a, p in aliases),
                    'ambiguous path collision')
            aliases.add((alias, prefix))
        paths.append(path)
    require(len(paths) <= 1000 and total <= 4 * 1024 * 1024, 'artifact size limit')
    require(paths == sorted(set(paths)), 'paths must be sorted and unique')
    require(not any('/'.join(p.split('/')[:i]) in paths
                    for p in paths for i in range(1, len(p.split('/')))),
            'file/directory collision')
    return manifest


def capture(root, base_digest):
    """No-follow fd traversal; two stable scans or refusal. Task must be quiescent.

    The second scan detects concurrent mutations, but is not an OS freeze. RT must
    prove process termination before production import; this harness has no worker
    subprocesses. Size ceilings bound this fake importer, not provider usage.
    """
    root = Path(root)

    def identity(info):
        # Reading can change atime; that is not a content mutation.
        return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink,
                info.st_size, info.st_mtime_ns, info.st_ctime_ns)

    def scan():
        entries, identities = [], []

        def walk(directory, prefix=''):
            names = sorted(os.listdir(directory))
            for name in names:
                if not prefix and name == '.git':
                    continue  # never open task Git metadata, even a linked .git
                path = prefix + name
                safe_path(path)
                before = os.stat(name, dir_fd=directory, follow_symlinks=False)
                require(not stat.S_ISLNK(before.st_mode), 'links are forbidden')
                flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
                if stat.S_ISDIR(before.st_mode):
                    flags |= os.O_DIRECTORY
                else:
                    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1,
                            'only unlinked regular files allowed')
                    require(before.st_size <= 4 * 1024 * 1024, 'artifact size limit')
                fd = os.open(name, flags, dir_fd=directory)
                try:
                    opened = os.fstat(fd)
                    require(identity(opened) == identity(before), 'changed during import')
                    if stat.S_ISDIR(opened.st_mode):
                        walk(fd, path + '/')
                    else:
                        with os.fdopen(os.dup(fd), 'rb') as stream:
                            data = stream.read(4 * 1024 * 1024 + 1)
                        require(len(data) == before.st_size, 'changed during import')
                        entries.append(dict(path=path, type='file', mode=(
                            '100755' if before.st_mode & 0o111 else '100644'),
                            bytes_hex=data.hex()))
                        require(len(entries) <= 1000 and sum(
                            len(e['bytes_hex']) // 2 for e in entries) <= 4 * 1024 * 1024,
                            'artifact size limit')
                    require(identity(os.fstat(fd)) == identity(before) and identity(os.stat(
                        name, dir_fd=directory, follow_symlinks=False)) == identity(before),
                        'changed during import')
                    identities.append((path, identity(before)))
                finally:
                    os.close(fd)
            require(sorted(os.listdir(directory)) == names, 'changed during import')

        fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            root_identity = identity(os.fstat(fd))
            walk(fd)
            require(identity(os.fstat(fd)) == root_identity and
                    identity(root.stat(follow_symlinks=False)) == root_identity,
                    'changed during import')
            identities.append(('', root_identity))
        finally:
            os.close(fd)
        return sorted(entries, key=lambda e: e['path']), identities

    try:
        first, identities = scan()
        second, later = scan()
        require(first == second and identities == later, 'changed during import')
    except OSError as exc:
        raise Refused('unsafe or changing workspace') from exc
    return validate_manifest(dict(base_digest=base_digest, entries=first))


def restore(manifest, destination):
    """Restore verified data only into a new, trusted directory."""
    validate_manifest(manifest)
    root = Path(destination)
    require(root.parent.resolve() == root.parent.absolute(), 'linked recovery parent')
    root.mkdir(mode=0o700, exist_ok=False)
    # A minimal local repository, made without invoking any Git write command.
    (root / '.git' / 'objects').mkdir(parents=True)
    (root / '.git' / 'refs').mkdir()
    (root / '.git' / 'HEAD').write_text('ref: refs/heads/fake-task\n')
    for entry in manifest['entries']:
        target = root / entry['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(bytes.fromhex(entry['bytes_hex']))
        target.chmod(0o755 if entry['mode'] == '100755' else 0o644)
    return root


def git_objects(manifest):
    """Construct actual Git blob/tree bytes without checkout, hooks or filters."""
    validate_manifest(manifest)
    objects = {}

    def put(kind, data):
        raw = kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data
        oid = hashlib.sha1(raw).hexdigest()
        objects[oid] = raw
        return oid

    tree = {}
    for entry in manifest['entries']:
        branch = tree
        parts = entry['path'].split('/')
        for part in parts[:-1]:
            branch = branch.setdefault(part, {})
        branch[parts[-1]] = (entry['mode'], put('blob', bytes.fromhex(entry['bytes_hex'])))

    def build(branch):
        content = b''
        for name, value in sorted(branch.items(), key=lambda item: (
                item[0] + ('/' if isinstance(item[1], dict) else '')).encode()):
            mode, oid = ('40000', build(value)) if isinstance(value, dict) else value
            content += mode.encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(oid)
        return put('tree', content)

    oid = build(tree)
    mapping = dict(git_tree_oid=oid, git_tree_digest='sha256:' +
                   hashlib.sha256(objects[oid]).hexdigest(), artifact_digest=digest(manifest))
    return mapping, objects
