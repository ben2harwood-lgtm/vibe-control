"""COM: the licence check that unlocks the user's own code (honest-user gate, not copy protection).

The built-in example project is always free. Any other project needs a key activated with
the merchant of record (Polar). `Polar` is the only code that talks to the merchant, so another
merchant can be swapped in. Standard library only; the full key is never printed or logged.

    python studio/licence/licence.py activate|status|deactivate
"""
import dataclasses
import getpass
import hashlib
import http.client
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

HERE = Path(__file__).resolve().parent
CONFIG = HERE / 'licence.json'
KEY_FILE = 'licence-key'
RECORD_FILE = 'licence-record.json'
INSTANCE_NAME = 'Vibe Control'
DAY = 86400
RECHECK = DAY            # ask the merchant at most once a day
GRACE = 30 * DAY         # offline allowance after the last good answer
SKEW = 300               # a validation time further ahead than this is not believed
STATUSES = ('granted', 'revoked', 'disabled')
ACTIVATE_HINT = 'Run: vibe licence activate'


@dataclasses.dataclass(frozen=True)
class Verdict:
    ok: bool
    reason: str


class Unreachable(Exception):
    """No usable answer from the merchant (network, timeout, server error, unreadable reply)."""


class UnsafeFolder(Exception):
    """The licence folder is not a real folder owned by the current user."""


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None  # a redirect becomes an error, never a request to another host


class Polar:
    """Polar's customer-portal licence-key API: JSON POSTs, JSON replies, no authentication.

    Each reply is turned into one plain shape, so `Licence` never sees Polar's own field names:
    accepted (bool), error (text or None), status, organization_id, benefit_id, activation_id.
    """

    def __init__(self, base, organization_id, timeout=3.0):
        parts = urllib.parse.urlsplit(base)
        if parts.scheme != 'https' and not (parts.scheme == 'http' and parts.hostname == '127.0.0.1'):
            raise ValueError('The merchant address must use https.')
        self.base = base.rstrip('/')
        self.organization_id = organization_id
        self.timeout = timeout
        self._open = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect).open

    def activate(self, key, label):
        return self._post('activate', dict(key=key, organization_id=self.organization_id, label=label))

    def validate(self, key, activation_id):
        return self._post('validate', dict(key=key, organization_id=self.organization_id,
                                           activation_id=activation_id))

    def deactivate(self, key, activation_id):
        return self._post('deactivate', dict(key=key, organization_id=self.organization_id,
                                             activation_id=activation_id))

    def _post(self, action, fields):
        request = urllib.request.Request(
            self.base + '/v1/customer-portal/license-keys/' + action, data=json.dumps(fields).encode(),
            headers={'Accept': 'application/json', 'Content-Type': 'application/json'})
        try:
            try:
                with self._open(request, timeout=self.timeout) as response:
                    code, body = response.status, response.read(65536)
            except urllib.error.HTTPError as error:  # any non-2xx, and a redirect that was not followed
                try:
                    code, body = error.code, error.read(65536)
                finally:
                    error.close()
            if action == 'deactivate' and code == 204:
                return dict(accepted=True, error=None)  # Polar answers a freed activation with no body
            reply = json.loads(body)
        except (OSError, ValueError, RecursionError, http.client.HTTPException):
            raise Unreachable('The merchant could not be reached or its reply could not be read.') from None
        if not isinstance(reply, dict):
            raise Unreachable('The merchant reply could not be read.')
        if not 200 <= code < 300:
            # Only a plain "no" (not "slow down", "timed out" or a server error) with Polar's error body
            # is an answer: 403 not permitted, 404 not found, 422 not valid.
            if not (code in (403, 404, 422) and ('detail' in reply or 'error' in reply)):
                raise Unreachable('The merchant did not answer properly.')
            detail = reply.get('detail')
            return dict(accepted=False, error=detail if isinstance(detail, str) else reply.get('error'))
        if action == 'deactivate':
            raise Unreachable('The merchant did not answer properly.')  # only 204 frees an activation
        if action == 'activate':  # an activation, holding its licence key
            key_info, activation_id = _dig(reply, 'license_key'), reply.get('id')
        else:  # a licence key, holding the activation that was named
            key_info, activation_id = reply, _dig(reply, 'activation').get('id')
        return dict(accepted=True, error=None, status=key_info.get('status'),
                    organization_id=key_info.get('organization_id'), benefit_id=key_info.get('benefit_id'),
                    activation_id=activation_id)


def load_config(path=CONFIG):
    return json.loads(Path(path).read_text())


def is_example(project_path, example_path, marker, marker_sha256):
    """True only for the shipped example folder itself (after resolving links) with its exact marker."""
    try:
        project = Path(project_path).resolve(strict=True)
        example = Path(example_path).resolve(strict=True)
        mark = example / marker
        if project != example or mark.is_symlink() or not mark.is_file():
            return False
        return hashlib.sha256(mark.read_bytes()).hexdigest() == marker_sha256
    except OSError:
        return False


def _seal(key, record):
    fields = {name: record.get(name) for name in
              ('state', 'key_last4', 'instance_id', 'organization_id', 'benefit_id', 'validated_at')}
    return hashlib.sha256(json.dumps([key, fields], sort_keys=True).encode()).hexdigest()


def _dig(value, name):
    value = value.get(name) if isinstance(value, dict) else None
    return value if isinstance(value, dict) else {}


def _days(seconds):
    days = int(seconds // DAY)
    if days == 0:
        return 'less than a day'
    return '1 day' if days == 1 else '%d days' % days


class Licence:
    def __init__(self, folder=None, config=None, merchant=None, clock=time.time):
        self.config = load_config() if config is None else config
        self.folder = Path(folder) if folder is not None else Path.home() / '.vibe-control'
        self.merchant = (merchant if merchant is not None else
                         Polar(self.config['merchant_base'], self.config['organization_id']))
        self.clock = clock

    # Public commands

    def activate(self, key):
        key = key.strip() if isinstance(key, str) else ''
        unsafe = self._unsafe()
        if unsafe:
            return unsafe
        if not 8 <= len(key) <= 200 or any(c.isspace() or not c.isprintable() for c in key):
            return Verdict(False, 'That does not look like a licence key.')
        try:
            reply = self.merchant.activate(key, INSTANCE_NAME)
        except Unreachable:
            return Verdict(False, 'Could not reach the merchant to activate this key. '
                                  'Check your internet connection and try again.')
        instance_id = reply.get('activation_id')
        problem = self._problem(reply, key)
        if not problem and not (isinstance(instance_id, str) and instance_id):
            problem = 'The merchant did not return an activation for this machine.'
        if problem:
            return Verdict(False, problem)
        self._save(key, instance_id)
        return Verdict(True, 'Unlocked: Vibe Control can now work on your own code (key ending %s).'
                       % key[-4:])

    def status(self):
        unsafe = self._unsafe()
        if unsafe:
            return unsafe
        record = self._read_record()
        if record is None:
            return Verdict(False, 'No licence on this machine. ' + ACTIVATE_HINT)
        if record.get('state') == 'locked':
            return Verdict(False, 'This machine is locked. ' + ACTIVATE_HINT)
        key = self._read_key()
        if key is None:
            return Verdict(False, 'The local licence files are incomplete. ' + ACTIVATE_HINT)
        now = self.clock()
        trusted = self._trusted(key, record, now)
        age = now - record['validated_at'] if trusted else None
        if trusted and age < RECHECK:
            return Verdict(True, 'Unlocked (key ending %s).' % key[-4:])
        instance_id = record.get('instance_id') if isinstance(record.get('instance_id'), str) else ''
        try:
            reply = self.merchant.validate(key, instance_id)
        except Unreachable:
            if trusted and age <= GRACE:
                return Verdict(True, 'Unlocked, but the merchant could not be reached to re-check. Last '
                               'confirmed %s ago; it must be confirmed again within %s.'
                               % (_days(age), _days(GRACE - age)))
            if trusted:
                return Verdict(False, 'The licence was last confirmed more than 30 days ago and the '
                                      'merchant cannot be reached now. Connect to the internet and try again.')
            return Verdict(False, 'The local licence record does not match what was stored, and the '
                                  'merchant cannot be reached to check it. Connect to the internet '
                                  'and try again, or activate again.')
        problem = self._problem(reply, key)
        if not problem and reply.get('activation_id') != instance_id:
            problem = 'The merchant does not recognise this machine\'s activation.'
        if problem:
            self._lock(key)
            return Verdict(False, problem + ' The unlock on this machine has been removed.')
        self._save(key, instance_id)
        return Verdict(True, 'Unlocked (key ending %s, confirmed with the merchant just now).' % key[-4:])

    def deactivate(self):
        unsafe = self._unsafe()
        if unsafe:
            return unsafe
        record, key = self._read_record(), self._read_key()
        if not record or record.get('state') != 'unlocked' or key is None:
            return Verdict(False, 'There is no active licence on this machine to deactivate.')
        try:
            freed = self.merchant.deactivate(key, record.get('instance_id')).get('accepted') is True
        except Unreachable:
            freed = False
        self._lock(key)
        if freed:
            return Verdict(True, 'Deactivated: this machine is locked and its activation is free to use elsewhere.')
        return Verdict(True, 'This machine is locked, but the merchant did not confirm that the activation '
                             'was freed. It may still count towards the key\'s limit.')

    def gate(self, project_path, example_path=None):
        config = self.config
        example = example_path if example_path is not None else HERE.parent / config['example_dir']
        if is_example(project_path, example, config['example_marker'], config['example_marker_sha256']):
            return Verdict(True, 'This is the built-in example project, which is free. No licence needed.')
        result = self.status()
        if result.ok:
            return Verdict(True, 'Your own project is allowed. ' + result.reason)
        buy = config.get('buy_url') or ''
        return Verdict(False, 'Vibe Control is free on the built-in example project; your own code needs '
                              'a licence. ' + result.reason + (' Buy a key at ' + buy if buy else ''))

    # Merchant replies

    def _problem(self, reply, key):
        """None when the reply proves a granted key for the expected organisation and benefit."""
        if reply.get('accepted') is not True:
            error = reply.get('error')
            detail = ''
            if isinstance(error, str) and error.strip():
                text = ''.join(c for c in error.replace(key, '[key]') if c.isprintable())[:200]
                detail = ' The merchant said: ' + text
            return 'The merchant did not accept this key.' + detail
        status = reply.get('status')
        if status != 'granted':
            return 'This key is %s, not active.' % (status if status in STATUSES else 'not recognised')
        # Sandbox (test) and live keys live on separate Polar servers with separate organisations, so
        # the merchant address and these two ids are what keep a test key out of a live copy.
        for name, label in (('organization_id', 'organisation'), ('benefit_id', 'product')):
            value = reply.get(name)
            if type(value) is not str or not value or value != self.config[name]:
                return 'This key belongs to a different %s, not Vibe Control.' % label
        return None

    # Local files

    def _trusted(self, key, record, now):
        try:
            return (record.get('state') == 'unlocked' and record.get('seal') == _seal(key, record)
                    and record.get('key_last4') == key[-4:]
                    and record.get('organization_id') == self.config['organization_id']
                    and record.get('benefit_id') == self.config['benefit_id']
                    and type(record.get('validated_at')) is int
                    and record['validated_at'] <= now + SKEW)
        except (TypeError, ValueError):
            return False

    def _check_folder(self):
        """Return None when the folder is missing or is a real directory owned by this user."""
        try:
            info = os.lstat(self.folder)
        except FileNotFoundError:
            return None
        except OSError:
            raise UnsafeFolder() from None
        if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
            raise UnsafeFolder()
        return info

    def _unsafe(self):
        """A refusal Verdict (before anything is sent or written) or None."""
        try:
            self._check_folder()
        except UnsafeFolder:
            return Verdict(False, 'The licence folder (%s) is not safe to use: it must be a real folder '
                                  'that only you own, not a link. Nothing was sent or saved.' % self.folder)
        return None

    def _read_text(self, name):
        """Read a file in the licence folder, refusing links and anything that is not a regular file."""
        descriptor = os.open(self.folder / name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(descriptor) as stream:
            if not stat.S_ISREG(os.fstat(descriptor).st_mode):
                raise OSError('not a regular file')
            return stream.read()

    def _read_record(self):
        try:
            record = json.loads(self._read_text(RECORD_FILE))
        except FileNotFoundError:
            return None
        except (OSError, ValueError, RecursionError):
            return {}
        return record if isinstance(record, dict) else {}

    def _read_key(self):
        try:
            key = self._read_text(KEY_FILE).strip()
        except (OSError, ValueError):
            return None
        return key or None

    def _save(self, key, instance_id):
        record = dict(state='unlocked', key_last4=key[-4:], instance_id=instance_id,
                      organization_id=self.config['organization_id'], benefit_id=self.config['benefit_id'],
                      validated_at=int(self.clock()))
        record['seal'] = _seal(key, record)
        self._write(KEY_FILE, key + '\n')
        self._write(RECORD_FILE, json.dumps(record, indent=2, sort_keys=True) + '\n')

    def _lock(self, key):
        self._write(RECORD_FILE, json.dumps(dict(state='locked', key_last4=key[-4:]), indent=2) + '\n')
        try:
            os.unlink(self.folder / KEY_FILE)
        except FileNotFoundError:
            pass

    def _write(self, name, text):
        info = self._check_folder()
        if info is None:
            self.folder.mkdir(mode=0o700, parents=True)
            os.chmod(self.folder, 0o700)
        elif stat.S_IMODE(info.st_mode) != 0o700:
            os.chmod(self.folder, 0o700)
        handle, temporary = tempfile.mkstemp(dir=self.folder, prefix='.' + name + '.')  # mode 0600
        try:
            with os.fdopen(handle, 'w') as stream:
                os.fchmod(stream.fileno(), 0o600)
                stream.write(text)
            os.replace(temporary, self.folder / name)
        except BaseException:
            if os.path.exists(temporary):
                os.unlink(temporary)
            raise


def main(argv=None, licence=None, stdin=None):
    args = sys.argv[1:] if argv is None else argv
    stdin = sys.stdin if stdin is None else stdin
    if len(args) != 1 or args[0] not in ('activate', 'status', 'deactivate'):
        print('Usage: python studio/licence/licence.py activate|status|deactivate', file=sys.stderr)
        return 2
    licence = Licence() if licence is None else licence
    if args[0] == 'activate':
        # The key is read from the terminal or standard input, never the command line.
        key = getpass.getpass('Licence key: ') if stdin.isatty() else stdin.readline()
        result = licence.activate(key)
    else:
        result = getattr(licence, args[0])()
    print(result.reason)
    return 0 if result.ok else 1


if __name__ == '__main__':
    sys.exit(main())
