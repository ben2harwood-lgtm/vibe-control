# Vibe Control

Vibe Control runs a coding task through a plan, a build, a check and a second Claude Code review on your Mac. You approve the plan and type the candidate's short code before it delivers a new branch to a local repository. The built-in example is free to try.

The licence terms are approved. Buying a licence key for your own code is not open yet; the built-in example is free to try now.

Requirements: macOS, Python 3.11 or newer, Git, Claude Code on PATH with your own existing subscription setup, and Node.js 20.10 or newer for the example's checks. Vibe installs none of these. Your own projects also need their check command's tools.

Unpack the zip, open a terminal in its `vibe-control-0.1.1` folder, and run:

```sh
./vibe doctor
./vibe demo
```

If the unpacking tool drops the executable bit, `sh ./vibe` works the same; for example, use `sh ./vibe doctor` and `sh ./vibe demo`. Demo needs a real terminal for its final approval; piped answers cannot approve it. If a run stops and is held, `./vibe demo --new` starts a fresh one.

Doctor lists the tools and versions it can find; it does not check sign-in. Demo asks you to approve the plan, runs the example, and asks you to type the displayed short code before branch delivery. The default time limit is ten minutes.

## What it does not do

A passing check does not prove your tests ran. Use a plain check-command form: `npm test`, `npm run <name>`, `yarn test`, `yarn <name>`, `pnpm test`, `pnpm run <name>` or `node --run <name>`. For these forms, Vibe Control records what the named script says at the start and refuses to continue if the change edits it, but this only covers scripts in the top-level `package.json`. Where an option sits before the script name, as in `npm --prefix . test`, Vibe Control locks every script the command could mean. A command that points at another folder's `package.json`, for example `npm --prefix some/folder test` or `cd some/folder && npm test`, runs scripts that are not locked, because only the top-level `package.json` is covered. Use the plain form. A change can still affect how tests behave through an `.npmrc` file, a test-runner configuration file, the script file your test command calls, a Makefile or the test files themselves. Vibe Control lists every changed file and flags `package.json`, lockfiles and test folders, but it cannot tell you whether your tests are still meaningful. Read the list of changed files before you approve.

Text from the reviewer, your tests and the brief appears on marked lines (`reviewer>`, `check>`, `brief>`, `file>`). In a narrow terminal, a very long marked line wraps onto another row without repeating its marker. The lines that matter — "Files changed", the check result, the review verdict and the code to type — are always printed last, directly above the approval question. Trust that last block.

The review comes from a second, fresh Claude Code session of the same model family. It is not an independent review. The reviewer has read-only tools: it cannot run your tests and is not shown the history, so it cannot always tell whether a test file was changed.

Vibe Control is not a security product. Your check command runs on your computer as you, without a sandbox, on code a model wrote, just as when you run your tests yourself. To keep the obvious things out of reach, the check starts with only a short list of environment settings (such as `PATH`, language settings and `TERM`), so tokens and keys you have exported are not passed to it, and its home folder, temporary folder and npm cache are an empty throwaway folder that is deleted afterwards. The check runs in a copy of your project in the system temporary folder, outside your home folder, so settings files in your home folder such as `~/.npmrc` or `~/.yarnrc.yml` are not picked up; that copy is deleted afterwards too. This is not isolation: the check can still read any file your account can read if it names the full path, use the network, and change files outside the clean copy. Because the npm cache starts empty, an install step such as `npm ci` downloads packages again each time. A proxy setting that contains a user name or password is not passed on.

Delivering the result into your repository runs that repository's own git hooks for incoming pushes, as any push into it would.

What works today is macOS with Claude Code, for JavaScript and TypeScript projects with a top-level `package.json`, up to 4 MB and 1,000 tracked files. Ignored folders such as `node_modules` do not count. Checks run in a clean copy, so include the install step in `--check` if your tests need installed packages. It has been run for real only on the built-in example and a small stand-in project.

The licence key is an honest-user gate, not copy protection.

## Using your own code

The proposed offer is $49 once to unlock your own code, alongside your own Claude subscription cost. Purchasing is not open yet: there is no purchase link, and the merchant configuration is a test placeholder. Once the owner provides a purchase link and configures the merchant, buy there and use the supplied key:

```sh
./vibe licence activate
./vibe licence status
./vibe run /absolute/path/to/repository --brief "Describe your change" --check "npm test"
```

Activation asks for the key and does not show it as you type; the key is never given on the command line. Run needs a clean supported JavaScript/TypeScript web repository. It creates a local branch; the terminal prints commands you can run yourself to push it and open a pull request.

Runs, the journal, receipts and exported run pages live under `~/.vibe-control/runs` by default. Use `--runs-dir /absolute/folder` to choose another location. The licence lives in `~/.vibe-control/licence-key` (full key in plain text) and `~/.vibe-control/licence-record.json`.

To remove Vibe, first use `./vibe licence deactivate` if you activated a key, then delete the unpacked folder. Delete `~/.vibe-control` and any custom runs folder if you also want to remove stored keys and runs; save any receipts you want first. Delivered branches remain in their local repositories.

What it is not:

- It is not a hosted service, a deployment tool or an automatic GitHub publisher.
- A completed build or a passing check is not your approval.
- Observed usage units are not a bill or a provider spending cap.

Maintainer note: a normal package build requires the owner to add a first line to `LICENCE.txt` exactly in this form: `Approved for distribution by Example Owner on 2020-01-01`, replacing the example name and date with the owner's name and approval date. The name must be nonempty without angle brackets or surrounding whitespace; the date must be a valid `YYYY-MM-DD` date no later than today. Nonempty licence terms must follow on subsequent lines. Remove all placeholder wording, the word “draft” and the phrase “not for distribution” from that file. Anything without this approval is refused unless `--allow-draft-licence` is used for a local DRAFT archive; a missing licence file gets a placeholder in that archive. The marker records the owner's manual approval, not a legal review.
